import type ts from "typescript";
import type { ProjectData } from "../../Shared/types.ts";
export declare function fileUsesCommentDirectives(data: ProjectData, sourceFile: ts.SourceFile): ts.Diagnostic[];
//# sourceMappingURL=fileUsesCommentDirectives.d.ts.map