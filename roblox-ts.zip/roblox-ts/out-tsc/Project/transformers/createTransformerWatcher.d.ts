import ts from "typescript";
import type { TransformerWatcher } from "../../Shared/types.ts";
export declare function createTransformerWatcher(program: ts.Program): TransformerWatcher;
//# sourceMappingURL=createTransformerWatcher.d.ts.map