import ts from "typescript";
import type { TransformerPluginConfig } from "../../Shared/types.ts";
export declare function flattenIntoTransformers(transformers: ts.CustomTransformers): Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>;
export declare function createTransformerList(program: ts.Program, configs: Array<TransformerPluginConfig>, baseDir: string): ts.CustomTransformers;
//# sourceMappingURL=createTransformerList.d.ts.map