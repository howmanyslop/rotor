import type { TransformerPluginConfig } from "../../Shared/types.ts";
export declare function getPluginConfigs(tsConfigPath: string): TransformerPluginConfig[];
//# sourceMappingURL=getPluginConfigs.d.ts.map