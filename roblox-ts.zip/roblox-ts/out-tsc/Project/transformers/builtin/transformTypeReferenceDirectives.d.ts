import ts from "typescript";
export declare function transformTypeReferenceDirectives(): (sourceFile: ts.SourceFile | ts.Bundle) => ts.Bundle | ts.SourceFile;
//# sourceMappingURL=transformTypeReferenceDirectives.d.ts.map