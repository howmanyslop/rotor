import ts from "typescript";
export declare function wrapTransformersWithParentFix(transformers: Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>): Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>;
//# sourceMappingURL=wrapTransformersWithParentFix.d.ts.map