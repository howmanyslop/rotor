export declare function isCompilableFile(fsPath: string): boolean;
//# sourceMappingURL=isCompilableFile.d.ts.map