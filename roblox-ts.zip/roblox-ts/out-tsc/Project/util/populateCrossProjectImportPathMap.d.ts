import ts from "typescript";
import type { ProjectOptions } from "../../Shared/types.ts";
export declare function populateCrossProjectImportPathMap(buildOrder: ReadonlyArray<string>, getParsedCommandLine: (configPath: string) => ts.ParsedCommandLine | undefined, entryProjectOptions: ProjectOptions, importPathMap: Map<string, string>, importPathMapOwnership?: Map<string, Set<string>>): void;
//# sourceMappingURL=populateCrossProjectImportPathMap.d.ts.map