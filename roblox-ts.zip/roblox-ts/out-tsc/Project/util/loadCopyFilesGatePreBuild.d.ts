import type { PathTranslator } from "@roblox-ts/path-translator";
import { type BuildStateSnapshot } from "./snapshotBuildState.ts";
export declare const COPY_FILES_CACHE_FILENAME = "rbxts.copyfiles.json";
export interface GateInputs {
    rootDirs: ReadonlyArray<string>;
    outDir: string;
    declaration: boolean;
    pathTranslator: PathTranslator;
    snapshot: BuildStateSnapshot;
}
export interface GateOutputs {
    skipCleanup: boolean;
    skipCopyFiles: boolean;
    persist: () => void;
}
export declare function loadCopyFilesGatePreBuild(inputs: GateInputs): GateOutputs;
//# sourceMappingURL=loadCopyFilesGatePreBuild.d.ts.map