import type ts from "typescript";
import type { ProjectData } from "../../Shared/types.ts";
export type PreEmitChecker = (data: ProjectData, sourceFile: ts.SourceFile) => Array<ts.Diagnostic>;
export declare function getCustomPreEmitDiagnostics(data: ProjectData, sourceFile: ts.SourceFile): ts.Diagnostic[];
//# sourceMappingURL=getCustomPreEmitDiagnostics.d.ts.map