import type { PathTranslator } from "@roblox-ts/path-translator";
export type CopyFilesFileEntry = [src: string, dest: string, srcMtimeMs: number, destMtimeMs: number];
export type CopyFilesDirEntry = [path: string, mtimeMs: number];
export interface CopyFilesManifest {
    version: number;
    compilerVersion: string;
    key: string;
    declaration: boolean;
    files: Array<CopyFilesFileEntry>;
    dirs: Array<CopyFilesDirEntry>;
}
export interface BuildManifestInputs {
    rootDirs: ReadonlyArray<string>;
    outDir: string;
    declaration: boolean;
    key: string;
    pathTranslator: PathTranslator;
}
export declare function buildCopyFilesManifest(inputs: BuildManifestInputs): CopyFilesManifest;
export declare function writeCopyFilesManifest(filePath: string, manifest: CopyFilesManifest): void;
export declare function tryLoadCopyFilesManifest(filePath: string, key: string, declaration: boolean): CopyFilesManifest | undefined;
//# sourceMappingURL=copyFilesManifest.d.ts.map