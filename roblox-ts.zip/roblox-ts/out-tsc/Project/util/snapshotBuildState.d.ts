import type ts from "typescript";
export interface BuildStateSnapshot {
    changedFilePaths: ReadonlySet<string>;
}
export declare function snapshotBuildState(program: ts.BuilderProgram): BuildStateSnapshot;
//# sourceMappingURL=snapshotBuildState.d.ts.map