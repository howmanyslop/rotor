import type { RojoResolver } from "@isentinel/rojo-utils";
import type { RojoResolverCache } from "../classes/RojoResolverCache.ts";
interface LoadInputs {
    rojoConfigPath: string | undefined;
    typeRoots: ReadonlyArray<string>;
    outDir: string;
    nodeModulesPath: string;
}
interface LoadOutputs {
    rojoCacheEntry: {
        resolver: RojoResolver;
        persist: () => void;
    } | undefined;
    typeRootsEntry: {
        resolvers: ReadonlyArray<RojoResolver>;
        persist: () => void;
    };
    persistAll: () => void;
}
export declare function loadRojoCachesPreBuild(cache: RojoResolverCache, inputs: LoadInputs): LoadOutputs;
export {};
//# sourceMappingURL=loadRojoCachesPreBuild.d.ts.map