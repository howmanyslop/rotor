import ts from "typescript";
export interface RunRbxtsEmitOptions {
    readonly program: ts.BuilderProgram;
    readonly compileThunk: (tsProgram: ts.Program) => Promise<ts.EmitResult>;
    readonly solutionEmit?: (writeFile: (fileName: string, text: string, writeByteOrderMark: boolean) => void) => ts.EmitResult | undefined;
}
export interface RunRbxtsEmitResult {
    readonly compileResult: ts.EmitResult;
    readonly preEmitDiagnostics: ReadonlyArray<ts.Diagnostic>;
    readonly emittedSuccessfully: boolean;
}
export declare function runRbxtsEmit(options: RunRbxtsEmitOptions): Promise<RunRbxtsEmitResult>;
//# sourceMappingURL=runRbxtsEmit.d.ts.map