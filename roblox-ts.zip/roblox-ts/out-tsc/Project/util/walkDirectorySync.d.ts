export declare function walkDirectorySync(dir: string, callback: (fsPath: string) => void): void;
//# sourceMappingURL=walkDirectorySync.d.ts.map