import ts from "typescript";
import type { ProjectData } from "../index.ts";
export declare function createProgramFactory(data: ProjectData, options: ts.CompilerOptions): ts.CreateProgram<ts.EmitAndSemanticDiagnosticsBuilderProgram>;
//# sourceMappingURL=createProgramFactory.d.ts.map