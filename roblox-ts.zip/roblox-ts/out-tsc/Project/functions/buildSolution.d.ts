import ts from "typescript";
import type { ProjectOptions } from "../../Shared/types.ts";
export declare function buildSolution(configPath: string, projectOptions: ProjectOptions, buildOptions: ts.BuildOptions): Promise<ts.ExitStatus>;
//# sourceMappingURL=buildSolution.d.ts.map