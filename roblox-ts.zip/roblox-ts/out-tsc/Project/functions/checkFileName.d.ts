export declare function checkFileName(filePath: string): void;
//# sourceMappingURL=checkFileName.d.ts.map