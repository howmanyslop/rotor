import { TraceMap } from "@jridgewell/trace-mapping";
import ts from "typescript";
interface PrintResult {
    text: string;
    traceMap: TraceMap | undefined;
}
export declare function printSourceFileWithTraceMap(sourceFile: ts.SourceFile, compilerOptions: ts.CompilerOptions): PrintResult;
export {};
//# sourceMappingURL=printSourceFileWithTraceMap.d.ts.map