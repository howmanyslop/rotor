import ts from "typescript";
import type { ProjectData } from "../index.ts";
export declare function getParsedCommandLine(data: ProjectData): ts.ParsedCommandLine;
//# sourceMappingURL=getParsedCommandLine.d.ts.map