import type { ProjectData, ProjectOptions } from "../../Shared/types.ts";
export declare function createProjectData(tsConfigPath: string, projectOptions: ProjectOptions): ProjectData;
//# sourceMappingURL=createProjectData.d.ts.map