import type { PathTranslator } from "@roblox-ts/path-translator";
export declare function tryRemoveOutput(pathTranslator: PathTranslator, outPath: string): void;
//# sourceMappingURL=tryRemoveOutput.d.ts.map