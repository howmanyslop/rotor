import type { PathTranslator } from "@roblox-ts/path-translator";
import type { ProjectData } from "../../Shared/types.ts";
export declare function copyFiles(data: ProjectData, pathTranslator: PathTranslator, sources: Set<string>): void;
//# sourceMappingURL=copyFiles.d.ts.map