import ts from "typescript";
export declare function getChangedSourceFiles(program: ts.BuilderProgram, rootDirs: ReadonlyArray<string>, pathHints?: Array<string>): ts.SourceFile[];
//# sourceMappingURL=getChangedSourceFiles.d.ts.map