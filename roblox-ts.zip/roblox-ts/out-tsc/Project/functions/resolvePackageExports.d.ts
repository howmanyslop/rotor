export interface PackageJsonWithExports {
    main?: string;
    types?: string;
    typings?: string;
    exports?: PackageExportsField;
}
type PackageExportsField = string | ExportsConditions | Array<ExportsConditions | string | null> | null;
interface ExportsConditions {
    [key: string]: PackageExportsField;
}
export declare function resolvePackageExports(pkgPath: string, pkgJson: PackageJsonWithExports, customConditions?: ReadonlyArray<string>): Map<string, string>;
export {};
//# sourceMappingURL=resolvePackageExports.d.ts.map