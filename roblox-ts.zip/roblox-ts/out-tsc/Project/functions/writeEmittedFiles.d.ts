export interface PendingWrite {
    readonly path: string;
    readonly data: string;
}
export interface WriteEmittedFilesOptions {
    readonly writeOnlyChanged: boolean;
    readonly concurrency?: number;
    readonly syncCutoff?: number;
    readonly useCaseSensitiveFileNames: boolean;
}
export declare function defaultConcurrency(): number;
export declare function writeEmittedFiles(writes: ReadonlyArray<PendingWrite>, options: WriteEmittedFilesOptions): Promise<ReadonlyArray<string>>;
//# sourceMappingURL=writeEmittedFiles.d.ts.map