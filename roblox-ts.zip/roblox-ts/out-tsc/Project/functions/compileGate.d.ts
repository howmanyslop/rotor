export interface CompileGate {
    trigger: () => void;
    drain: () => Promise<void>;
}
export interface CompileGateOptions {
    readonly runCompile: () => Promise<void>;
    readonly onFailure: (error: unknown) => void;
}
export declare function createCompileGate(options: CompileGateOptions): CompileGate;
//# sourceMappingURL=compileGate.d.ts.map