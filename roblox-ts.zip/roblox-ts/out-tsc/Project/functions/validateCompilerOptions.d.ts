import ts from "typescript";
export declare function validateCompilerOptions(opts: ts.CompilerOptions, projectPath: string): void;
//# sourceMappingURL=validateCompilerOptions.d.ts.map