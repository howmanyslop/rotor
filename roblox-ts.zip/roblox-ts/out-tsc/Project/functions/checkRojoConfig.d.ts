import type { RojoResolver } from "@isentinel/rojo-utils";
import type { PathTranslator } from "@roblox-ts/path-translator";
import type { ProjectData } from "../index.ts";
export declare function checkRojoConfig(data: ProjectData, rojoResolver: RojoResolver, rootDirs: ReadonlyArray<string>, pathTranslator: PathTranslator): void;
//# sourceMappingURL=checkRojoConfig.d.ts.map