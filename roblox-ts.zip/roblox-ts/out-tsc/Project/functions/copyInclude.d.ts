import type { ProjectData } from "../../Shared/types.ts";
export declare function copyInclude(data: ProjectData): void;
//# sourceMappingURL=copyInclude.d.ts.map