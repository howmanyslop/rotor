import type { PathTranslator } from "@roblox-ts/path-translator";
import ts from "typescript";
import type { ProjectData } from "../../Shared/types.ts";
export declare function compileFiles(program: ts.Program, data: ProjectData, pathTranslator: PathTranslator, sourceFiles: Array<ts.SourceFile>, importPathMap?: ReadonlyMap<string, string>): Promise<ts.EmitResult>;
//# sourceMappingURL=compileFiles.d.ts.map