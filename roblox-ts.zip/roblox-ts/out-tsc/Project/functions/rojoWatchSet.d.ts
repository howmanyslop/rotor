import type { RojoResolver } from "@isentinel/rojo-utils";
import type ts from "typescript";
export type WatchHostSubset = Pick<ts.WatchHost, "watchFile" | "watchDirectory">;
export interface RegisterRojoWatchersOptions {
    readonly host: WatchHostSubset;
    readonly resolver: RojoResolver;
    readonly onInvalidate: () => void;
}
export declare function registerRojoWatchers(options: RegisterRojoWatchersOptions): () => void;
//# sourceMappingURL=rojoWatchSet.d.ts.map