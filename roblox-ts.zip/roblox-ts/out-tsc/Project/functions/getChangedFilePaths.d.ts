import ts from "typescript";
export declare function getChangedFilePaths(program: ts.BuilderProgram, pathHints?: Array<string>): Set<string>;
//# sourceMappingURL=getChangedFilePaths.d.ts.map