import type { PathTranslator } from "@roblox-ts/path-translator";
export declare function cleanup(pathTranslator: PathTranslator): void;
//# sourceMappingURL=cleanup.d.ts.map