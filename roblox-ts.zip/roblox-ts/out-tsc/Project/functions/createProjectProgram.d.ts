import type ts from "typescript";
import type { ProjectData } from "../../Shared/types.ts";
export declare function createProjectProgram(data: ProjectData, host?: ts.CompilerHost): ts.EmitAndSemanticDiagnosticsBuilderProgram;
//# sourceMappingURL=createProjectProgram.d.ts.map