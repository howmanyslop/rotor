import { PathTranslator } from "@roblox-ts/path-translator";
import ts from "typescript";
import type { ProjectData } from "../../Shared/types.ts";
export declare function createPathTranslator(program: ts.BuilderProgram, data: ProjectData): PathTranslator;
//# sourceMappingURL=createPathTranslator.d.ts.map