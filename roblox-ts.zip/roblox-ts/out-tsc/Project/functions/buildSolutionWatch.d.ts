import ts from "typescript";
import type { ProjectOptions } from "../../Shared/types.ts";
export interface BuildSolutionWatchTestHooks {
    readonly onDrainComplete?: () => void;
    readonly onAssetDrainComplete?: () => void;
    readonly onReady?: () => void;
}
export interface BuildSolutionWatchOptions {
    readonly testHooks?: BuildSolutionWatchTestHooks;
    readonly shutdown?: Promise<void>;
}
export declare function buildSolutionWatch(configPath: string, projectOptions: ProjectOptions, buildOptions: ts.BuildOptions, watchOptions?: BuildSolutionWatchOptions): Promise<void>;
//# sourceMappingURL=buildSolutionWatch.d.ts.map