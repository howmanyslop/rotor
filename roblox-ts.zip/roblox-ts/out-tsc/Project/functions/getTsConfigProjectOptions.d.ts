import type { ProjectOptions } from "../../Shared/types.ts";
export declare const rbxtsTsConfigSchema: import("arktype/internal/variants/object.ts").ObjectType<{
    allowCommentDirectives?: boolean | undefined;
    includePath?: string | undefined;
    logTruthyChanges?: boolean | undefined;
    luau?: boolean | undefined;
    noInclude?: boolean | undefined;
    optimizedLoops?: boolean | undefined;
    rojo?: string | undefined;
    type?: "game" | "model" | "package" | undefined;
}, {}>;
export declare const RBXTS_TSCONFIG_KEYS: ReadonlySet<string>;
export declare function getTsConfigProjectOptions(tsConfigPath: string, visitedOut?: Set<string>): Partial<ProjectOptions> | undefined;
//# sourceMappingURL=getTsConfigProjectOptions.d.ts.map