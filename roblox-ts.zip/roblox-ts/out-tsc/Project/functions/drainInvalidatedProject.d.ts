import type { RojoResolver } from "@isentinel/rojo-utils";
import type { PathTranslator } from "@roblox-ts/path-translator";
import ts from "typescript";
import type { ProjectData, ProjectOptions } from "../../Shared/types.ts";
export interface LoadedResolverInfo {
    readonly project: string;
    readonly kind: "fromPath" | "synthetic";
    readonly key: string;
    readonly resolver: RojoResolver;
}
export interface DrainContext {
    readonly projectOptions: ProjectOptions;
    readonly resolvedConfigPath: string;
    readonly isSolutionCoordinator: boolean;
    readonly importPathMap: Map<string, string>;
    readonly pendingRojoCachePersists: Array<() => void>;
    readonly pendingCopyFilesPersists: Array<() => void>;
    readonly diagnosticReporter: ts.DiagnosticReporter;
    readonly onProjectDrainStart?: (project: string) => void;
    readonly onResolverLoaded?: (info: LoadedResolverInfo) => void;
    readonly onProjectRootDirsResolved?: (project: string, rootDirs: ReadonlyArray<string>) => void;
    readonly onProjectArtifactsResolved?: (project: string, data: ProjectData, pathTranslator: PathTranslator) => void;
    readonly importPathMapOwnership?: Map<string, Set<string>>;
}
export interface DrainOutcome {
    readonly hadErrors: boolean;
    readonly skipped: boolean;
}
export declare function drainInvalidatedProject(project: ts.InvalidatedProject<ts.EmitAndSemanticDiagnosticsBuilderProgram>, ctx: DrainContext): Promise<DrainOutcome>;
//# sourceMappingURL=drainInvalidatedProject.d.ts.map