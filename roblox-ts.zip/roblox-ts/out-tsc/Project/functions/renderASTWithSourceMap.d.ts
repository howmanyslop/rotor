import luau from "@roblox-ts/luau-ast";
import type { SourcePosition } from "../../Shared/types.ts";
export declare function renderASTWithSourceMap(ast: luau.List<luau.Statement>, sourcePositionMap: WeakMap<luau.Node, SourcePosition>, sourceEndPositionMap: WeakMap<luau.Node, SourcePosition>, sourceFileName: string, outputFileName: string, sourceContent?: string): {
    code: string;
    map: import("@jridgewell/gen-mapping").EncodedSourceMap;
};
//# sourceMappingURL=renderASTWithSourceMap.d.ts.map