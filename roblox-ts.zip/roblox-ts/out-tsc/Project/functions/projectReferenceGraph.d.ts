import ts from "typescript";
export interface ProjectReferenceGraph {
    dependentsOf(project: string): ReadonlySet<string>;
}
export interface ProjectReferenceGraphHost {
    getParsedCommandLine(fileName: string): ts.ParsedCommandLine | undefined;
}
export declare function buildProjectReferenceGraph(builder: ts.SolutionBuilder<ts.EmitAndSemanticDiagnosticsBuilderProgram>, host: ProjectReferenceGraphHost): ProjectReferenceGraph;
//# sourceMappingURL=projectReferenceGraph.d.ts.map