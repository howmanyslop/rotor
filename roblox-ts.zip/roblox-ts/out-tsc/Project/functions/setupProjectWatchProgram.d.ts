import type { ProjectData } from "../index.ts";
export declare function setupProjectWatchProgram(data: ProjectData, usePolling: boolean, tsConfigChain?: Iterable<string>): Promise<boolean>;
//# sourceMappingURL=setupProjectWatchProgram.d.ts.map