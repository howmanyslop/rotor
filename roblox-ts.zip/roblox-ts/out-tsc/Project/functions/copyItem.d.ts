import type { PathTranslator } from "@roblox-ts/path-translator";
import type { ProjectData } from "../index.ts";
export declare function copyItem(data: ProjectData, pathTranslator: PathTranslator, item: string): void;
//# sourceMappingURL=copyItem.d.ts.map