import { RojoResolver } from "@isentinel/rojo-utils";
interface ResolverFactory {
    fromPath: (configPath: string) => RojoResolver;
    synthetic: (basePath: string) => RojoResolver;
}
export declare class RojoResolverCache {
    private fromPathCache;
    private syntheticCache;
    private resolverFactory;
    private statFile;
    constructor(resolverFactory?: ResolverFactory, statFile?: (p: string) => {
        mtimeMs: number;
    });
    getFromPath(configPath: string): RojoResolver;
    getSynthetic(basePath: string): RojoResolver;
    getFromPathWithDiskCache(configPath: string, cacheFilePath: string): {
        resolver: RojoResolver;
        persist: () => void;
    };
    getSyntheticBatchWithDiskCache(basePaths: ReadonlyArray<string>, cacheFilePath: string, sentinelPath?: string): {
        resolvers: ReadonlyArray<RojoResolver>;
        persist: () => void;
    };
    private tryLoadSyntheticBatch;
    private writeSyntheticBatch;
    invalidate(configPath: string): void;
    invalidateAll(): void;
    invalidateSynthetic(basePath: string): void;
    invalidateAllSynthetic(): void;
}
export declare const rojoResolverCache: RojoResolverCache;
export {};
//# sourceMappingURL=RojoResolverCache.d.ts.map