import type { ConstructorMacro, MacroList } from "./types.ts";
export declare const CONSTRUCTOR_MACROS: MacroList<ConstructorMacro>;
//# sourceMappingURL=constructorMacros.d.ts.map