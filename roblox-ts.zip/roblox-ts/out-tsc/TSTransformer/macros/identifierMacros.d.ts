import type { IdentifierMacro, MacroList } from "./types.ts";
export declare const IDENTIFIER_MACROS: MacroList<IdentifierMacro>;
//# sourceMappingURL=identifierMacros.d.ts.map