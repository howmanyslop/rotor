import type { MacroList, PropertyCallMacro } from "./types.ts";
export declare const PROPERTY_CALL_MACROS: {
    [className: string]: MacroList<PropertyCallMacro>;
};
//# sourceMappingURL=propertyCallMacros.d.ts.map