import type { CallMacro, MacroList } from "./types.ts";
export declare const CALL_MACROS: MacroList<CallMacro>;
//# sourceMappingURL=callMacros.d.ts.map