import type { MacroManager } from "./index.ts";
export interface TransformServices {
    macroManager: MacroManager;
}
export interface TryUses {
    usesReturn: boolean;
    usesBreak: boolean;
    usesContinue: boolean;
}
//# sourceMappingURL=types.d.ts.map