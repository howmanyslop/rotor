export * from "./classes/MacroManager.ts";
export * from "./classes/MultiTransformState.ts";
export * from "./classes/TransformState.ts";
export { transformSourceFile } from "./nodes/transformSourceFile.ts";
//# sourceMappingURL=index.d.ts.map