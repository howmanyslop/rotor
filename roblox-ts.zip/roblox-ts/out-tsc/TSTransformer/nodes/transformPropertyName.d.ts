import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function transformPropertyName(state: TransformState, name: ts.PropertyName): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformPropertyName.d.ts.map