import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
export declare function transformInterpolatedStringPart(node: ts.TemplateLiteralToken | ts.StringLiteral): luau.InterpolatedStringPart;
//# sourceMappingURL=transformInterpolatedStringPart.d.ts.map