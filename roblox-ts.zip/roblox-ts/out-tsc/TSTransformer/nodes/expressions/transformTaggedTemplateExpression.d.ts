import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformTaggedTemplateExpression(state: TransformState, node: ts.TaggedTemplateExpression): luau.CallExpression;
//# sourceMappingURL=transformTaggedTemplateExpression.d.ts.map