import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformBinaryExpression(state: TransformState, node: ts.BinaryExpression): luau.Array | luau.BinaryExpression | luau.CallExpression | luau.ComputedIndexExpression | luau.FalseLiteral | luau.FunctionExpression | luau.Identifier | luau.IfExpression | luau.InterpolatedString | luau.Map | luau.MethodCallExpression | luau.MixedTable | luau.NilLiteral | luau.None | luau.NumberLiteral | luau.ParenthesizedExpression | luau.PropertyAccessExpression | luau.Set | luau.StringLiteral | luau.TemporaryIdentifier | luau.TrueLiteral | luau.UnaryExpression | luau.VarArgsLiteral;
//# sourceMappingURL=transformBinaryExpression.d.ts.map