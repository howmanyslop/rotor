import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformVoidExpression(state: TransformState, node: ts.VoidExpression): luau.NilLiteral;
//# sourceMappingURL=transformVoidExpression.d.ts.map