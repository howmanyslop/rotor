import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformFunctionExpression(state: TransformState, node: ts.FunctionExpression | ts.ArrowFunction): luau.CallExpression | luau.FunctionExpression;
//# sourceMappingURL=transformFunctionExpression.d.ts.map