import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformDeleteExpression(state: TransformState, node: ts.DeleteExpression): luau.FalseLiteral | luau.None | luau.TrueLiteral;
//# sourceMappingURL=transformDeleteExpression.d.ts.map