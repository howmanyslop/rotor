import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsxSelfClosingElement(state: TransformState, node: ts.JsxSelfClosingElement): import("@roblox-ts/luau-ast/out/LuauAST/bundle").CallExpression;
//# sourceMappingURL=transformJsxSelfClosingElement.d.ts.map