import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformIdentifierDefined(state: TransformState, node: ts.Identifier): luau.Identifier | luau.TemporaryIdentifier;
export declare function transformIdentifier(state: TransformState, node: ts.Identifier): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformIdentifier.d.ts.map