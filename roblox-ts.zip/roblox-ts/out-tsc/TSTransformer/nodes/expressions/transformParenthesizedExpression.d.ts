import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformParenthesizedExpression(state: TransformState, node: ts.ParenthesizedExpression): luau.FalseLiteral | luau.Identifier | luau.NilLiteral | luau.NumberLiteral | luau.ParenthesizedExpression | luau.StringLiteral | luau.TemporaryIdentifier | luau.TrueLiteral;
//# sourceMappingURL=transformParenthesizedExpression.d.ts.map