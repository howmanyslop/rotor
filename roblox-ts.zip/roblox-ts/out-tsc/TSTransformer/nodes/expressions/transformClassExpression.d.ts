import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformClassExpression(state: TransformState, node: ts.ClassExpression): import("@roblox-ts/luau-ast/out/LuauAST/bundle").Identifier | import("@roblox-ts/luau-ast/out/LuauAST/bundle").TemporaryIdentifier;
//# sourceMappingURL=transformClassExpression.d.ts.map