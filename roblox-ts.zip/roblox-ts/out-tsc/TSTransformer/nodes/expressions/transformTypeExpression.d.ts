import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformTypeExpression(state: TransformState, node: ts.AsExpression | ts.NonNullExpression | ts.SatisfiesExpression | ts.TypeAssertion | ts.ExpressionWithTypeArguments): import("@roblox-ts/luau-ast/out/LuauAST/bundle").Expression<import("@roblox-ts/luau-ast/out/LuauAST/bundle").SyntaxKind>;
//# sourceMappingURL=transformTypeExpression.d.ts.map