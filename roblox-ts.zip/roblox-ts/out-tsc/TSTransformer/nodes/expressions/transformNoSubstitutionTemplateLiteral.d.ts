import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function transformNoSubstitutionTemplateLiteral(state: TransformState, node: ts.NoSubstitutionTemplateLiteral): luau.InterpolatedString;
//# sourceMappingURL=transformNoSubstitutionTemplateLiteral.d.ts.map