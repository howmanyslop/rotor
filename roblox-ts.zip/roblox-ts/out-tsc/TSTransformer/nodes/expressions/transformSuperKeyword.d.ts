import luau from "@roblox-ts/luau-ast";
export declare function transformSuperKeyword(): luau.Identifier;
//# sourceMappingURL=transformSuperKeyword.d.ts.map