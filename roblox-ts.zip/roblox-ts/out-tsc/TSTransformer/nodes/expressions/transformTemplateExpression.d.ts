import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformTemplateExpression(state: TransformState, node: ts.TemplateExpression): luau.InterpolatedString;
//# sourceMappingURL=transformTemplateExpression.d.ts.map