import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function transformYieldExpression(state: TransformState, node: ts.YieldExpression): luau.CallExpression | luau.None | luau.TemporaryIdentifier;
//# sourceMappingURL=transformYieldExpression.d.ts.map