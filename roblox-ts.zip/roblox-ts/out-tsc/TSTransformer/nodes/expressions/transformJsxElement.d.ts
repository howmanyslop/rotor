import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsxElement(state: TransformState, node: ts.JsxElement): import("@roblox-ts/luau-ast/out/LuauAST/bundle").CallExpression;
//# sourceMappingURL=transformJsxElement.d.ts.map