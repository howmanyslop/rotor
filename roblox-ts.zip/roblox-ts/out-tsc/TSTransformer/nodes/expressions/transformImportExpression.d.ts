import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function transformImportExpression(state: TransformState, node: ts.CallExpression): luau.CallExpression | luau.None;
//# sourceMappingURL=transformImportExpression.d.ts.map