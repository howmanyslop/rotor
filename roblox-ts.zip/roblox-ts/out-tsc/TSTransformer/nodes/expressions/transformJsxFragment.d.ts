import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsxFragment(state: TransformState, node: ts.JsxFragment): luau.CallExpression;
//# sourceMappingURL=transformJsxFragment.d.ts.map