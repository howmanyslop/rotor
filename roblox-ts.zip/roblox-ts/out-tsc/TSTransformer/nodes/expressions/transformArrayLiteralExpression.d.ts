import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformArrayLiteralExpression(state: TransformState, node: ts.ArrayLiteralExpression): luau.Array | luau.TemporaryIdentifier;
//# sourceMappingURL=transformArrayLiteralExpression.d.ts.map