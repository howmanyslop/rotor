import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformNewExpression(state: TransformState, node: ts.NewExpression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformNewExpression.d.ts.map