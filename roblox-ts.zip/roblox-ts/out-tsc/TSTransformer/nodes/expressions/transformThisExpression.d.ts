import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformThisExpression(state: TransformState, node: ts.ThisExpression): luau.AnyIdentifier;
//# sourceMappingURL=transformThisExpression.d.ts.map