import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsxExpression(state: TransformState, node: ts.JsxExpression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformJsxExpression.d.ts.map