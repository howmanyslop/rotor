import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformObjectLiteralExpression(state: TransformState, node: ts.ObjectLiteralExpression): luau.Map | luau.TemporaryIdentifier;
//# sourceMappingURL=transformObjectLiteralExpression.d.ts.map