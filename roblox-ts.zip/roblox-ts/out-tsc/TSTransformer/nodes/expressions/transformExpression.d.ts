import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformExpression(state: TransformState, node: ts.Expression): luau.Expression;
//# sourceMappingURL=transformExpression.d.ts.map