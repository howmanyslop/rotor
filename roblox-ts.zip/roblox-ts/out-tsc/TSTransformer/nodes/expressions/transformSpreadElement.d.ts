import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformSpreadElement(state: TransformState, node: ts.SpreadElement): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformSpreadElement.d.ts.map