import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformAwaitExpression(state: TransformState, node: ts.AwaitExpression): luau.CallExpression;
//# sourceMappingURL=transformAwaitExpression.d.ts.map