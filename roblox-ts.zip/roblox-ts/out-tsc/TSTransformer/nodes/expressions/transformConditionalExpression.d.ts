import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformConditionalExpression(state: TransformState, node: ts.ConditionalExpression): luau.IfExpression | luau.None | luau.TemporaryIdentifier;
//# sourceMappingURL=transformConditionalExpression.d.ts.map