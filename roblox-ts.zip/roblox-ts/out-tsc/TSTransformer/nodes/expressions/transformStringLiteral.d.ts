import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformStringLiteral(state: TransformState, node: ts.StringLiteral): luau.StringLiteral;
//# sourceMappingURL=transformStringLiteral.d.ts.map