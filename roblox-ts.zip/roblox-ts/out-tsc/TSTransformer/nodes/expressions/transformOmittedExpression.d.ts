import luau from "@roblox-ts/luau-ast";
export declare function transformOmittedExpression(): luau.NilLiteral;
//# sourceMappingURL=transformOmittedExpression.d.ts.map