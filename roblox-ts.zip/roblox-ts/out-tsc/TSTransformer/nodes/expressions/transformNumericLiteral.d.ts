import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformNumericLiteral(state: TransformState, node: ts.NumericLiteral): luau.NumberLiteral;
//# sourceMappingURL=transformNumericLiteral.d.ts.map