import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformElementAccessExpressionInner(state: TransformState, node: ts.ElementAccessExpression, expression: luau.Expression, argumentExpression: ts.Expression): luau.Expression<luau.SyntaxKind>;
export declare function transformElementAccessExpression(state: TransformState, node: ts.ElementAccessExpression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformElementAccessExpression.d.ts.map