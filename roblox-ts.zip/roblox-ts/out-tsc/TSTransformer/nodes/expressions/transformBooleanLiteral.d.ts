import luau from "@roblox-ts/luau-ast";
export declare function transformTrueKeyword(): luau.TrueLiteral;
export declare function transformFalseKeyword(): luau.FalseLiteral;
//# sourceMappingURL=transformBooleanLiteral.d.ts.map