import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function transformInitializer(state: TransformState, id: luau.WritableExpression, initializer: ts.Expression): luau.IfStatement;
//# sourceMappingURL=transformInitializer.d.ts.map