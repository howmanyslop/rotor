import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformThrowStatement(state: TransformState, node: ts.ThrowStatement): luau.List<luau.CallStatement>;
//# sourceMappingURL=transformThrowStatement.d.ts.map