import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformExportAssignment(state: TransformState, node: ts.ExportAssignment): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformExportAssignment.d.ts.map