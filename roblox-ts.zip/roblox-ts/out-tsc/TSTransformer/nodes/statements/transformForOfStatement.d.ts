import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformForOfRangeMacro(state: TransformState, node: ts.ForOfStatement, macroCall: ts.CallExpression): luau.List<luau.Statement>;
export declare function transformForOfStatement(state: TransformState, node: ts.ForOfStatement): luau.List<luau.Statement>;
//# sourceMappingURL=transformForOfStatement.d.ts.map