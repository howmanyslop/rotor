import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformWhileStatement(state: TransformState, node: ts.WhileStatement): luau.List<luau.WhileStatement>;
//# sourceMappingURL=transformWhileStatement.d.ts.map