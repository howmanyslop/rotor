import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformEnumDeclaration(state: TransformState, node: ts.EnumDeclaration): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformEnumDeclaration.d.ts.map