import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformReturnStatementInner(state: TransformState, returnExp: ts.Expression): luau.List<luau.Statement>;
export declare function transformReturnStatement(state: TransformState, node: ts.ReturnStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformReturnStatement.d.ts.map