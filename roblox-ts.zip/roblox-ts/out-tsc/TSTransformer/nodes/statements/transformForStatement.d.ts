import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformForStatement(state: TransformState, node: ts.ForStatement): luau.List<luau.Statement>;
//# sourceMappingURL=transformForStatement.d.ts.map