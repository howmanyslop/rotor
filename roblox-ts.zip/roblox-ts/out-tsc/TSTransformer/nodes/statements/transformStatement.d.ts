import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformStatement(state: TransformState, node: ts.Statement): luau.List<luau.Statement>;
//# sourceMappingURL=transformStatement.d.ts.map