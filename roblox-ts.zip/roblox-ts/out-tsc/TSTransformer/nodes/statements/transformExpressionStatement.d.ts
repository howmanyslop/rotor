import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformExpressionStatementInner(state: TransformState, expression: ts.Expression): luau.List<luau.Statement>;
export declare function transformExpressionStatement(state: TransformState, node: ts.ExpressionStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformExpressionStatement.d.ts.map