import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformImportEqualsDeclaration(state: TransformState, node: ts.ImportEqualsDeclaration): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformImportEqualsDeclaration.d.ts.map