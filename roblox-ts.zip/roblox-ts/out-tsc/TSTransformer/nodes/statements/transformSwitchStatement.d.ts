import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformSwitchStatement(state: TransformState, node: ts.SwitchStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformSwitchStatement.d.ts.map