import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformBlock(state: TransformState, node: ts.Block): luau.List<luau.DoStatement>;
//# sourceMappingURL=transformBlock.d.ts.map