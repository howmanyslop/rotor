import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformIfStatementInner(state: TransformState, node: ts.IfStatement): luau.IfStatement;
export declare function transformIfStatement(state: TransformState, node: ts.IfStatement): luau.List<luau.IfStatement>;
//# sourceMappingURL=transformIfStatement.d.ts.map