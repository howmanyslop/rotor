import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformContinueStatement(state: TransformState, node: ts.ContinueStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformContinueStatement.d.ts.map