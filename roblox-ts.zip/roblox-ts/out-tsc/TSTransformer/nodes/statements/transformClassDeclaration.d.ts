import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformClassDeclaration(state: TransformState, node: ts.ClassDeclaration): import("@roblox-ts/luau-ast/out/LuauAST/bundle").List<import("@roblox-ts/luau-ast/out/LuauAST/bundle").Statement<import("@roblox-ts/luau-ast/out/LuauAST/bundle").SyntaxKind>>;
//# sourceMappingURL=transformClassDeclaration.d.ts.map