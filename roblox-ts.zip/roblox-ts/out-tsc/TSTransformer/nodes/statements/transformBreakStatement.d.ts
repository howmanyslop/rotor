import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformBreakStatement(state: TransformState, node: ts.BreakStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformBreakStatement.d.ts.map