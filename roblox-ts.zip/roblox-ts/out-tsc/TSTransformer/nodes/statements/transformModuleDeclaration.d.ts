import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformModuleDeclaration(state: TransformState, node: ts.ModuleDeclaration): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformModuleDeclaration.d.ts.map