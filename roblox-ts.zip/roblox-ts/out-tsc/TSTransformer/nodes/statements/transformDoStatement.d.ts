import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformDoStatement(state: TransformState, { expression, statement }: ts.DoStatement): luau.List<luau.RepeatStatement>;
//# sourceMappingURL=transformDoStatement.d.ts.map