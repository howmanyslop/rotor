import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformTryStatement(state: TransformState, node: ts.TryStatement): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformTryStatement.d.ts.map