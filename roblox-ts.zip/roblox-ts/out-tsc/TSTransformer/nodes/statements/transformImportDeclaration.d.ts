import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformImportDeclaration(state: TransformState, node: ts.ImportDeclaration): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformImportDeclaration.d.ts.map