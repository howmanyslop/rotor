import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformFunctionDeclaration(state: TransformState, node: ts.FunctionDeclaration): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformFunctionDeclaration.d.ts.map