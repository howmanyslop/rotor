import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
import type { Pointer } from "../util/pointer.ts";
export declare function transformMethodDeclaration(state: TransformState, node: ts.MethodDeclaration, ptr: Pointer<luau.Map | luau.AnyIdentifier>): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformMethodDeclaration.d.ts.map