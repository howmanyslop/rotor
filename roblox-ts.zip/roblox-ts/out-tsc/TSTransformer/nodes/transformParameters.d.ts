import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
import type { VarArgsData } from "../util/varArgsHelpers.ts";
export type FunctionLikeWithBody = (ts.FunctionDeclaration & {
    body: ts.FunctionBody;
}) | (ts.FunctionExpression & {
    body: ts.FunctionBody;
}) | ts.ArrowFunction | (ts.MethodDeclaration & {
    body: ts.FunctionBody;
}) | (ts.ConstructorDeclaration & {
    body: ts.FunctionBody;
});
export declare function transformParameters(state: TransformState, node: ts.SignatureDeclarationBase): {
    parameters: luau.List<luau.AnyIdentifier>;
    statements: luau.List<luau.Statement<luau.SyntaxKind>>;
    hasDotDotDot: boolean;
    varArgsData: VarArgsData | undefined;
};
//# sourceMappingURL=transformParameters.d.ts.map