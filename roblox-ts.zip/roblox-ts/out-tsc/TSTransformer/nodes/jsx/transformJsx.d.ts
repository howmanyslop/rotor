import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsx(state: TransformState, node: ts.JsxElement | ts.JsxSelfClosingElement, tagName: ts.JsxTagNameExpression, attributes: ts.JsxAttributes, children: ReadonlyArray<ts.JsxChild>): luau.CallExpression;
//# sourceMappingURL=transformJsx.d.ts.map