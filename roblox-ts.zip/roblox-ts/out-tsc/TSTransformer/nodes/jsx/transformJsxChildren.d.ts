import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function transformJsxChildren(state: TransformState, children: ReadonlyArray<ts.JsxChild>): luau.Expression<luau.SyntaxKind>[];
//# sourceMappingURL=transformJsxChildren.d.ts.map