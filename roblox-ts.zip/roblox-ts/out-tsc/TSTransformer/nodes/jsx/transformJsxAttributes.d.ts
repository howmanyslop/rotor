import ts from "typescript";
import type { TransformState } from "../../index.ts";
import type { MapPointer } from "../../util/pointer.ts";
export declare function transformJsxAttributes(state: TransformState, attributes: ts.JsxAttributes, attributesPtr: MapPointer): void;
//# sourceMappingURL=transformJsxAttributes.d.ts.map