import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformJsxTagName(state: TransformState, tagName: ts.JsxTagNameExpression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformJsxTagName.d.ts.map