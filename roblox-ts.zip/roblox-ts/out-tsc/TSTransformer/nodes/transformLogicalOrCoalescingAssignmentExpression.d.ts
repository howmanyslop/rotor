import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function transformLogicalOrCoalescingAssignmentExpression(state: TransformState, node: ts.AssignmentExpression<ts.Token<ts.LogicalOrCoalescingAssignmentOperator>>): luau.WritableExpression;
export declare function transformLogicalOrCoalescingAssignmentExpressionStatement(state: TransformState, node: ts.AssignmentExpression<ts.Token<ts.LogicalOrCoalescingAssignmentOperator>>): luau.List<luau.Statement>;
//# sourceMappingURL=transformLogicalOrCoalescingAssignmentExpression.d.ts.map