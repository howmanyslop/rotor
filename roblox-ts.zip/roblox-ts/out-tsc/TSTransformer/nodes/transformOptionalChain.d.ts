import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
declare const OptionalChainItemKind: {
    readonly PropertyAccess: 0;
    readonly ElementAccess: 1;
    readonly Call: 2;
    readonly PropertyCall: 3;
    readonly ElementCall: 4;
};
type OptionalChainItemKind = (typeof OptionalChainItemKind)[keyof typeof OptionalChainItemKind];
interface OptionalChainItem<T extends OptionalChainItemKind, U extends ts.Expression> {
    kind: T;
    node: U;
    optional: boolean;
    type: ts.Type;
}
interface PropertyAccessItem extends OptionalChainItem<typeof OptionalChainItemKind.PropertyAccess, ts.PropertyAccessExpression> {
    name: string;
}
interface ElementAccessItem extends OptionalChainItem<typeof OptionalChainItemKind.ElementAccess, ts.ElementAccessExpression> {
    expression: ts.Expression;
}
interface CallItem extends OptionalChainItem<typeof OptionalChainItemKind.Call, ts.CallExpression> {
    args: ReadonlyArray<ts.Expression>;
}
interface PropertyCallItem extends OptionalChainItem<typeof OptionalChainItemKind.PropertyCall, ts.CallExpression> {
    expression: ts.PropertyAccessExpression;
    name: string;
    callOptional: boolean;
    callType: ts.Type;
    args: ReadonlyArray<ts.Expression>;
}
interface ElementCallItem extends OptionalChainItem<typeof OptionalChainItemKind.ElementCall, ts.CallExpression> {
    expression: ts.ElementAccessExpression;
    argumentExpression: ts.Expression;
    callOptional: boolean;
    callType: ts.Type;
    args: ReadonlyArray<ts.Expression>;
}
type ChainItem = PropertyAccessItem | ElementAccessItem | CallItem | PropertyCallItem | ElementCallItem;
export declare function flattenOptionalChain(state: TransformState, expression: ts.Expression): {
    chain: ChainItem[];
    expression: ts.Expression;
};
export declare function transformOptionalChain(state: TransformState, node: ts.PropertyAccessExpression | ts.ElementAccessExpression | ts.CallExpression): luau.Expression;
export {};
//# sourceMappingURL=transformOptionalChain.d.ts.map