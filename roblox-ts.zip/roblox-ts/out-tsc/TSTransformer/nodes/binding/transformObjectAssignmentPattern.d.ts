import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformObjectAssignmentPattern(state: TransformState, assignmentPattern: ts.ObjectLiteralExpression, parentId: luau.AnyIdentifier): void;
//# sourceMappingURL=transformObjectAssignmentPattern.d.ts.map