import type luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformArrayBindingPattern(state: TransformState, bindingPattern: ts.ArrayBindingPattern, parentId: luau.AnyIdentifier): void;
//# sourceMappingURL=transformArrayBindingPattern.d.ts.map