import type luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformObjectBindingPattern(state: TransformState, bindingPattern: ts.ObjectBindingPattern, parentId: luau.AnyIdentifier): void;
//# sourceMappingURL=transformObjectBindingPattern.d.ts.map