import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformBindingName(state: TransformState, name: ts.BindingName, initializers: luau.List<luau.Statement>): luau.AnyIdentifier;
//# sourceMappingURL=transformBindingName.d.ts.map