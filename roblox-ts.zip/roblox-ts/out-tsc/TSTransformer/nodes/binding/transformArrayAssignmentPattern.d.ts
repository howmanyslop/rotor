import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformArrayAssignmentPattern(state: TransformState, assignmentPattern: ts.ArrayLiteralExpression, parentId: luau.AnyIdentifier): void;
//# sourceMappingURL=transformArrayAssignmentPattern.d.ts.map