import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function transformLogical(state: TransformState, node: ts.BinaryExpression): luau.Expression;
//# sourceMappingURL=transformLogical.d.ts.map