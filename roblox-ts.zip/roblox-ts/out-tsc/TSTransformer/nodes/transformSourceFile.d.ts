import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function transformSourceFile(state: TransformState, node: ts.SourceFile): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformSourceFile.d.ts.map