import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformClassLikeDeclaration(state: TransformState, node: ts.ClassLikeDeclaration): {
    statements: luau.List<luau.Statement<luau.SyntaxKind>>;
    name: luau.Identifier | luau.TemporaryIdentifier;
};
//# sourceMappingURL=transformClassLikeDeclaration.d.ts.map