import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformPropertyDeclaration(state: TransformState, node: ts.PropertyDeclaration, name: luau.AnyIdentifier): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=transformPropertyDeclaration.d.ts.map