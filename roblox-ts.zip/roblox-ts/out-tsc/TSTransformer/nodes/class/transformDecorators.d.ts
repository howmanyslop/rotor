import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare function transformDecorators(state: TransformState, node: ts.ClassLikeDeclaration, classId: luau.AnyIdentifier): luau.List<luau.Statement>;
//# sourceMappingURL=transformDecorators.d.ts.map