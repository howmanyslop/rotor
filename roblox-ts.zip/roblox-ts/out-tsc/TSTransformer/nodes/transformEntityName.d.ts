import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function transformEntityName(state: TransformState, node: ts.EntityName): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=transformEntityName.d.ts.map