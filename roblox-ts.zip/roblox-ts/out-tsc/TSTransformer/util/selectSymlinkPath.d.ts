export declare function selectSymlinkPath(symlinks: ReadonlyArray<string> | undefined, nodeModulesPath: string): string | undefined;
//# sourceMappingURL=selectSymlinkPath.d.ts.map