import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function validateMethodAssignment(state: TransformState, node: ts.ObjectLiteralElementLike | ts.ClassElement): void;
//# sourceMappingURL=validateMethodAssignment.d.ts.map