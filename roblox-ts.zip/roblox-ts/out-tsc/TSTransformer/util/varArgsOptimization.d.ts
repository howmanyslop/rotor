import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export { createSelectLengthCall, handleVarArgsParameterOptimization, simplifyUnpackOfArray, type VarArgsData, } from "./varArgsHelpers.ts";
import type { VarArgsData } from "./varArgsHelpers.ts";
export declare function analyzeVarArgsOptimization(typeChecker: ts.TypeChecker, parameter: ts.ParameterDeclaration, functionNode: ts.Node): VarArgsData | undefined;
export declare function tryHandleVarArgsArraySpread(state: TransformState, node: ts.SpreadElement): luau.Expression | undefined;
export declare function tryHandleVarArgsIndexableExpression(state: TransformState, node: ts.ElementAccessExpression, index: luau.Expression): luau.Expression | undefined;
export declare function tryHandleVarArgsCallMacro(state: TransformState, node: ts.CallExpression): luau.Expression | undefined;
export declare function transformVarArgsForOfResult(state: TransformState, node: ts.ForOfStatement, result: luau.List<luau.Statement>): luau.List<luau.Statement>;
//# sourceMappingURL=varArgsOptimization.d.ts.map