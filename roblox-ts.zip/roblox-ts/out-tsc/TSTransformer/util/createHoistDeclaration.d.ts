import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function createHoistDeclaration(state: TransformState, statement: ts.Statement | ts.CaseClause): luau.VariableDeclaration | undefined;
//# sourceMappingURL=createHoistDeclaration.d.ts.map