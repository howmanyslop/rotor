import luau from "@roblox-ts/luau-ast";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function spreadDestructureSet(state: TransformState, parentId: luau.AnyIdentifier, index: number, idStack: Array<luau.AnyIdentifier>): luau.TemporaryIdentifier;
//# sourceMappingURL=spreadDestructureSet.d.ts.map