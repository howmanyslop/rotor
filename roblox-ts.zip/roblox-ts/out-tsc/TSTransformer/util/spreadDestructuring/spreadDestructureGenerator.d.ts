import luau from "@roblox-ts/luau-ast";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function spreadDestructureGenerator(state: TransformState, parentId: luau.AnyIdentifier): luau.TemporaryIdentifier;
//# sourceMappingURL=spreadDestructureGenerator.d.ts.map