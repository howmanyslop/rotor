import luau from "@roblox-ts/luau-ast";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function spreadDestructureObject(state: TransformState, parentId: luau.AnyIdentifier, preSpreadNames: Array<luau.Expression>): luau.TemporaryIdentifier;
//# sourceMappingURL=spreadDestructureObject.d.ts.map