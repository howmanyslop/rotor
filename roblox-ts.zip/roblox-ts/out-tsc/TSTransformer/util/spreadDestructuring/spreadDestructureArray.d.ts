import luau from "@roblox-ts/luau-ast";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function spreadDestructureArray(state: TransformState, parentId: luau.AnyIdentifier, index: number): luau.CallExpression;
//# sourceMappingURL=spreadDestructureArray.d.ts.map