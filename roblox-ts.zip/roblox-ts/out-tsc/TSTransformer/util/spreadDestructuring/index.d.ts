import type luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export * from "./spreadDestructureArray.ts";
export * from "./spreadDestructureMap.ts";
export * from "./spreadDestructureObject.ts";
export * from "./spreadDestructureSet.ts";
type SpreadDestructor = (state: TransformState, parentId: luau.AnyIdentifier, index: number, idStack: Array<luau.AnyIdentifier>) => luau.Expression;
export declare function getSpreadDestructorForType(state: TransformState, node: ts.Node, type: ts.Type): SpreadDestructor;
//# sourceMappingURL=index.d.ts.map