import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function validateIdentifier(state: TransformState, node: ts.Identifier): void;
//# sourceMappingURL=validateIdentifier.d.ts.map