import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
export declare const objectAccessor: (state: TransformState, parentId: luau.AnyIdentifier, type: ts.Type, name: ts.PropertyName) => luau.Expression;
//# sourceMappingURL=objectAccessor.d.ts.map