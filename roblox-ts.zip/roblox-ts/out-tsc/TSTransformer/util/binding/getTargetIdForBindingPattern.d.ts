import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../classes/TransformState.ts";
export declare function getTargetIdForBindingPattern(state: TransformState, name: ts.BindingPattern, value: luau.Expression): luau.Identifier | luau.TemporaryIdentifier;
//# sourceMappingURL=getTargetIdForBindingPattern.d.ts.map