import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../../index.ts";
type BindingAccessor = (state: TransformState, parentId: luau.AnyIdentifier, index: number, idStack: Array<luau.AnyIdentifier>, isOmitted: boolean) => luau.Expression;
export declare function getAccessorForBindingType(state: TransformState, node: ts.Node, type: ts.Type): BindingAccessor;
export {};
//# sourceMappingURL=getAccessorForBindingType.d.ts.map