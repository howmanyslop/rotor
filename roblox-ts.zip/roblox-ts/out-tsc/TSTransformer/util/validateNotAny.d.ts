import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function validateNotAnyType(state: TransformState, node: ts.Node): void;
//# sourceMappingURL=validateNotAny.d.ts.map