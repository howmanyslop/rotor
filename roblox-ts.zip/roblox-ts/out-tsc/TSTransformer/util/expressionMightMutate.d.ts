import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function expressionMightMutate(state: TransformState, expression: luau.Expression, node?: ts.Expression): boolean;
//# sourceMappingURL=expressionMightMutate.d.ts.map