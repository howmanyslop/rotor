import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function createBinaryFromOperator(state: TransformState, node: ts.Node, left: luau.Expression, leftType: ts.Type, operatorKind: ts.BinaryOperator, right: luau.Expression, rightType: ts.Type): luau.Expression;
//# sourceMappingURL=createBinaryFromOperator.d.ts.map