import ts from "typescript";
export declare function isUsedAsStatement(expression: ts.Expression): boolean;
//# sourceMappingURL=isUsedAsStatement.d.ts.map