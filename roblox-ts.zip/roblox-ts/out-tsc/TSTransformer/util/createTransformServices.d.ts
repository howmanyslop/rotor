import type ts from "typescript";
import type { TransformServices } from "../types.ts";
export declare function createTransformServices(typeChecker: ts.TypeChecker): TransformServices;
//# sourceMappingURL=createTransformServices.d.ts.map