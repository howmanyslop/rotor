import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function getConstantValueLiteral(state: TransformState, node: ts.EnumMember | ts.PropertyAccessExpression | ts.ElementAccessExpression): luau.Expression<luau.SyntaxKind> | undefined;
//# sourceMappingURL=getConstantValueLiteral.d.ts.map