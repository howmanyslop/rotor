import luau from "@roblox-ts/luau-ast";
export interface VarArgsData {
    id: luau.AnyIdentifier;
    useLengthVar: boolean;
    lengthId?: luau.AnyIdentifier;
}
export declare function createSelectLengthCall(): luau.CallExpression;
export declare function simplifyUnpackOfArray(expression: luau.Expression): luau.Expression | undefined;
export declare function handleVarArgsParameterOptimization(statements: luau.List<luau.Statement>, paramId: luau.AnyIdentifier, varArgsData: VarArgsData | undefined): void;
//# sourceMappingURL=varArgsHelpers.d.ts.map