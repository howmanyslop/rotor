export declare function cleanModuleName(name: string): string;
//# sourceMappingURL=cleanModuleName.d.ts.map