export declare function assertNever(value: never, message: string): never;
//# sourceMappingURL=assertNever.d.ts.map