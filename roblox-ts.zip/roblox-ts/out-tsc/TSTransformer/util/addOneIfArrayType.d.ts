import type luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function addOneIfArrayType(state: TransformState, type: ts.Type, expression: luau.Expression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=addOneIfArrayType.d.ts.map