import ts from "typescript";
export declare function createStringFromLiteral(node: ts.TemplateLiteralToken | ts.StringLiteral): string;
//# sourceMappingURL=createStringFromLiteral.d.ts.map