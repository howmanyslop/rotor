import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function isSymbolMutable(state: TransformState, idSymbol: ts.Symbol): boolean;
//# sourceMappingURL=isSymbolMutable.d.ts.map