import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function getSourceFileFromModuleSpecifier(state: TransformState, moduleSpecifier: ts.Expression): ts.SourceFile | undefined;
//# sourceMappingURL=getSourceFileFromModuleSpecifier.d.ts.map