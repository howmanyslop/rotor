import luau from "@roblox-ts/luau-ast";
export declare function valueToIdStr(value: luau.Expression): string;
//# sourceMappingURL=valueToIdStr.d.ts.map