import ts from "typescript";
export declare function isSymbolOfValue(symbol: ts.Symbol): boolean;
//# sourceMappingURL=isSymbolOfValue.d.ts.map