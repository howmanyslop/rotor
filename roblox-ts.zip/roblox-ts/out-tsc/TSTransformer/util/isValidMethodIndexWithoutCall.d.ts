import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function isValidMethodIndexWithoutCall(state: TransformState, node: ts.Node): boolean;
//# sourceMappingURL=isValidMethodIndexWithoutCall.d.ts.map