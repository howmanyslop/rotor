import { RojoResolver } from "@isentinel/rojo-utils";
import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function getPathsWithScope(rojoResolver: RojoResolver, moduleScope: string): Array<string>;
export declare function resolveSymlinkedModulePath(nodeModulesPath: string, moduleOutPath: string): string | undefined;
export declare function getImportParts(state: TransformState, sourceFile: ts.SourceFile, moduleSpecifier: ts.Expression): luau.Expression<luau.SyntaxKind>[];
export declare function createImportExpression(state: TransformState, sourceFile: ts.SourceFile, moduleSpecifier: ts.Expression): luau.IndexableExpression;
//# sourceMappingURL=createImportExpression.d.ts.map