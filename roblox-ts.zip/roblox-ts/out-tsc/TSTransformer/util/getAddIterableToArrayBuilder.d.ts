import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
type AddIterableToArrayBuilder = (state: TransformState, expression: luau.Expression, arrayId: luau.AnyIdentifier, lengthId: luau.AnyIdentifier, amtElementsSinceUpdate: number, shouldUpdateLengthId: boolean) => luau.List<luau.Statement>;
export declare function getAddIterableToArrayBuilder(state: TransformState, node: ts.Node, type: ts.Type): AddIterableToArrayBuilder;
export {};
//# sourceMappingURL=getAddIterableToArrayBuilder.d.ts.map