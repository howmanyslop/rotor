import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function wrapStatementsAsGenerator(state: TransformState, node: ts.Node, statements: luau.List<luau.Statement>, hasDotDotDot?: boolean): luau.List<luau.Statement<luau.SyntaxKind>>;
//# sourceMappingURL=wrapStatementsAsGenerator.d.ts.map