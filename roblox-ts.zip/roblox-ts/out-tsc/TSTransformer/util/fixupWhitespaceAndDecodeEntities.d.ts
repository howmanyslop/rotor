export declare function fixupWhitespaceAndDecodeEntities(text: string): string | undefined;
//# sourceMappingURL=fixupWhitespaceAndDecodeEntities.d.ts.map