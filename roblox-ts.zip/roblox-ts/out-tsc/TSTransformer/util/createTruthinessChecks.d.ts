import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function willCreateTruthinessChecks(type: ts.Type): boolean;
export declare function createTruthinessChecks(state: TransformState, exp: luau.Expression, node: ts.Expression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=createTruthinessChecks.d.ts.map