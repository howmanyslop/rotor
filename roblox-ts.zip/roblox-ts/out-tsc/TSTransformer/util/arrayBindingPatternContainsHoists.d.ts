import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function arrayBindingPatternContainsHoists(state: TransformState, arrayBindingPattern: ts.ArrayBindingPattern): boolean;
//# sourceMappingURL=arrayBindingPatternContainsHoists.d.ts.map