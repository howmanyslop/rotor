import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function wrapReturnIfLuaTuple(state: TransformState, node: ts.CallExpression, exp: luau.Expression): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=wrapReturnIfLuaTuple.d.ts.map