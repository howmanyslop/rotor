import ts from "typescript";
export declare function getOriginalSymbolOfNode(typeChecker: ts.TypeChecker, node: ts.Node): ts.Symbol | undefined;
//# sourceMappingURL=getOriginalSymbolOfNode.d.ts.map