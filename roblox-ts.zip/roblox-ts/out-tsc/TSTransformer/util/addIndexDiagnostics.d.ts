import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function addIndexDiagnostics(state: TransformState, node: ts.PropertyAccessExpression | ts.ElementAccessExpression | ts.SignatureDeclarationBase | ts.PropertyName, expType: ts.Type): void;
//# sourceMappingURL=addIndexDiagnostics.d.ts.map