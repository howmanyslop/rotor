import type ts from "typescript";
import type { SourcePosition } from "../../Shared/types.ts";
import type { MultiTransformState } from "../classes/MultiTransformState.ts";
export declare function getOriginalSourcePosition(multiTransformState: MultiTransformState, node: ts.Node, positionSelector?: (node: ts.Node) => number): SourcePosition;
//# sourceMappingURL=getOriginalSourcePosition.d.ts.map