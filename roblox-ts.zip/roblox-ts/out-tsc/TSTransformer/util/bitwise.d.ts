import luau from "@roblox-ts/luau-ast";
import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function isBitwiseOperator(operatorKind: ts.BinaryOperator): boolean;
export declare function createBitwiseCall(operatorKind: ts.BinaryOperator, expressions: Array<luau.Expression>): luau.Expression;
export declare function createBitwiseFromOperator(state: TransformState, operatorKind: ts.BinaryOperator, node: ts.BinaryExpression): luau.Expression;
//# sourceMappingURL=bitwise.d.ts.map