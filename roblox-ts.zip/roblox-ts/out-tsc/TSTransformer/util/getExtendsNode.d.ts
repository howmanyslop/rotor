import ts from "typescript";
export declare function getExtendsNode(node: ts.ClassLikeDeclaration): ts.ExpressionWithTypeArguments | undefined;
//# sourceMappingURL=getExtendsNode.d.ts.map