import ts from "typescript";
import type { TransformState } from "../index.ts";
export declare function isMethodFromType(state: TransformState, node: ts.Node, type: ts.Type): boolean;
export declare function isMethod(state: TransformState, node: ts.PropertyAccessExpression | ts.ElementAccessExpression | ts.SignatureDeclarationBase | ts.PropertyName): boolean;
//# sourceMappingURL=isMethod.d.ts.map