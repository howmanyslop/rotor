import luau from "@roblox-ts/luau-ast";
export declare function getLiteralNumberValue(expression: luau.NumberLiteral): number;
export declare function getLiteralNumberValue(expression: luau.Expression): number | undefined;
export declare function offset(expression: luau.Expression, value: number): luau.Expression<luau.SyntaxKind>;
//# sourceMappingURL=offset.d.ts.map