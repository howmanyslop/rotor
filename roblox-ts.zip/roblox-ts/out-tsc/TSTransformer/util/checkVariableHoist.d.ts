import ts from "typescript";
import type { TransformState } from "../classes/TransformState.ts";
export declare function checkVariableHoist(state: TransformState, node: ts.Identifier, symbol: ts.Symbol): void;
//# sourceMappingURL=checkVariableHoist.d.ts.map