export {};
//# sourceMappingURL=resolvePackageExports.test.d.ts.map