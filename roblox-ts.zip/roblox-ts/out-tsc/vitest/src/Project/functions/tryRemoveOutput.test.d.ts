export {};
//# sourceMappingURL=tryRemoveOutput.test.d.ts.map