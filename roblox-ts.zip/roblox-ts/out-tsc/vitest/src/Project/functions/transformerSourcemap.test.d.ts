export {};
//# sourceMappingURL=transformerSourcemap.test.d.ts.map