export {};
//# sourceMappingURL=copyItem.test.d.ts.map