export {};
//# sourceMappingURL=langserviceRealpath.test.d.ts.map