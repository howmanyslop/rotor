export {};
//# sourceMappingURL=compileGate.test.d.ts.map