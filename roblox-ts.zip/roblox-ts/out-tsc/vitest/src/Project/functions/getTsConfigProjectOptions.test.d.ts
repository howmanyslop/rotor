export {};
//# sourceMappingURL=getTsConfigProjectOptions.test.d.ts.map