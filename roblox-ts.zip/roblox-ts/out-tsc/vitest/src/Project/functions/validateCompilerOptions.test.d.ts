export {};
//# sourceMappingURL=validateCompilerOptions.test.d.ts.map