export {};
//# sourceMappingURL=createTransformerList.test.d.ts.map