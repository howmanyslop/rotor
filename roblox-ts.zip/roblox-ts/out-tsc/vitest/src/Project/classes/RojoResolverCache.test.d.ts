export {};
//# sourceMappingURL=RojoResolverCache.test.d.ts.map