export {};
//# sourceMappingURL=copyFilesManifest.test.d.ts.map