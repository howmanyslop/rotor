export {};
//# sourceMappingURL=snapshotBuildState.test.d.ts.map