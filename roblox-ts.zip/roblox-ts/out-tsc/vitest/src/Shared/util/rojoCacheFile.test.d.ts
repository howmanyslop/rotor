export {};
//# sourceMappingURL=rojoCacheFile.test.d.ts.map