export {};
//# sourceMappingURL=transformForOfStatement.test.d.ts.map