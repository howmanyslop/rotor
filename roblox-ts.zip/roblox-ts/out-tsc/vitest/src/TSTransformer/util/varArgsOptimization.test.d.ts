export {};
//# sourceMappingURL=varArgsOptimization.test.d.ts.map