export {};
//# sourceMappingURL=selectSymlinkPath.test.d.ts.map