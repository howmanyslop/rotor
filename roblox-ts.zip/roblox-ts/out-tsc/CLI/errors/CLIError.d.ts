import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
export declare class CLIError extends DiagnosticError {
    constructor(message: string);
}
//# sourceMappingURL=CLIError.d.ts.map