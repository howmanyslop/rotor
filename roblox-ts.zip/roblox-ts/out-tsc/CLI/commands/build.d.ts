import type { CommandModule } from "yargs";
import type { ProjectOptions } from "../../Shared/types.ts";
interface BuildFlags {
    project: string;
    build?: string | true;
    emitDeclarationOnly?: boolean;
}
declare const _default: CommandModule<object, BuildFlags & Partial<ProjectOptions>>;
export default _default;
//# sourceMappingURL=build.d.ts.map