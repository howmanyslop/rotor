export {};
//# sourceMappingURL=patchFs.d.ts.map