export declare function warn(message: string): void;
//# sourceMappingURL=warn.d.ts.map