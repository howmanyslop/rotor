import ts from "typescript";
export declare function formatDiagnostics(diagnostics: ReadonlyArray<ts.Diagnostic>): string;
//# sourceMappingURL=formatDiagnostics.d.ts.map