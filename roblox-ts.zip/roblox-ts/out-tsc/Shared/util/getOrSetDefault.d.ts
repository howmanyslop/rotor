export declare function getOrSetDefault<K, V>(map: Map<K, V>, key: K, getDefaultValue: () => V): V;
//# sourceMappingURL=getOrSetDefault.d.ts.map