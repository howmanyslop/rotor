export declare function findLastIndex<T>(array: ReadonlyArray<T>, callback: (value: T) => boolean): number;
//# sourceMappingURL=findLastIndex.d.ts.map