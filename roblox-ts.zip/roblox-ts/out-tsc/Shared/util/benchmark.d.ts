export declare function benchmarkSync(name: string, callback: () => void): void;
export declare function benchmarkIfVerbose(name: string, callback: () => void): void;
export declare function benchmarkAsync<T>(name: string, callback: () => Promise<T>): Promise<T>;
export declare function benchmarkAsyncIfVerbose<T>(name: string, callback: () => Promise<T>): Promise<T>;
export declare function benchmark<T>(name: string, callback: () => Promise<T>): Promise<void>;
//# sourceMappingURL=benchmark.d.ts.map