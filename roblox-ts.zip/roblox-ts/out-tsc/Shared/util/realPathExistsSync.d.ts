export declare function realPathExistsSync(fsPath: string): string | undefined;
//# sourceMappingURL=realPathExistsSync.d.ts.map