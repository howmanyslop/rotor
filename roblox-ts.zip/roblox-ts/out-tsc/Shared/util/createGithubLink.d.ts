export declare function issue(id: number): string;
//# sourceMappingURL=createGithubLink.d.ts.map