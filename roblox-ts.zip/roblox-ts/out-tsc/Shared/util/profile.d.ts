export declare function profile<T>(name: string, fn: () => T extends Promise<unknown> ? never : T): T;
export declare function profileAsync<T>(name: string, fn: () => Promise<T>): Promise<T>;
//# sourceMappingURL=profile.d.ts.map