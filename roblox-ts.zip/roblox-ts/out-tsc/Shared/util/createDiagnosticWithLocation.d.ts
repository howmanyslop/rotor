import type ts from "typescript";
import type { SourceFileWithTextRange } from "../types.ts";
export declare function createDiagnosticWithLocation(id: number, messageText: string, category: ts.DiagnosticCategory, node: ts.Node | SourceFileWithTextRange): ts.DiagnosticWithLocation;
//# sourceMappingURL=createDiagnosticWithLocation.d.ts.map