import ts from "typescript";
export declare function hasErrors(diagnostics: ReadonlyArray<ts.Diagnostic>): boolean;
//# sourceMappingURL=hasErrors.d.ts.map