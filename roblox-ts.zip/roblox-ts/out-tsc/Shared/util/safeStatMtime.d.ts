export declare function safeStatMtime(filePath: string): number | undefined;
//# sourceMappingURL=safeStatMtime.d.ts.map