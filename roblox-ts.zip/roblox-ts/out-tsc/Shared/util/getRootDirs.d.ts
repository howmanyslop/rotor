import type ts from "typescript";
export declare function getRootDirs(compilerOptions: ts.CompilerOptions): string[];
//# sourceMappingURL=getRootDirs.d.ts.map