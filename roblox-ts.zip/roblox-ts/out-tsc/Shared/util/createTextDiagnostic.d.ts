import ts from "typescript";
export declare function createTextDiagnostic(messageText: string, category?: ts.DiagnosticCategory): ts.Diagnostic;
//# sourceMappingURL=createTextDiagnostic.d.ts.map