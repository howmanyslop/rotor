import type { RojoResolverState } from "@isentinel/rojo-utils";
import { RojoResolver } from "@isentinel/rojo-utils";
type ManifestEntry = [string, number];
export interface CacheFile {
    version: number;
    compilerVersion: string;
    key: string;
    state: RojoResolverState;
    manifest: {
        configFiles: Array<ManifestEntry>;
        dirs: Array<ManifestEntry>;
    };
    sentinel?: {
        path: string;
        mtimeMs: number;
    };
}
export declare const manifestEntrySchema: import("arktype/internal/variants/array.ts").ArrayType<[string, number], {}>;
export declare const rbxPathSchema: import("arktype/internal/variants/array.ts").ArrayType<string[], {}>;
export declare const rojoResolverStateSchema: import("arktype/internal/variants/object.ts").ObjectType<{
    partitions: {
        rbxPath: string[];
        fsPath: string;
    }[];
    filePathToRbxPathMap: [string, string[]][];
    isolatedContainers: string[][];
    isGame: boolean;
    warnings: string[];
    walkedDirs: string[];
    walkedConfigFiles: string[];
}, {}>;
export declare const sentinelSchema: import("arktype/internal/variants/object.ts").ObjectType<{
    path: string;
    mtimeMs: number;
}, {}>;
export declare function serialiseRojoResolver(resolver: RojoResolver, key: string, sentinelPath?: string): CacheFile;
export declare function writeCacheFile(cacheFilePath: string, cache: CacheFile): void;
export declare function tryLoadResolver(cacheFilePath: string, key: string): RojoResolver | undefined;
export {};
//# sourceMappingURL=rojoCacheFile.d.ts.map