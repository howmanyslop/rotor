export declare function findAncestorDir(dirs: Array<string>): string;
//# sourceMappingURL=findAncestorDir.d.ts.map