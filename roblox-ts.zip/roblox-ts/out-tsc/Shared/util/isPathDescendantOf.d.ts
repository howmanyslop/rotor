export declare function isPathDescendantOf(filePath: string, dirPath: string): boolean;
//# sourceMappingURL=isPathDescendantOf.d.ts.map