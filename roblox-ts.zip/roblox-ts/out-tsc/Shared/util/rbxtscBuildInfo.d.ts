import ts from "typescript";
export declare function addRbxtscInfix(filePath: string): string;
export declare function applyRbxtscBuildInfoPath(options: ts.CompilerOptions): void;
//# sourceMappingURL=rbxtscBuildInfo.d.ts.map