import type ts from "typescript";
import type { ProjectType } from "./constants.ts";
export interface SourcePosition {
    line: number;
    column: number;
}
export interface ProjectOptions {
    includePath: string;
    rojo: string | undefined;
    type: ProjectType | undefined;
    logTruthyChanges: boolean;
    noInclude: boolean;
    usePolling: boolean;
    verbose: boolean;
    watch: boolean;
    writeOnlyChanged: boolean;
    writeTransformedFiles: boolean;
    optimizedLoops: boolean;
    allowCommentDirectives: boolean;
    luau: boolean;
}
export interface ProjectData {
    isPackage: boolean;
    nodeModulesPath: string;
    projectOptions: ProjectOptions;
    projectPath: string;
    rojoConfigPath: string | undefined;
    tsConfigPath: string;
    transformerWatcher?: TransformerWatcher;
}
export interface TransformerWatcher {
    service: ts.LanguageService;
    updateFile: (fileName: string, text: string) => void;
}
export type ShouldTransformSourceFile = (file: ts.SourceFile, program: ts.Program, config: TransformerPluginConfig) => boolean;
export interface TransformerPluginConfig {
    transform?: string;
    import?: string;
    type?: "program" | "config" | "checker" | "raw" | "compilerOptions";
    after?: boolean;
    afterDeclarations?: boolean;
    [options: string]: unknown;
}
export interface SourceFileWithTextRange {
    sourceFile: ts.SourceFile;
    range: ts.ReadonlyTextRange;
}
//# sourceMappingURL=types.d.ts.map