export declare class Lazy<T> {
    private isInitialized;
    private value;
    private readonly getValue;
    constructor(getValue: () => T);
    get(): T;
    set(value: T): void;
}
//# sourceMappingURL=Lazy.d.ts.map