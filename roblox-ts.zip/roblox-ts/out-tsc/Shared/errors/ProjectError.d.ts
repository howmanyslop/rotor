import { DiagnosticError } from "./DiagnosticError.ts";
export declare class ProjectError extends DiagnosticError {
    constructor(message: string);
}
//# sourceMappingURL=ProjectError.d.ts.map