import type ts from "typescript";
import { LoggableError } from "./LoggableError.ts";
export declare class DiagnosticError extends LoggableError {
    readonly diagnostics: ReadonlyArray<ts.Diagnostic>;
    constructor(diagnostics: ReadonlyArray<ts.Diagnostic>);
    toString(): string;
}
//# sourceMappingURL=DiagnosticError.d.ts.map