export declare abstract class LoggableError {
    constructor();
    abstract toString(): string;
    log(): void;
}
//# sourceMappingURL=LoggableError.d.ts.map