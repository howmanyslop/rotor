# Contributing

Thank you for your interest in contributing to **roblox-ts**!

## Getting Started

This compiler is maintained in-tree under `tools/roblox-ts` of the
project-halcyon monorepo. It is built, tested, and type-checked through the
package scripts (driven by Nx at the workspace level):

```sh
# from the monorepo root
pnpm install

# bundle to dist/ (only needed for publishing)
pnpm --filter @isentinel/roblox-ts build

# run the test suite / type-check
pnpm --filter @isentinel/roblox-ts test-compile
pnpm --filter @isentinel/roblox-ts typecheck
```

The `rbxtsc` bin runs the TypeScript in `src/` directly via Node's native type
stripping, so a source checkout uses your changes immediately — no build step is
required to try them. Set `RBXTSC_FROM_DIST=1` to force the bundled `dist/`
build instead.

## Unit Testing

**roblox-ts** keeps a suite of automated unit tests inside of `/tests`.

Effectively, this folder is a tiny **roblox-ts** game. Testing process is as follows:

1. Compile tests project to create a `/tests/out` folder containing `.lua` files
2. Use `rojo build` to create `/tests/test.rbxl`
3. Use `lune` to execute the tests

You can run this process yourself if you have [rokit](https://github.com/rojo-rbx/rokit) installed.

```sh
# install rojo + lune
rokit install
# Compile tests, build .rbxl, run with lune
npm test
```
