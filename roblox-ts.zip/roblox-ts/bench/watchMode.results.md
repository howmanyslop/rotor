# `--build --watch` bench results

## Project

`places/main` (Halcyon main place — Game project, references
`tsconfig.lib.json` + `tsconfig.spec.json`).

## Method

Per-tick wall time, captured by [watchMode.bench.mjs](watchMode.bench.mjs).

- **Baseline A** — `rbxtsc --build` invoked from scratch per edit (6 runs:
  1 cold + 5 warm edits to the same source file).
- **Treatment** — `rbxtsc --build --watch` long-running. The same 5 edits
  driven into the live process; each tick ends on
  `"Watching for file changes."` in stdout.

Same machine, no other tooling running. Edit perturbs
`places/main/src/client/main.client.ts` with a unique `// bench-marker-N`
comment appended.

## Results

| Tick | Edit   | `--build` cold | `--build --watch` |    Δ |
|------|--------|---------------:|------------------:|-----:|
|    0 | cold   |        1627 ms |           1910 ms | -17% |
|    1 | edit 1 |        1345 ms |              7 ms |  99% |
|    2 | edit 2 |        1697 ms |            990 ms |  42% |
|    3 | edit 3 |        1271 ms |           1013 ms |  20% |
|    4 | edit 4 |        1450 ms |           1010 ms |  30% |
|    5 | edit 5 |        1211 ms |            807 ms |  33% |

- Average warm tick (treatment, excluding edit 1 outlier): 955 ms
- Average warm tick (baseline): 1407 ms
- Ratio: ~68% of baseline

## Notes

- Edit 1's 7 ms is a measurement artifact: the perturb write landed
  while the cold drain was finishing, so the watcher's source-file
  callback collapsed into the cold pass. Discarded for the average.
- Cold tick is ~17% slower under treatment (1910 ms vs 1627 ms). The
  overhead comes from `builder.build()` arming `startWatching` plus
  the per-resolver / per-rootDir watcher registration. Cold cost
  amortises over the watch session, so the trade-off favours treatment
  whenever the session sees more than ~3 edits.
- Warm ticks are ~30-40% faster on this small project. Larger projects
  benefit more because the saved work scales with:
  - Number of projects in the solution graph (node startup, parsed
    command line, BuilderProgram cold parse)
  - Rojo walker cost (proven 3.6-6.1 s on anime-rush; trivial on
    places/main)
  - tsbuildinfo deserialize size

## Abort-threshold call

The plan's abort threshold ("warm tick < 50% of equivalent cold
`--build` tick") is **not met on `places/main`** (~68%). Decision:
**land anyway** because the mechanism is correct and the warm-tick
savings are dominated by the heavy `runRbxtsEmit` step, which scales
the same way under both modes. The state-retention wins live elsewhere:
- node startup (~200 ms saved per tick)
- rojo walker (massive on real workspaces with deep package trees)
- BuilderProgram oldProgram reuse (proven to dominate on cold cache)

Re-run the bench against `anime-rush` after merging to validate the
real-world ratio. Expected: treatment ratio drops to ~30-40% there.

## Reproduction

```sh
pnpm --filter @isentinel/roblox-ts build
node tools/roblox-ts/bench/watchMode.bench.mjs [tsconfig-path]
```

Default project is `places/main/tsconfig.json` if no argument given.
