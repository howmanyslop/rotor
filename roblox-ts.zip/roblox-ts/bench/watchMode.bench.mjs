#!/usr/bin/env node
/**
 * Bench `--build` re-invocation vs `--build --watch` over 5 sequential
 * single-file edits. Reports a per-tick wall-time table.
 *
 * Usage:
 *   node tools/roblox-ts/bench/watchMode.bench.mjs [project-tsconfig-path]
 *
 * Default project: places/main/tsconfig.json
 */
import { spawn } from "node:child_process";
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const REPO_ROOT = path.resolve(__dirname, "../../..");

const PROJECT_TSCONFIG = process.argv[2]
	? path.resolve(process.argv[2])
	: path.join(REPO_ROOT, "places/main/tsconfig.json");

if (!existsSync(PROJECT_TSCONFIG)) {
	console.error(`tsconfig not found: ${PROJECT_TSCONFIG}`);
	process.exit(1);
}

const RBXTSC = path.join(REPO_ROOT, "tools/roblox-ts/dist/CLI/cli.cjs");
if (!existsSync(RBXTSC)) {
	console.error(`built CLI not found: ${RBXTSC} — run \`pnpm --filter @isentinel/roblox-ts build\` first`);
	process.exit(1);
}

const PROJECT_DIR = path.dirname(PROJECT_TSCONFIG);

// Find a source file to perturb. Walks src/ for the first .ts.
function findPerturbFile() {
	const candidates = [
		"src/index.ts",
		"src/main.ts",
		"src/client/main.client.ts",
		"src/server/main.server.ts",
	];
	for (const c of candidates) {
		const p = path.join(PROJECT_DIR, c);
		if (existsSync(p)) return p;
	}
	// Fall back to first non-.spec.ts file under src
	function walk(dir) {
		for (const entry of readdirSync(dir)) {
			const full = path.join(dir, entry);
			if (statSync(full).isDirectory()) {
				const found = walk(full);
				if (found) return found;
			} else if (
				entry.endsWith(".ts") &&
				!entry.endsWith(".d.ts") &&
				!entry.endsWith(".spec.ts")
			) {
				return full;
			}
		}
		return undefined;
	}
	return walk(path.join(PROJECT_DIR, "src"));
}

const PERTURB_FILE = findPerturbFile();
if (PERTURB_FILE === undefined) {
	console.error(`no .ts source file found under ${PROJECT_DIR}/src`);
	process.exit(1);
}
console.error(`perturbing: ${path.relative(REPO_ROOT, PERTURB_FILE)}`);

const ORIGINAL_CONTENT = readFileSync(PERTURB_FILE, "utf-8");

function perturb(iter) {
	const marker = `\n// bench-marker-${iter}\n`;
	writeFileSync(PERTURB_FILE, ORIGINAL_CONTENT + marker);
}

function restore() {
	try {
		writeFileSync(PERTURB_FILE, ORIGINAL_CONTENT);
	} catch {
		// process.on('exit') runs sync after stdio teardown; swallow IO errors.
	}
}

// Restore on normal exit AND on Ctrl+C. Without this, a kill mid-run leaves
// PERTURB_FILE modified and prone to being accidentally committed.
process.on("exit", restore);
process.on("SIGINT", () => process.exit(130));
process.on("SIGTERM", () => process.exit(143));

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

// === Baseline A: cold --build invoked manually per edit ===
async function baselineA() {
	const ticks = [];
	for (let i = 0; i <= 5; i++) {
		const t0 = process.hrtime.bigint();
		const exit = await new Promise(resolve => {
			const proc = spawn(process.execPath, [RBXTSC, "--build", "--project", PROJECT_TSCONFIG], {
				stdio: "ignore",
			});
			proc.on("exit", code => resolve(code));
		});
		const ms = Number(process.hrtime.bigint() - t0) / 1_000_000;
		ticks.push({ tick: i, label: i === 0 ? "cold" : `edit ${i}`, wallMs: ms, exit });
		if (i < 5) {
			perturb(i + 1);
		}
	}
	restore();
	return ticks;
}

// === Treatment: --build --watch with edits driven into the long-running process ===
async function treatment() {
	restore();

	const ticks = [];
	let resolveTick = null;
	let coldStart = null;

	const proc = spawn(process.execPath, [RBXTSC, "--build", "--watch", "--project", PROJECT_TSCONFIG], {
		stdio: ["ignore", "pipe", "pipe"],
	});

	let buffer = "";
	proc.stdout.on("data", chunk => {
		buffer += chunk.toString();
		// "Watching for file changes." marks the end of a drain cycle.
		const matches = buffer.match(/Watching for file changes/g);
		if (matches !== null && resolveTick !== null) {
			const r = resolveTick;
			resolveTick = null;
			r();
			buffer = "";
		}
	});
	proc.stderr.on("data", chunk => process.stderr.write(chunk));

	async function awaitNextDrain() {
		await new Promise(resolve => {
			resolveTick = resolve;
		});
	}

	try {
		// Cold drain
		coldStart = process.hrtime.bigint();
		await awaitNextDrain();
		const coldMs = Number(process.hrtime.bigint() - coldStart) / 1_000_000;
		ticks.push({ tick: 0, label: "cold", wallMs: coldMs });

		// 5 sequential warm edits
		for (let i = 1; i <= 5; i++) {
			const editStart = process.hrtime.bigint();
			perturb(i);
			await awaitNextDrain();
			const ms = Number(process.hrtime.bigint() - editStart) / 1_000_000;
			ticks.push({ tick: i, label: `edit ${i}`, wallMs: ms });
		}
	} finally {
		restore();
		proc.kill("SIGTERM");
		// Give it a moment to clean up
		await sleep(200);
		if (proc.exitCode === null) proc.kill("SIGKILL");
	}

	return ticks;
}

function fmt(ms) {
	return ms.toFixed(0).padStart(6) + " ms";
}

(async () => {
	console.error("[bench] running Baseline A: --build (6 invocations: 1 cold + 5 edits)");
	const a = await baselineA();

	console.error("[bench] running Treatment: --build --watch");
	const t = await treatment();

	console.log("\n## Bench: `--build` vs `--build --watch` (places/main)");
	console.log();
	console.log("| Tick | Edit       | `--build` cold | `--build --watch` | Δ            |");
	console.log("|------|------------|----------------|-------------------|--------------|");
	const len = Math.max(a.length, t.length);
	for (let i = 0; i < len; i++) {
		const aTick = a[i];
		const tTick = t[i];
		const label = (aTick ?? tTick).label;
		const aMs = aTick?.wallMs;
		const tMs = tTick?.wallMs;
		const delta = aMs !== undefined && tMs !== undefined ? aMs - tMs : undefined;
		const deltaCell = delta !== undefined ? `${(delta / aMs * 100).toFixed(0)}%` : "—";
		console.log(
			`| ${String(i).padStart(4)} | ${label.padEnd(10)} | ${aMs !== undefined ? fmt(aMs) : "      —    "} | ${tMs !== undefined ? fmt(tMs) : "      —    "} | ${deltaCell.padStart(10)} |`,
		);
	}

	// Abort threshold check
	const warmA = a.filter(x => x.label.startsWith("edit")).map(x => x.wallMs);
	const warmT = t.filter(x => x.label.startsWith("edit")).map(x => x.wallMs);
	const avgWarmA = warmA.reduce((s, v) => s + v, 0) / warmA.length;
	const avgWarmT = warmT.reduce((s, v) => s + v, 0) / warmT.length;
	const ratio = avgWarmT / avgWarmA;

	console.log();
	console.log(`Average warm tick (treatment): ${avgWarmT.toFixed(0)} ms`);
	console.log(`Average warm tick (baseline) : ${avgWarmA.toFixed(0)} ms`);
	console.log(`Ratio: ${(ratio * 100).toFixed(0)}% of baseline`);
	console.log(
		ratio < 0.5
			? `✓ Abort threshold met (warm tick < 50% of cold --build tick).`
			: `✗ Abort threshold MISSED — investigate before merging.`,
	);
})();
