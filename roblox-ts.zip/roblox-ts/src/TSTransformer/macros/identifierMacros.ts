import type { IdentifierMacro, MacroList } from "./types.ts";

export const IDENTIFIER_MACROS: MacroList<IdentifierMacro> = {
	Promise: (state, node) => state.TS(node, "Promise"),
};
