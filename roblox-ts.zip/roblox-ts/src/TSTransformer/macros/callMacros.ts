import luau from "@roblox-ts/luau-ast";

import { errors } from "../../Shared/diagnostics.ts";
import { DiagnosticService } from "../classes/DiagnosticService.ts";
import { convertToIndexableExpression } from "../util/convertToIndexableExpression.ts";
import { getImportParts } from "../util/createImportExpression.ts";
import { createTruthinessChecks } from "../util/createTruthinessChecks.ts";
import type { CallMacro, MacroList } from "./types.ts";

const PRIMITIVE_LUAU_TYPES = new Set([
	"nil",
	"boolean",
	"string",
	"number",
	"table",
	"userdata",
	"function",
	"thread",
	"vector",
	"buffer",
]);

export const CALL_MACROS: MacroList<CallMacro> = {
	assert: (state, node, expression, args) => {
		args[0] = createTruthinessChecks(state, args[0], node.arguments[0]);
		return luau.call(luau.globals.assert, args);
	},

	typeOf: (state, node, expression, args) => luau.call(luau.globals.typeof, args),

	typeIs: (state, node, expression, args) => {
		const [value, typeStr] = args;
		const typeFunc =
			luau.isStringLiteral(typeStr) && PRIMITIVE_LUAU_TYPES.has(typeStr.value)
				? luau.globals.type
				: luau.globals.typeof;
		return luau.binary(luau.call(typeFunc, [value]), "==", typeStr);
	},

	classIs: (state, node, expression, args) => {
		const [value, typeStr] = args;
		return luau.binary(luau.property(convertToIndexableExpression(value), "ClassName"), "==", typeStr);
	},

	identity: (state, node, expression, args) => args[0],

	$range: (state, node) => {
		DiagnosticService.addDiagnostic(errors.noRangeMacroOutsideForOf(node.expression));
		return luau.none();
	},

	$tuple: (state, node) => {
		DiagnosticService.addDiagnostic(errors.noTupleMacroOutsideReturn(node));
		return luau.none();
	},

	$getModuleTree: (state, node) => {
		const parts = getImportParts(state, node.getSourceFile(), node.arguments[0]);
		// converts the flat array into { root, { "rest", "of", "path" } }
		return luau.array([parts.shift()!, luau.array(parts)]);
	},
};
