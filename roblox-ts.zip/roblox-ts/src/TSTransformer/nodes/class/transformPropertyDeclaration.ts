import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { transformExpression } from "../expressions/transformExpression.ts";
import { transformPropertyName } from "../transformPropertyName.ts";

export function transformPropertyDeclaration(
	state: TransformState,
	node: ts.PropertyDeclaration,
	name: luau.AnyIdentifier,
) {
	if (!ts.hasStaticModifier(node)) {
		return luau.list.make<luau.Statement>();
	}

	if (ts.isPrivateIdentifier(node.name)) {
		DiagnosticService.addDiagnostic(errors.noPrivateIdentifier(node));
		return luau.list.make<luau.Statement>();
	}

	if (!node.initializer) {
		return luau.list.make<luau.Statement>();
	}

	return luau.list.make(
		luau.create(luau.SyntaxKind.Assignment, {
			left: luau.create(luau.SyntaxKind.ComputedIndexExpression, {
				expression: name,
				index: transformPropertyName(state, node.name),
			}),
			operator: "=",
			right: transformExpression(state, node.initializer),
		}),
	);
}
