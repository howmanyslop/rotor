import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../classes/TransformState.ts";
import { convertToIndexableExpression } from "../util/convertToIndexableExpression.ts";
import { validateIdentifier } from "../util/validateIdentifier.ts";
import { transformIdentifier } from "./expressions/transformIdentifier.ts";

export function transformEntityName(state: TransformState, node: ts.EntityName) {
	if (ts.isIdentifier(node)) {
		validateIdentifier(state, node);
		return transformIdentifier(state, node);
	} else {
		return transformQualifiedName(state, node);
	}
}

function transformQualifiedName(state: TransformState, node: ts.QualifiedName): luau.PropertyAccessExpression {
	return luau.property(convertToIndexableExpression(transformEntityName(state, node.left)), node.right.text);
}
