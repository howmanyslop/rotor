import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { DiagnosticFactory } from "../../../Shared/diagnostics.ts";
import { errors } from "../../../Shared/diagnostics.ts";
import { assert } from "../../../Shared/util/assert.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { getKindName } from "../../util/getKindName.ts";
import { transformBlock } from "./transformBlock.ts";
import { transformBreakStatement } from "./transformBreakStatement.ts";
import { transformClassDeclaration } from "./transformClassDeclaration.ts";
import { transformContinueStatement } from "./transformContinueStatement.ts";
import { transformDoStatement } from "./transformDoStatement.ts";
import { transformEnumDeclaration } from "./transformEnumDeclaration.ts";
import { transformExportAssignment } from "./transformExportAssignment.ts";
import { transformExportDeclaration } from "./transformExportDeclaration.ts";
import { transformExpressionStatement } from "./transformExpressionStatement.ts";
import { transformForOfStatement } from "./transformForOfStatement.ts";
import { transformForStatement } from "./transformForStatement.ts";
import { transformFunctionDeclaration } from "./transformFunctionDeclaration.ts";
import { transformIfStatement } from "./transformIfStatement.ts";
import { transformImportDeclaration } from "./transformImportDeclaration.ts";
import { transformImportEqualsDeclaration } from "./transformImportEqualsDeclaration.ts";
import { transformModuleDeclaration } from "./transformModuleDeclaration.ts";
import { transformReturnStatement } from "./transformReturnStatement.ts";
import { transformSwitchStatement } from "./transformSwitchStatement.ts";
import { transformThrowStatement } from "./transformThrowStatement.ts";
import { transformTryStatement } from "./transformTryStatement.ts";
import { transformVariableStatement } from "./transformVariableStatement.ts";
import { transformWhileStatement } from "./transformWhileStatement.ts";

const NO_EMIT = () => luau.list.make<luau.Statement>();

const DIAGNOSTIC = (factory: DiagnosticFactory) => (state: TransformState, node: ts.Statement) => {
	DiagnosticService.addDiagnostic(factory(node));
	return NO_EMIT();
};

type Validate<T> = {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- typecheck only works with `any`
	[k in keyof T]: T[k] extends [infer Kind, infer C extends (...args: any) => unknown]
		? "kind" extends keyof Parameters<C>[1]
			? Kind extends Parameters<C>[1]["kind"]
				? T[k]
				: never
			: T[k]
		: never;
};

function createTransformerMap<
	T extends Array<
		[
			ts.SyntaxKind,
			{ bivariant(state: TransformState, statement: ts.Statement): luau.List<luau.Statement> }["bivariant"],
		]
	>,
>(
	values: Validate<[...T]>,
): Map<ts.SyntaxKind, (state: TransformState, statement: ts.Statement) => luau.List<luau.Statement>> {
	return new Map(values);
}

const TRANSFORMER_BY_KIND = createTransformerMap([
	// no emit
	[ts.SyntaxKind.InterfaceDeclaration, NO_EMIT],
	[ts.SyntaxKind.TypeAliasDeclaration, NO_EMIT],
	[ts.SyntaxKind.EmptyStatement, NO_EMIT],

	// banned statements
	[ts.SyntaxKind.ForInStatement, DIAGNOSTIC(errors.noForInStatement)],
	[ts.SyntaxKind.LabeledStatement, DIAGNOSTIC(errors.noLabeledStatement)],
	[ts.SyntaxKind.DebuggerStatement, DIAGNOSTIC(errors.noDebuggerStatement)],

	// regular transforms
	[ts.SyntaxKind.Block, transformBlock],
	[ts.SyntaxKind.BreakStatement, transformBreakStatement],
	[ts.SyntaxKind.ClassDeclaration, transformClassDeclaration],
	[ts.SyntaxKind.ContinueStatement, transformContinueStatement],
	[ts.SyntaxKind.DoStatement, transformDoStatement],
	[ts.SyntaxKind.EnumDeclaration, transformEnumDeclaration],
	[ts.SyntaxKind.ExportAssignment, transformExportAssignment],
	[ts.SyntaxKind.ExportDeclaration, transformExportDeclaration],
	[ts.SyntaxKind.ExpressionStatement, transformExpressionStatement],
	[ts.SyntaxKind.ForOfStatement, transformForOfStatement],
	[ts.SyntaxKind.ForStatement, transformForStatement],
	[ts.SyntaxKind.FunctionDeclaration, transformFunctionDeclaration],
	[ts.SyntaxKind.IfStatement, transformIfStatement],
	[ts.SyntaxKind.ImportDeclaration, transformImportDeclaration],
	[ts.SyntaxKind.ImportEqualsDeclaration, transformImportEqualsDeclaration],
	[ts.SyntaxKind.ModuleDeclaration, transformModuleDeclaration],
	[ts.SyntaxKind.ReturnStatement, transformReturnStatement],
	[ts.SyntaxKind.SwitchStatement, transformSwitchStatement],
	[ts.SyntaxKind.ThrowStatement, transformThrowStatement],
	[ts.SyntaxKind.TryStatement, transformTryStatement],
	[ts.SyntaxKind.VariableStatement, transformVariableStatement],
	[ts.SyntaxKind.WhileStatement, transformWhileStatement],
]);

/**
 * Transforms a singular `ts.Statement` in a `luau.list<...>`.
 * @param state The current transform state.
 * @param node The `ts.Statement` to transform.
 */
export function transformStatement(state: TransformState, node: ts.Statement): luau.List<luau.Statement> {
	// if any modifiers of the node include the `declare` keyword we do not transform
	// `declare` tells us that the identifier of the node is defined somewhere else and we should trust it
	const modifiers = ts.canHaveModifiers(node) ? ts.getModifiers(node) : undefined;
	if (modifiers?.some(v => v.kind === ts.SyntaxKind.DeclareKeyword)) return NO_EMIT();
	const transformer = TRANSFORMER_BY_KIND.get(node.kind);
	if (transformer) {
		return transformer(state, node);
	}
	assert(false, `Unknown statement: ${getKindName(node.kind)}`);
}
