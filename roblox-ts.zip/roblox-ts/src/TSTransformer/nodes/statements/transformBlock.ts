import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformStatementList } from "../transformStatementList.ts";

export function transformBlock(state: TransformState, node: ts.Block) {
	return luau.list.make(
		luau.create(luau.SyntaxKind.DoStatement, {
			statements: transformStatementList(state, node, node.statements),
		}),
	);
}
