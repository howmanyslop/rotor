import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../../index.ts";
import { isUnaryAssignmentOperator } from "../../typeGuards.ts";
import { createCompoundAssignmentStatement, getSimpleAssignmentOperator } from "../../util/assignment.ts";
import { getAssignableValue } from "../../util/getAssignableValue.ts";
import { skipDownwards } from "../../util/traversal.ts";
import { wrapExpressionStatement } from "../../util/wrapExpressionStatement.ts";
import { transformExpression } from "../expressions/transformExpression.ts";
import { transformLogicalOrCoalescingAssignmentExpressionStatement } from "../transformLogicalOrCoalescingAssignmentExpression.ts";
import { transformWritableAssignment, transformWritableExpression } from "../transformWritable.ts";

function transformUnaryExpressionStatement(
	state: TransformState,
	node: ts.PrefixUnaryExpression | ts.PostfixUnaryExpression,
) {
	const writable = transformWritableExpression(state, node.operand, false);
	const operator: luau.AssignmentOperator = node.operator === ts.SyntaxKind.PlusPlusToken ? "+=" : "-=";
	return luau.create(luau.SyntaxKind.Assignment, {
		left: writable,
		operator,
		right: luau.number(1),
	});
}

export function transformExpressionStatementInner(
	state: TransformState,
	expression: ts.Expression,
): luau.List<luau.Statement> {
	if (ts.isBinaryExpression(expression)) {
		const operatorKind = expression.operatorToken.kind;
		if (ts.isLogicalOrCoalescingAssignmentExpression(expression)) {
			return transformLogicalOrCoalescingAssignmentExpressionStatement(state, expression);
		} else if (
			ts.isAssignmentOperator(operatorKind) &&
			!ts.isArrayLiteralExpression(expression.left) &&
			!ts.isObjectLiteralExpression(expression.left)
		) {
			const writableType = state.getType(expression.left);
			const valueType = state.getType(expression.right);
			const operator = getSimpleAssignmentOperator(
				writableType,
				operatorKind as ts.AssignmentOperator,
				valueType,
			);
			const { writable, readable, value } = transformWritableAssignment(
				state,
				expression.left,
				expression.right,
				operator === undefined,
				operator === undefined,
			);
			if (operator !== undefined) {
				return luau.list.make(
					luau.create(luau.SyntaxKind.Assignment, {
						left: writable,
						operator,
						right: getAssignableValue(operator, value, valueType),
					}),
				);
			} else {
				return luau.list.make(
					createCompoundAssignmentStatement(
						state,
						expression,
						writable,
						writableType,
						readable,
						operatorKind,
						value,
						valueType,
					),
				);
			}
		}
	} else if (
		(ts.isPrefixUnaryExpression(expression) || ts.isPostfixUnaryExpression(expression)) &&
		isUnaryAssignmentOperator(expression.operator)
	) {
		return luau.list.make(transformUnaryExpressionStatement(state, expression));
	}

	return wrapExpressionStatement(transformExpression(state, expression));
}

export function transformExpressionStatement(state: TransformState, node: ts.ExpressionStatement) {
	const expression = skipDownwards(node.expression);
	return transformExpressionStatementInner(state, expression);
}
