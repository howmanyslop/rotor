import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformExpression } from "../expressions/transformExpression.ts";

export function transformThrowStatement(state: TransformState, node: ts.ThrowStatement) {
	const args = new Array<luau.Expression>();
	if (node.expression !== undefined) {
		args.push(transformExpression(state, node.expression));
	}
	return luau.list.make(
		luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.call(luau.globals.error, args),
		}),
	);
}
