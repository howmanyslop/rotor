import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { assert } from "../../../Shared/util/assert.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { validateIdentifier } from "../../util/validateIdentifier.ts";
import { wrapStatementsAsGenerator } from "../../util/wrapStatementsAsGenerator.ts";
import { transformIdentifierDefined } from "../expressions/transformIdentifier.ts";
import { transformParameters } from "../transformParameters.ts";
import { transformStatementList } from "../transformStatementList.ts";

export function transformFunctionDeclaration(state: TransformState, node: ts.FunctionDeclaration) {
	if (!node.body) {
		return luau.list.make<luau.Statement>();
	}

	const isExportDefault = ts.hasSyntacticModifier(node, ts.ModifierFlags.ExportDefault);

	assert(node.name || isExportDefault);

	if (node.name) {
		validateIdentifier(state, node.name);
	}

	const name = node.name ? transformIdentifierDefined(state, node.name) : luau.id("default");

	let { statements, parameters, hasDotDotDot, varArgsData } = transformParameters(state, node);

	const restParam = varArgsData ? node.parameters.find(p => p.dotDotDotToken) : undefined;
	if (restParam && varArgsData) {
		state.registerOptimizableVarArgs(restParam, varArgsData);
	}

	luau.list.pushList(statements, transformStatementList(state, node.body, node.body.statements));

	if (restParam && varArgsData) {
		state.unregisterOptimizableVarArgs(restParam);
	}

	let localize = isExportDefault;
	if (node.name) {
		const symbol = state.typeChecker.getSymbolAtLocation(node.name);
		assert(symbol);
		localize = state.isHoisted.get(symbol) !== true;
	}

	const isAsync = ts.hasSyntacticModifier(node, ts.ModifierFlags.Async);

	if (node.asteriskToken) {
		if (isAsync) {
			DiagnosticService.addDiagnostic(errors.noAsyncGeneratorFunctions(node));
		}
		statements = wrapStatementsAsGenerator(state, node, statements, hasDotDotDot);
	}

	if (isAsync) {
		const right = luau.call(state.TS(node, "async"), [
			luau.create(luau.SyntaxKind.FunctionExpression, {
				hasDotDotDot,
				parameters,
				statements,
			}),
		]);
		if (localize) {
			return luau.list.make(
				luau.create(luau.SyntaxKind.VariableDeclaration, {
					left: name,
					right,
				}),
			);
		} else {
			return luau.list.make(
				luau.create(luau.SyntaxKind.Assignment, {
					left: name,
					operator: "=",
					right,
				}),
			);
		}
	} else {
		return luau.list.make(
			luau.create(luau.SyntaxKind.FunctionDeclaration, { localize, name, statements, parameters, hasDotDotDot }),
		);
	}
}
