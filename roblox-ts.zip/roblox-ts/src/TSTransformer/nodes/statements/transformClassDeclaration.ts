import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformClassLikeDeclaration } from "../class/transformClassLikeDeclaration.ts";

export function transformClassDeclaration(state: TransformState, node: ts.ClassDeclaration) {
	return transformClassLikeDeclaration(state, node).statements;
}
