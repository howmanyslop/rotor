import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import ts from "typescript";
import { describe, expect, it } from "vitest";

import { VirtualProject } from "../../../Project/index.ts";

// ElementFlags values from TypeScript:
// Required = 1, Optional = 2, Rest = 4, Variadic = 8, Variable = Rest | Variadic = 12

describe("LuaTuple variadic element detection", () => {
	it("Variable flag covers Rest", () => {
		expect(ts.ElementFlags.Rest & ts.ElementFlags.Variable).toBeTruthy();
	});

	it("Variable flag covers Variadic", () => {
		expect(ts.ElementFlags.Variadic & ts.ElementFlags.Variable).toBeTruthy();
	});

	it("Variable flag does not match Required", () => {
		expect(ts.ElementFlags.Required & ts.ElementFlags.Variable).toBeFalsy();
	});

	it("Variable flag does not match Optional", () => {
		expect(ts.ElementFlags.Optional & ts.ElementFlags.Variable).toBeFalsy();
	});

	it("combinedFlags with Variadic is detected as variable-length", () => {
		const combinedFlags = ts.ElementFlags.Required | ts.ElementFlags.Variadic;
		expect(combinedFlags & ts.ElementFlags.Variable).toBeTruthy();
	});

	it("combinedFlags with only fixed elements is not variable-length", () => {
		const combinedFlags = ts.ElementFlags.Required | ts.ElementFlags.Optional;
		expect(combinedFlags & ts.ElementFlags.Variable).toBeFalsy();
	});
});

// The compiler-types / types packages supply the globals MacroManager resolves
// ($range, Array, Map, the iteration protocol, ...). VirtualProject compiles
// with `noLib`, so the real .d.ts must be mirrored into its in-memory VFS.
const RBXTS_TYPE_ROOT = fileURLToPath(new URL("../../../../tests/node_modules/@rbxts", import.meta.url));
const TYPE_PACKAGES = ["types", "compiler-types"];

function mirrorTypePackages(project: VirtualProject): void {
	for (const pkg of TYPE_PACKAGES) {
		const walk = (dir: string): void => {
			for (const entry of fs.readdirSync(dir)) {
				const absolute = path.join(dir, entry);
				if (fs.statSync(absolute).isDirectory()) {
					walk(absolute);
					continue;
				}

				if (!entry.endsWith(".d.ts") && entry !== "package.json") {
					continue;
				}

				const relative = path.relative(RBXTS_TYPE_ROOT, absolute).split(path.sep).join("/");
				project.vfs.writeFile(`/node_modules/@rbxts/${relative}`, fs.readFileSync(absolute, "utf8"));
			}
		};
		walk(path.join(RBXTS_TYPE_ROOT, pkg));
	}
}

function compileRange(source: string): string {
	const project = new VirtualProject();
	mirrorTypePackages(project);
	return project.compileSource(source);
}

describe("transformForOfStatement $range step", () => {
	it("emits a clean negative literal step without an `or 1` guard", () => {
		const luau = compileRange("export {};\nfor (const i of $range(9, 1, -1)) {}\n");

		expect(luau).toMatch(/= 9, 1, -1 do/);
		expect(luau).not.toMatch(/or 1/);
	});

	it("keeps the `or 1` guard for a dynamic step", () => {
		const luau = compileRange("export {};\nlet step = -1;\nfor (const i of $range(9, 1, step)) {}\n");

		expect(luau).toMatch(/, step or 1 do/);
	});

	it("does not wrap a positive literal step", () => {
		const luau = compileRange("export {};\nfor (const i of $range(0, 9, 2)) {}\n");

		expect(luau).toMatch(/= 0, 9, 2 do/);
		expect(luau).not.toMatch(/or 1/);
	});

	it("omits the step entirely when none is given", () => {
		const luau = compileRange("export {};\nfor (const i of $range(1, 10)) {}\n");

		expect(luau).toMatch(/= 1, 10 do/);
		expect(luau).not.toMatch(/or 1/);
	});
});
