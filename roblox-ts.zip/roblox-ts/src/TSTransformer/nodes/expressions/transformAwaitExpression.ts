import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { skipDownwards } from "../../util/traversal.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformAwaitExpression(state: TransformState, node: ts.AwaitExpression) {
	return luau.call(state.TS(node, "await"), [transformExpression(state, skipDownwards(node.expression))]);
}
