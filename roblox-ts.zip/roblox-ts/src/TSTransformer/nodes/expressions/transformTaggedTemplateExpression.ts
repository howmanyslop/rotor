import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../../index.ts";
import { convertToIndexableExpression } from "../../util/convertToIndexableExpression.ts";
import { ensureTransformOrder } from "../../util/ensureTransformOrder.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformTaggedTemplateExpression(state: TransformState, node: ts.TaggedTemplateExpression) {
	const tagExp = transformExpression(state, node.tag);

	if (ts.isTemplateExpression(node.template)) {
		const strings = new Array<luau.Expression>();
		strings.push(luau.string(node.template.head.text));
		for (const templateSpan of node.template.templateSpans) {
			strings.push(luau.string(templateSpan.literal.text));
		}

		const expressions = ensureTransformOrder(
			state,
			node.template.templateSpans.map(templateSpan => templateSpan.expression),
		);

		return luau.call(convertToIndexableExpression(tagExp), [luau.array(strings), ...expressions]);
	} else {
		return luau.call(convertToIndexableExpression(tagExp), [luau.array([luau.string(node.template.text)])]);
	}
}
