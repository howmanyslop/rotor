import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../../index.ts";
import { addIndexDiagnostics } from "../../util/addIndexDiagnostics.ts";
import { convertToIndexableExpression } from "../../util/convertToIndexableExpression.ts";
import { getConstantValueLiteral } from "../../util/getConstantValueLiteral.ts";
import { skipUpwards } from "../../util/traversal.ts";
import { validateNotAnyType } from "../../util/validateNotAny.ts";
import { transformOptionalChain } from "../transformOptionalChain.ts";

export function transformPropertyAccessExpressionInner(
	state: TransformState,
	node: ts.PropertyAccessExpression,
	expression: luau.Expression,
	name: string,
) {
	// a in a.b
	validateNotAnyType(state, node.expression);

	addIndexDiagnostics(state, node, state.typeChecker.getNonOptionalType(state.getType(node)));

	if (ts.isDeleteExpression(skipUpwards(node).parent)) {
		state.prereq(
			luau.create(luau.SyntaxKind.Assignment, {
				left: luau.property(convertToIndexableExpression(expression), name),
				operator: "=",
				right: luau.nil(),
			}),
		);
		return luau.none();
	}

	return luau.property(convertToIndexableExpression(expression), name);
}

export function transformPropertyAccessExpression(state: TransformState, node: ts.PropertyAccessExpression) {
	const constantValue = getConstantValueLiteral(state, node);
	if (constantValue) {
		return constantValue;
	}

	return transformOptionalChain(state, node);
}
