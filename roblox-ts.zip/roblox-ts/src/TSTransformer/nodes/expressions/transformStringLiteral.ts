import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { createStringFromLiteral } from "../../util/createStringFromLiteral.ts";

export function transformStringLiteral(state: TransformState, node: ts.StringLiteral) {
	return luau.string(createStringFromLiteral(node));
}
