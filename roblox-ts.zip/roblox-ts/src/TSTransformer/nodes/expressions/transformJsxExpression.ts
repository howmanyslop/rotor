import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformJsxExpression(state: TransformState, node: ts.JsxExpression) {
	if (node.expression) {
		const expression = transformExpression(state, node.expression);
		if (node.dotDotDotToken) {
			return luau.call(luau.globals.unpack, [expression]);
		}
		return expression;
	}
	return luau.none();
}
