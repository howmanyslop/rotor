import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { convertToIndexableExpression } from "../../util/convertToIndexableExpression.ts";
import { ensureTransformOrder } from "../../util/ensureTransformOrder.ts";
import { getFirstConstructSymbol } from "../../util/types.ts";
import { validateNotAnyType } from "../../util/validateNotAny.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformNewExpression(state: TransformState, node: ts.NewExpression) {
	validateNotAnyType(state, node.expression);

	const symbol = getFirstConstructSymbol(state, node.expression);
	if (symbol) {
		const macro = state.services.macroManager.getConstructorMacro(symbol);
		if (macro) {
			return macro(state, node);
		}
	}

	const expression = convertToIndexableExpression(transformExpression(state, node.expression));
	const args = node.arguments ? ensureTransformOrder(state, node.arguments) : [];
	return luau.call(luau.property(expression, "new"), args);
}
