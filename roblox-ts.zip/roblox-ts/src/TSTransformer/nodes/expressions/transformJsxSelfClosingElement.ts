import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformJsx } from "../jsx/transformJsx.ts";

export function transformJsxSelfClosingElement(state: TransformState, node: ts.JsxSelfClosingElement) {
	return transformJsx(state, node, node.tagName, node.attributes, []);
}
