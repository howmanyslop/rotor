import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { wrapStatementsAsGenerator } from "../../util/wrapStatementsAsGenerator.ts";
import { transformReturnStatementInner } from "../statements/transformReturnStatement.ts";
import { transformParameters } from "../transformParameters.ts";
import { transformStatementList } from "../transformStatementList.ts";

export function transformFunctionExpression(state: TransformState, node: ts.FunctionExpression | ts.ArrowFunction) {
	if (node.name) {
		DiagnosticService.addDiagnostic(errors.noFunctionExpressionName(node.name));
	}

	let { statements, parameters, hasDotDotDot, varArgsData } = transformParameters(state, node);

	const restParam = varArgsData ? node.parameters.find(p => p.dotDotDotToken) : undefined;
	if (restParam && varArgsData) {
		state.registerOptimizableVarArgs(restParam, varArgsData);
	}

	const body = node.body;
	if (ts.isFunctionBody(body)) {
		luau.list.pushList(statements, transformStatementList(state, body, body.statements));
	} else {
		const [returnStatements, prereqs] = state.capture(() => transformReturnStatementInner(state, body));
		luau.list.pushList(statements, prereqs);
		luau.list.pushList(statements, returnStatements);
	}

	if (restParam && varArgsData) {
		state.unregisterOptimizableVarArgs(restParam);
	}

	const isAsync = ts.hasSyntacticModifier(node, ts.ModifierFlags.Async);

	if (node.asteriskToken) {
		if (isAsync) {
			DiagnosticService.addDiagnostic(errors.noAsyncGeneratorFunctions(node));
		}
		statements = wrapStatementsAsGenerator(state, node, statements, hasDotDotDot);
	}

	let expression: luau.Expression = luau.create(luau.SyntaxKind.FunctionExpression, {
		hasDotDotDot,
		parameters,
		statements,
	});

	if (isAsync) {
		expression = luau.call(state.TS(node, "async"), [expression]);
	}

	return expression;
}
