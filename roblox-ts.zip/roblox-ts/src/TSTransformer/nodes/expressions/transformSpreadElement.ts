import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { assert } from "../../../Shared/util/assert.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { getAddIterableToArrayBuilder } from "../../util/getAddIterableToArrayBuilder.ts";
import { isArrayType, isDefinitelyType } from "../../util/types.ts";
import { validateNotAnyType } from "../../util/validateNotAny.ts";
import { simplifyUnpackOfArray } from "../../util/varArgsHelpers.ts";
import { tryHandleVarArgsArraySpread } from "../../util/varArgsOptimization.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformSpreadElement(state: TransformState, node: ts.SpreadElement) {
	validateNotAnyType(state, node.expression);

	// array literal is caught and handled separately in transformArrayLiteralExpression.ts
	assert(!ts.isArrayLiteralExpression(node.parent) && node.parent.arguments);
	if (node.parent.arguments[node.parent.arguments.length - 1] !== node) {
		DiagnosticService.addDiagnostic(errors.noPrecedingSpreadElement(node));
	}

	const varArgsResult = tryHandleVarArgsArraySpread(state, node);
	if (varArgsResult) return varArgsResult;

	const expression = transformExpression(state, node.expression);

	const type = state.getType(node.expression);
	if (isDefinitelyType(type, isArrayType(state))) {
		const unpackCall = luau.call(luau.globals.unpack, [expression]);
		return simplifyUnpackOfArray(unpackCall) ?? unpackCall;
	} else {
		const addIterableToArrayBuilder = getAddIterableToArrayBuilder(state, node.expression, type);
		const arrayId = state.pushToVar(luau.array(), "array");
		const lengthId = state.pushToVar(luau.number(0), "length");
		state.prereqList(addIterableToArrayBuilder(state, expression, arrayId, lengthId, 0, false));
		return luau.call(luau.globals.unpack, [arrayId]);
	}
}
