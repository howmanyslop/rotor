import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformTypeExpression(
	state: TransformState,
	node:
		| ts.AsExpression
		| ts.NonNullExpression
		| ts.SatisfiesExpression
		| ts.TypeAssertion
		| ts.ExpressionWithTypeArguments,
) {
	return transformExpression(state, node.expression);
}
