import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../classes/TransformState.ts";
import { transformInterpolatedStringPart } from "../transformInterpolatedStringPart.ts";

// backtick string literals without interpolation expressions should be preserved
// as they still are valid in luau
export function transformNoSubstitutionTemplateLiteral(state: TransformState, node: ts.NoSubstitutionTemplateLiteral) {
	return luau.create(luau.SyntaxKind.InterpolatedString, {
		parts: luau.list.make(transformInterpolatedStringPart(node)),
	});
}
