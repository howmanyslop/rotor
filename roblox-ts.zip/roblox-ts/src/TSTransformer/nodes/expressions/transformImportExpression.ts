import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../classes/TransformState.ts";
import { createImportExpression } from "../../util/createImportExpression.ts";

export function transformImportExpression(state: TransformState, node: ts.CallExpression) {
	const moduleSpecifier = node.arguments[0];

	if (!moduleSpecifier || !ts.isStringLiteral(moduleSpecifier)) {
		DiagnosticService.addDiagnostic(errors.noNonStringModuleSpecifier(node));
		return luau.none();
	}

	const importExpression = createImportExpression(state, node.getSourceFile(), moduleSpecifier);
	const resolveId = luau.id("resolve");

	return luau.call(luau.property(state.TS(node, "Promise"), "new"), [
		luau.create(luau.SyntaxKind.FunctionExpression, {
			hasDotDotDot: false,
			parameters: luau.list.make(resolveId),
			statements: luau.list.make(
				luau.create(luau.SyntaxKind.CallStatement, {
					expression: luau.call(resolveId, [importExpression]),
				}),
			),
		}),
	]);
}
