import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { SYMBOL_NAMES } from "../../index.ts";

export function transformThisExpression(state: TransformState, node: ts.ThisExpression) {
	const symbol = state.typeChecker.getSymbolAtLocation(node);
	if (symbol === state.services.macroManager.getSymbolOrThrow(SYMBOL_NAMES.globalThis)) {
		DiagnosticService.addDiagnostic(errors.noGlobalThis(node));
	}

	if (symbol) {
		const container = ts.getThisContainer(node, false, false);

		// ts.hasStaticModifier doesn't work on static blocks
		const isStatic = ts.hasStaticModifier(container) || ts.isClassStaticBlockDeclaration(container);

		// MethodDeclaration creates it's own implicit this
		if (isStatic && !ts.isMethodDeclaration(container) && ts.isClassLike(container.parent)) {
			const identifier = state.classIdentifierMap.get(container.parent);
			if (identifier) {
				return identifier;
			}
		}
	}

	return luau.globals.self;
}
