import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { isUsedAsStatement } from "../../util/isUsedAsStatement.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformDeleteExpression(state: TransformState, node: ts.DeleteExpression) {
	// we just want the prereqs, deleting is done in the index expression transforms
	transformExpression(state, node.expression);
	return !isUsedAsStatement(node) ? luau.bool(true) : luau.none();
}
