import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { assert } from "../../../Shared/util/assert.ts";
import type { TransformState } from "../../index.ts";
import { convertToIndexableExpression } from "../../util/convertToIndexableExpression.ts";
import { transformJsxChildren } from "../jsx/transformJsxChildren.ts";
import { transformEntityName } from "../transformEntityName.ts";

export function transformJsxFragment(state: TransformState, node: ts.JsxFragment) {
	const jsxFactoryEntity = state.resolver.getJsxFactoryEntity(node);
	assert(jsxFactoryEntity, "Expected jsxFactoryEntity to be defined");

	const createElementExpression = convertToIndexableExpression(transformEntityName(state, jsxFactoryEntity));

	// getJsxFragmentFactoryEntity() doesn't seem to default to "Fragment"..
	// but the typechecker does, so we should follow that behavior
	const jsxFragmentFactoryEntity =
		state.resolver.getJsxFragmentFactoryEntity(node) ??
		ts.parseIsolatedEntityName("Fragment", ts.ScriptTarget.ESNext);
	assert(jsxFragmentFactoryEntity, "Unable to find valid jsxFragmentFactoryEntity");

	const args = [transformEntityName(state, jsxFragmentFactoryEntity)];

	const transformedChildren = transformJsxChildren(state, node.children);

	// props parameter
	if (transformedChildren.length > 0) {
		args.push(luau.nil());
	}

	args.push(...transformedChildren);

	return luau.call(createElementExpression, args);
}
