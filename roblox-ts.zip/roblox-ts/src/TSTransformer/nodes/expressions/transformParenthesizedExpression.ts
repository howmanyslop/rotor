import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { skipDownwards } from "../../util/traversal.ts";
import { transformExpression } from "./transformExpression.ts";

export function transformParenthesizedExpression(state: TransformState, node: ts.ParenthesizedExpression) {
	const expression = transformExpression(state, skipDownwards(node.expression));
	if (luau.isSimple(expression)) {
		return expression;
	} else {
		return luau.create(luau.SyntaxKind.ParenthesizedExpression, { expression });
	}
}
