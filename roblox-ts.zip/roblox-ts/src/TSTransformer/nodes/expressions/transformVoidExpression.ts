import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { skipDownwards } from "../../util/traversal.ts";
import { transformExpressionStatementInner } from "../statements/transformExpressionStatement.ts";

export function transformVoidExpression(state: TransformState, node: ts.VoidExpression) {
	state.prereqList(transformExpressionStatementInner(state, skipDownwards(node.expression)));
	return luau.create(luau.SyntaxKind.NilLiteral, {});
}
