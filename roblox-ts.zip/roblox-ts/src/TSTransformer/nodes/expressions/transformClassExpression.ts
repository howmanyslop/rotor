import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformClassLikeDeclaration } from "../class/transformClassLikeDeclaration.ts";

export function transformClassExpression(state: TransformState, node: ts.ClassExpression) {
	const { statements, name } = transformClassLikeDeclaration(state, node);
	state.prereqList(statements);
	return name;
}
