import type ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformJsx } from "../jsx/transformJsx.ts";

export function transformJsxElement(state: TransformState, node: ts.JsxElement) {
	return transformJsx(state, node, node.openingElement.tagName, node.openingElement.attributes, node.children);
}
