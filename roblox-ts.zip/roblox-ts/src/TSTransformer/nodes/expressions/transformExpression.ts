import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { DiagnosticFactory } from "../../../Shared/diagnostics.ts";
import { errors } from "../../../Shared/diagnostics.ts";
import { assert } from "../../../Shared/util/assert.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { getKindName } from "../../util/getKindName.ts";
import { transformArrayLiteralExpression } from "./transformArrayLiteralExpression.ts";
import { transformAwaitExpression } from "./transformAwaitExpression.ts";
import { transformBinaryExpression } from "./transformBinaryExpression.ts";
import { transformFalseKeyword, transformTrueKeyword } from "./transformBooleanLiteral.ts";
import { transformCallExpression } from "./transformCallExpression.ts";
import { transformClassExpression } from "./transformClassExpression.ts";
import { transformConditionalExpression } from "./transformConditionalExpression.ts";
import { transformDeleteExpression } from "./transformDeleteExpression.ts";
import { transformElementAccessExpression } from "./transformElementAccessExpression.ts";
import { transformFunctionExpression } from "./transformFunctionExpression.ts";
import { transformIdentifier } from "./transformIdentifier.ts";
import { transformJsxElement } from "./transformJsxElement.ts";
import { transformJsxExpression } from "./transformJsxExpression.ts";
import { transformJsxFragment } from "./transformJsxFragment.ts";
import { transformJsxSelfClosingElement } from "./transformJsxSelfClosingElement.ts";
import { transformNewExpression } from "./transformNewExpression.ts";
import { transformNoSubstitutionTemplateLiteral } from "./transformNoSubstitutionTemplateLiteral.ts";
import { transformNumericLiteral } from "./transformNumericLiteral.ts";
import { transformObjectLiteralExpression } from "./transformObjectLiteralExpression.ts";
import { transformOmittedExpression } from "./transformOmittedExpression.ts";
import { transformParenthesizedExpression } from "./transformParenthesizedExpression.ts";
import { transformPropertyAccessExpression } from "./transformPropertyAccessExpression.ts";
import { transformSpreadElement } from "./transformSpreadElement.ts";
import { transformStringLiteral } from "./transformStringLiteral.ts";
import { transformSuperKeyword } from "./transformSuperKeyword.ts";
import { transformTaggedTemplateExpression } from "./transformTaggedTemplateExpression.ts";
import { transformTemplateExpression } from "./transformTemplateExpression.ts";
import { transformThisExpression } from "./transformThisExpression.ts";
import { transformTypeExpression } from "./transformTypeExpression.ts";
import { transformPostfixUnaryExpression, transformPrefixUnaryExpression } from "./transformUnaryExpression.ts";
import { transformVoidExpression } from "./transformVoidExpression.ts";
import { transformYieldExpression } from "./transformYieldExpression.ts";

const NO_EMIT = () => luau.none();

const DIAGNOSTIC = (factory: DiagnosticFactory) => (state: TransformState, node: ts.Expression) => {
	DiagnosticService.addDiagnostic(factory(node));
	return NO_EMIT();
};

type Validate<T> = {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- typecheck only works with `any`
	[k in keyof T]: T[k] extends [infer Kind, infer C extends (...args: any) => unknown]
		? "kind" extends keyof Parameters<C>[1]
			? Kind extends Parameters<C>[1]["kind"]
				? T[k]
				: never
			: T[k]
		: never;
};

function createTransformerMap<
	T extends Array<
		[ts.SyntaxKind, { bivariant(state: TransformState, exp: ts.Expression): luau.Expression }["bivariant"]]
	>,
>(values: Validate<[...T]>): Map<ts.SyntaxKind, (state: TransformState, exp: ts.Expression) => luau.Expression> {
	return new Map(values);
}

const TRANSFORMER_BY_KIND = createTransformerMap([
	// banned expressions
	[ts.SyntaxKind.BigIntLiteral, DIAGNOSTIC(errors.noBigInt)],
	[ts.SyntaxKind.NullKeyword, DIAGNOSTIC(errors.noNullLiteral)],
	[ts.SyntaxKind.PrivateIdentifier, DIAGNOSTIC(errors.noPrivateIdentifier)],
	[ts.SyntaxKind.RegularExpressionLiteral, DIAGNOSTIC(errors.noRegex)],
	[ts.SyntaxKind.TypeOfExpression, DIAGNOSTIC(errors.noTypeOfExpression)],

	// skip transforms
	[ts.SyntaxKind.ImportKeyword, NO_EMIT],

	// regular transforms
	[ts.SyntaxKind.ArrayLiteralExpression, transformArrayLiteralExpression],
	[ts.SyntaxKind.ArrowFunction, transformFunctionExpression],
	[ts.SyntaxKind.AsExpression, transformTypeExpression],
	[ts.SyntaxKind.AwaitExpression, transformAwaitExpression],
	[ts.SyntaxKind.BinaryExpression, transformBinaryExpression],
	[ts.SyntaxKind.CallExpression, transformCallExpression],
	[ts.SyntaxKind.ClassExpression, transformClassExpression],
	[ts.SyntaxKind.ConditionalExpression, transformConditionalExpression],
	[ts.SyntaxKind.DeleteExpression, transformDeleteExpression],
	[ts.SyntaxKind.ElementAccessExpression, transformElementAccessExpression],
	[ts.SyntaxKind.ExpressionWithTypeArguments, transformTypeExpression],
	[ts.SyntaxKind.FalseKeyword, transformFalseKeyword],
	[ts.SyntaxKind.FunctionExpression, transformFunctionExpression],
	[ts.SyntaxKind.Identifier, transformIdentifier],
	[ts.SyntaxKind.JsxElement, transformJsxElement],
	[ts.SyntaxKind.JsxExpression, transformJsxExpression],
	[ts.SyntaxKind.JsxFragment, transformJsxFragment],
	[ts.SyntaxKind.JsxSelfClosingElement, transformJsxSelfClosingElement],
	[ts.SyntaxKind.NewExpression, transformNewExpression],
	[ts.SyntaxKind.NonNullExpression, transformTypeExpression],
	[ts.SyntaxKind.NoSubstitutionTemplateLiteral, transformNoSubstitutionTemplateLiteral],
	[ts.SyntaxKind.NumericLiteral, transformNumericLiteral],
	[ts.SyntaxKind.ObjectLiteralExpression, transformObjectLiteralExpression],
	[ts.SyntaxKind.OmittedExpression, transformOmittedExpression],
	[ts.SyntaxKind.ParenthesizedExpression, transformParenthesizedExpression],
	[ts.SyntaxKind.PostfixUnaryExpression, transformPostfixUnaryExpression],
	[ts.SyntaxKind.PrefixUnaryExpression, transformPrefixUnaryExpression],
	[ts.SyntaxKind.PropertyAccessExpression, transformPropertyAccessExpression],
	[ts.SyntaxKind.SatisfiesExpression, transformTypeExpression],
	[ts.SyntaxKind.SpreadElement, transformSpreadElement],
	[ts.SyntaxKind.StringLiteral, transformStringLiteral],
	[ts.SyntaxKind.SuperKeyword, transformSuperKeyword],
	[ts.SyntaxKind.TaggedTemplateExpression, transformTaggedTemplateExpression],
	[ts.SyntaxKind.TemplateExpression, transformTemplateExpression],
	[ts.SyntaxKind.ThisKeyword, transformThisExpression],
	[ts.SyntaxKind.TrueKeyword, transformTrueKeyword],
	[ts.SyntaxKind.TypeAssertionExpression, transformTypeExpression],
	[ts.SyntaxKind.VoidExpression, transformVoidExpression],
	[ts.SyntaxKind.YieldExpression, transformYieldExpression],
]);

export function transformExpression(state: TransformState, node: ts.Expression): luau.Expression {
	const transformer = TRANSFORMER_BY_KIND.get(node.kind);
	if (transformer) {
		return transformer(state, node);
	}
	assert(false, `Unknown expression: ${getKindName(node.kind)}`);
}
