import luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../../index.ts";
import { transformIdentifierDefined } from "../expressions/transformIdentifier.ts";
import { transformArrayBindingPattern } from "./transformArrayBindingPattern.ts";
import { transformObjectBindingPattern } from "./transformObjectBindingPattern.ts";

export function transformBindingName(
	state: TransformState,
	name: ts.BindingName,
	initializers: luau.List<luau.Statement>,
) {
	let id: luau.AnyIdentifier;
	if (ts.isIdentifier(name)) {
		id = transformIdentifierDefined(state, name);
	} else {
		id = luau.tempId("binding");
		luau.list.pushList(
			initializers,
			state.capturePrereqs(() => {
				if (ts.isArrayBindingPattern(name)) {
					transformArrayBindingPattern(state, name, id);
				} else {
					transformObjectBindingPattern(state, name, id);
				}
			}),
		);
	}
	return id;
}
