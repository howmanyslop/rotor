import type luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import { errors } from "../../../Shared/diagnostics.ts";
import { assert } from "../../../Shared/util/assert.ts";
import { DiagnosticService } from "../../classes/DiagnosticService.ts";
import type { TransformState } from "../../index.ts";
import { objectAccessor } from "../../util/binding/objectAccessor.ts";
import { spreadDestructureObject } from "../../util/spreadDestructuring/index.ts";
import { isPossiblyType, isRobloxType } from "../../util/types.ts";
import { validateNotAnyType } from "../../util/validateNotAny.ts";
import { transformVariable } from "../statements/transformVariableStatement.ts";
import { transformInitializer } from "../transformInitializer.ts";
import { transformArrayBindingPattern } from "./transformArrayBindingPattern.ts";

export function transformObjectBindingPattern(
	state: TransformState,
	bindingPattern: ts.ObjectBindingPattern,
	parentId: luau.AnyIdentifier,
) {
	validateNotAnyType(state, bindingPattern);
	const preSpreadNames = new Array<luau.Expression>();
	for (const element of bindingPattern.elements) {
		const name = element.name;
		const prop = element.propertyName;
		const isSpread = element.dotDotDotToken !== undefined;

		if (ts.isIdentifier(name)) {
			const value = isSpread
				? spreadDestructureObject(state, parentId, preSpreadNames)
				: objectAccessor(state, parentId, state.getType(bindingPattern), prop ?? name);
			preSpreadNames.push(value);

			if (isSpread && isPossiblyType(state.getType(bindingPattern), isRobloxType(state))) {
				DiagnosticService.addDiagnostic(errors.noRestSpreadingOfRobloxTypes(element));
				continue;
			}

			const id = transformVariable(state, name, value);
			if (element.initializer) {
				state.prereq(transformInitializer(state, id, element.initializer));
			}
		} else {
			// if name is not identifier, it must be a binding pattern
			// in that case, prop is guaranteed to exist
			assert(prop);
			assert(!isSpread);
			const value = objectAccessor(state, parentId, state.getType(bindingPattern), prop);
			preSpreadNames.push(value);

			const id = state.pushToVar(value, "binding");
			if (element.initializer) {
				state.prereq(transformInitializer(state, id, element.initializer));
			}
			if (ts.isArrayBindingPattern(name)) {
				transformArrayBindingPattern(state, name, id);
			} else {
				transformObjectBindingPattern(state, name, id);
			}
		}
	}
}
