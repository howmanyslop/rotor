import type luau from "@roblox-ts/luau-ast";
import ts from "typescript";

import type { TransformState } from "../../index.ts";
import { getAccessorForBindingType } from "../../util/binding/getAccessorForBindingType.ts";
import { getSpreadDestructorForType } from "../../util/spreadDestructuring/index.ts";
import { validateNotAnyType } from "../../util/validateNotAny.ts";
import { transformVariable } from "../statements/transformVariableStatement.ts";
import { transformInitializer } from "../transformInitializer.ts";
import { transformObjectBindingPattern } from "./transformObjectBindingPattern.ts";

export function transformArrayBindingPattern(
	state: TransformState,
	bindingPattern: ts.ArrayBindingPattern,
	parentId: luau.AnyIdentifier,
) {
	validateNotAnyType(state, bindingPattern);

	let index = 0;
	const idStack = new Array<luau.AnyIdentifier>();
	const accessor = getAccessorForBindingType(state, bindingPattern, state.getType(bindingPattern));
	const destructor = getSpreadDestructorForType(state, bindingPattern, state.getType(bindingPattern));

	for (const element of bindingPattern.elements) {
		if (ts.isOmittedExpression(element)) {
			accessor(state, parentId, index, idStack, true);
		} else {
			const name = element.name;

			const isSpreadElement = element.dotDotDotToken !== undefined;
			const value = isSpreadElement
				? destructor(state, parentId, index, idStack)
				: accessor(state, parentId, index, idStack, false);

			if (ts.isIdentifier(name)) {
				const id = transformVariable(state, name, value);
				if (element.initializer) {
					state.prereq(transformInitializer(state, id, element.initializer));
				}
			} else {
				const id = state.pushToVar(value, "binding");
				if (element.initializer) {
					state.prereq(transformInitializer(state, id, element.initializer));
				}
				if (ts.isArrayBindingPattern(name)) {
					transformArrayBindingPattern(state, name, id);
				} else {
					transformObjectBindingPattern(state, name, id);
				}
			}
		}
		index++;
	}
}
