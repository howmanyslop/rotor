import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import { assert } from "../../../Shared/util/assert.ts";
import type { TransformState } from "../../index.ts";
import { convertToIndexableExpression } from "../../util/convertToIndexableExpression.ts";
import type { MapPointer } from "../../util/pointer.ts";
import { createMapPointer } from "../../util/pointer.ts";
import { transformEntityName } from "../transformEntityName.ts";
import { transformJsxAttributes } from "./transformJsxAttributes.ts";
import { transformJsxChildren } from "./transformJsxChildren.ts";
import { transformJsxTagName } from "./transformJsxTagName.ts";

export function transformJsx(
	state: TransformState,
	node: ts.JsxElement | ts.JsxSelfClosingElement,
	tagName: ts.JsxTagNameExpression,
	attributes: ts.JsxAttributes,
	children: ReadonlyArray<ts.JsxChild>,
) {
	// jsxFactoryEntity seems to always be defined and will default to `React.createElement`
	const jsxFactoryEntity = state.resolver.getJsxFactoryEntity(node);
	assert(jsxFactoryEntity, "Expected jsxFactoryEntity to be defined");

	const createElementExpression = convertToIndexableExpression(transformEntityName(state, jsxFactoryEntity));

	const tagNameExp = transformJsxTagName(state, tagName);

	let attributesPtr: MapPointer | undefined;
	if (attributes.properties.length > 0) {
		attributesPtr = createMapPointer("attributes");
		transformJsxAttributes(state, attributes, attributesPtr);
	}

	const transformedChildren = transformJsxChildren(state, children);

	const args = [tagNameExp];

	if (attributesPtr) {
		args.push(attributesPtr.value);
	} else if (transformedChildren.length > 0) {
		args.push(luau.nil());
	}

	args.push(...transformedChildren);

	return luau.call(createElementExpression, args);
}
