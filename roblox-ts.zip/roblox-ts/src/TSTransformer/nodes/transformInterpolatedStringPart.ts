import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import { createStringFromLiteral } from "../util/createStringFromLiteral.ts";

export function transformInterpolatedStringPart(node: ts.TemplateLiteralToken | ts.StringLiteral) {
	return luau.create(luau.SyntaxKind.InterpolatedStringPart, { text: createStringFromLiteral(node) });
}
