import luau from "@roblox-ts/luau-ast";
import type ts from "typescript";

import type { TransformState } from "../index.ts";
import { transformExpression } from "./expressions/transformExpression.ts";

export function transformInitializer(state: TransformState, id: luau.WritableExpression, initializer: ts.Expression) {
	return luau.create(luau.SyntaxKind.IfStatement, {
		condition: luau.binary(id, "==", luau.nil()),
		elseBody: luau.list.make(),
		statements: state.capturePrereqs(() => {
			state.prereq(
				luau.create(luau.SyntaxKind.Assignment, {
					left: id,
					operator: "=",
					right: transformExpression(state, initializer),
				}),
			);
		}),
	});
}
