import path from "path";
import ts from "typescript";

import type { ProjectOptions } from "../../Shared/types.ts";
import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { profile, profileAsync } from "../../Shared/util/profile.ts";
import { applyRbxtscBuildInfoPath } from "../../Shared/util/rbxtscBuildInfo.ts";
import { populateCrossProjectImportPathMap } from "../util/populateCrossProjectImportPathMap.ts";
import type { DrainContext } from "./drainInvalidatedProject.ts";
import { drainInvalidatedProject } from "./drainInvalidatedProject.ts";

export async function buildSolution(
	configPath: string,
	projectOptions: ProjectOptions,
	buildOptions: ts.BuildOptions,
): Promise<ts.ExitStatus> {
	return profileAsync("buildSolution TOTAL", () => buildSolutionImpl(configPath, projectOptions, buildOptions));
}

async function buildSolutionImpl(
	configPath: string,
	projectOptions: ProjectOptions,
	buildOptions: ts.BuildOptions,
): Promise<ts.ExitStatus> {
	const diagnosticReporter = ts.createDiagnosticReporter(ts.sys, projectOptions.verbose === true);
	const host = profile("buildSolution createSolutionBuilderHost", () =>
		ts.createSolutionBuilderHost(
			ts.sys,
			undefined,
			diagnosticReporter,
			ts.createBuilderStatusReporter(ts.sys, projectOptions.verbose === true),
		),
	);
	// Install a per-project tsconfig parser so every project in the solution
	// graph (entry + referenced) routes its tsbuildinfo through the
	// rbxtsc-suffixed path. This is the single resolver boundary for --build —
	// SolutionBuilder calls getParsedCommandLine once per project (result is
	// cached), and the parsed options drive both emit (write) and the
	// up-to-date check (read) inside getNextInvalidatedProject. Must mutate
	// BEFORE the up-to-date check or the second build would read from the
	// wrong path. `createSolutionBuilderHost` leaves this hook unset by
	// default, so we provide a full implementation rather than wrapping.
	const parseConfigFileHost: ts.ParseConfigFileHost = {
		fileExists: ts.sys.fileExists,
		getCurrentDirectory: ts.sys.getCurrentDirectory,
		onUnRecoverableConfigFileDiagnostic: d => diagnosticReporter(d),
		readDirectory: ts.sys.readDirectory,
		readFile: ts.sys.readFile,
		useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
	};
	// Only `emitDeclarationOnly` of the BuildOptions surface translates to a
	// per-project CompilerOption rbxtsc cares about. Other build flags (force,
	// dry, verbose, …) drive SolutionBuilder behavior directly and don't need
	// to land on the parsed CompilerOptions.
	const optionsToExtend: ts.CompilerOptions = {};
	if (buildOptions.emitDeclarationOnly !== undefined) {
		optionsToExtend.emitDeclarationOnly = buildOptions.emitDeclarationOnly;
	}
	host.getParsedCommandLine = (fileName: string) => {
		const parsed = ts.getParsedCommandLineOfConfigFile(fileName, optionsToExtend, parseConfigFileHost);
		if (parsed) applyRbxtscBuildInfoPath(parsed.options);
		return parsed;
	};
	const builder = profile("buildSolution createSolutionBuilder", () =>
		ts.createSolutionBuilder(host, [configPath], buildOptions),
	);

	if (buildOptions.emitDeclarationOnly) {
		return profile("buildSolution builder.build(emitDeclarationOnly)", () => builder.build());
	}

	let hasAnyErrors = false;
	const importPathMap = new Map<string, string>();
	// Persists captured per-project but deferred until the entire solution loop
	// completes — subsequent projects' copyInclude can bump shared include/
	// dir mtimes that would invalidate caches written earlier in the loop.
	const pendingRojoCachePersists = new Array<() => void>();
	const pendingCopyFilesPersists = new Array<() => void>();
	const resolvedConfigPath = getCanonicalFileName(path.resolve(configPath));

	// A solution coordinator has no compilable files of its own — it exists only
	// to orchestrate referenced projects.  Every project in that graph should
	// keep the CLI-provided type/rojo because there is no "root" project to
	// distinguish from.
	const parsedConfig = ts.readConfigFile(configPath, ts.sys.readFile);
	if (parsedConfig.error) {
		// Surface the parse error so coordinator classification failures below
		// aren't silent. SolutionBuilder will also report this, but at that point
		// it's too late to flag that isSolutionCoordinator defaulted to false.
		diagnosticReporter(parsedConfig.error);
		hasAnyErrors = true;
	}
	const config = parsedConfig.config ?? {};
	const isSolutionCoordinator =
		Array.isArray(config.files) &&
		config.files.length === 0 &&
		!config.include &&
		Array.isArray(config.references) &&
		config.references.length > 0;

	const ctx: DrainContext = {
		projectOptions,
		resolvedConfigPath,
		isSolutionCoordinator,
		importPathMap,
		pendingRojoCachePersists,
		pendingCopyFilesPersists,
		diagnosticReporter,
	};

	// Pre-populate cross-project import paths for every referenced project in
	// the build order. Without this, a referenced project that's already
	// up-to-date (won't drain) leaves its source files out of `importPathMap`,
	// and dependents fall back to their own PathTranslator → wrong Rojo mount.
	// Drain's first-write-wins guard keeps these entries intact for projects
	// that don't drain; projects that DO drain still own and refresh their
	// own entries via importPathMapOwnership in watch mode.
	profile("buildSolution populateCrossProjectImportPathMap", () => {
		const buildOrder = ts.getBuildOrderFromAnyBuildOrder(builder.getBuildOrder());
		populateCrossProjectImportPathMap(
			buildOrder,
			fileName => host.getParsedCommandLine!(fileName),
			projectOptions,
			importPathMap,
		);
	});

	while (true) {
		const project = profile("buildSolution getNextInvalidatedProject", () => builder.getNextInvalidatedProject());
		if (!project) break;

		const outcome = await drainInvalidatedProject(project, ctx);
		if (outcome.hadErrors) hasAnyErrors = true;
	}

	profile("buildSolution persistRojoCaches", () => {
		for (const persist of pendingRojoCachePersists) persist();
	});
	profile("buildSolution persistCopyFilesGates", () => {
		for (const persist of pendingCopyFilesPersists) persist();
	});

	return hasAnyErrors ? ts.ExitStatus.DiagnosticsPresent_OutputsGenerated : ts.ExitStatus.Success;
}
