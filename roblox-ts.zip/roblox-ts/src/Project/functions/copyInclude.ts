import fs from "fs-extra";

import { INCLUDE_PATH, ProjectType } from "../../Shared/constants.ts";
import type { ProjectData } from "../../Shared/types.ts";
import { benchmarkIfVerbose } from "../../Shared/util/benchmark.ts";

export function copyInclude(data: ProjectData) {
	if (
		!data.projectOptions.noInclude &&
		data.projectOptions.type !== ProjectType.Package &&
		!(data.projectOptions.type === undefined && data.isPackage)
	) {
		benchmarkIfVerbose("copy include files", () =>
			fs.copySync(INCLUDE_PATH, data.projectOptions.includePath, { dereference: true }),
		);
	}
}
