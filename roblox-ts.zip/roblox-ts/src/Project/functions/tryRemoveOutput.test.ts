import { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { tryRemoveOutput } from "./tryRemoveOutput.ts";

const TMP_DIR = path.join(__dirname, "__tryRemoveOutput_tmp__");
const ROOT_DIR = path.join(TMP_DIR, "src");
const OUT_DIR = path.join(TMP_DIR, "out");

function createPathTranslator(opts: { declaration?: boolean } = {}) {
	return new PathTranslator(ROOT_DIR, OUT_DIR, undefined, opts.declaration ?? false, true);
}

function touch(...segments: Array<string>) {
	const filePath = path.join(...segments);
	fs.outputFileSync(filePath, "");
	return filePath;
}

describe("tryRemoveOutput", () => {
	beforeEach(() => {
		fs.mkdirpSync(ROOT_DIR);
		fs.mkdirpSync(OUT_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
	});

	it("removes orphaned .luau file with no source", () => {
		const outFile = touch(OUT_DIR, "orphan.luau");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, outFile);

		expect(fs.existsSync(outFile)).toBe(false);
	});

	it("keeps .luau file when source .ts exists", () => {
		touch(ROOT_DIR, "hello.ts");
		const outFile = touch(OUT_DIR, "hello.luau");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, outFile);

		expect(fs.existsSync(outFile)).toBe(true);
	});

	it("keeps .luau.map file when source .ts exists", () => {
		touch(ROOT_DIR, "hello.ts");
		touch(OUT_DIR, "hello.luau");
		const mapFile = touch(OUT_DIR, "hello.luau.map");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, mapFile);

		expect(fs.existsSync(mapFile)).toBe(true);
	});

	it("keeps .luau.map file when .luau missing but source .ts exists", () => {
		touch(ROOT_DIR, "hello.ts");
		// .luau output not yet emitted, but source exists — map should survive
		const mapFile = touch(OUT_DIR, "hello.luau.map");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, mapFile);

		expect(fs.existsSync(mapFile)).toBe(true);
	});

	it("removes .luau.map file when no source .ts exists", () => {
		const mapFile = touch(OUT_DIR, "orphan.luau.map");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, mapFile);

		expect(fs.existsSync(mapFile)).toBe(false);
	});

	it("never reaps rbxts.rojocache.json — owned by the disk-cache layer, not source", () => {
		const cacheFile = touch(OUT_DIR, "rbxts.rojocache.json");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, cacheFile);

		expect(fs.existsSync(cacheFile)).toBe(true);
	});

	it("never reaps rbxts.typeroots.rojocache.json — synthetic batch cache file", () => {
		const cacheFile = touch(OUT_DIR, "rbxts.typeroots.rojocache.json");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, cacheFile);

		expect(fs.existsSync(cacheFile)).toBe(true);
	});

	it("never reaps rbxts.copyfiles.json — owned by the copyFiles gate, not source", () => {
		const cacheFile = touch(OUT_DIR, "rbxts.copyfiles.json");
		const pt = createPathTranslator();

		tryRemoveOutput(pt, cacheFile);

		expect(fs.existsSync(cacheFile)).toBe(true);
	});
});
