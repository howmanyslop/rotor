import { describe, expect, it, vi } from "vitest";

import { createCompileGate } from "./compileGate.ts";

interface Deferred {
	promise: Promise<void>;
	resolve: () => void;
	reject: (error: unknown) => void;
}

function createDeferred(): Deferred {
	let resolve!: () => void;
	let reject!: (error: unknown) => void;
	const promise = new Promise<void>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

describe("createCompileGate", () => {
	it("runs a single trigger", async () => {
		const compileCalls = vi.fn(async () => {});
		const failures = new Array<unknown>();
		const gate = createCompileGate({
			runCompile: compileCalls,
			onFailure: error => failures.push(error),
		});

		gate.trigger();
		await gate.drain();

		expect(compileCalls).toHaveBeenCalledTimes(1);
		expect(failures).toEqual([]);
	});

	it("serializes overlapping triggers", async () => {
		const deferreds = new Array<Deferred>();
		let starts = 0;
		const gate = createCompileGate({
			runCompile: async () => {
				starts++;
				const d = createDeferred();
				deferreds.push(d);
				return d.promise;
			},
			onFailure: () => {},
		});

		gate.trigger();
		gate.trigger();
		gate.trigger();

		// One compile in flight; the other two collapse into pendingTrigger.
		// Give the event loop a tick to start the first.
		await new Promise(resolve => setTimeout(resolve, 0));
		expect(starts).toBe(1);

		// Release the first compile; the trailing one starts.
		deferreds[0]!.resolve();
		await new Promise(resolve => setTimeout(resolve, 0));
		expect(starts).toBe(2);

		// Release the trailing one; no third compile.
		deferreds[1]!.resolve();
		await gate.drain();
		expect(starts).toBe(2);
	});

	it("collapses N rapid triggers into one trailing compile", async () => {
		let starts = 0;
		const deferreds = new Array<Deferred>();
		const gate = createCompileGate({
			runCompile: async () => {
				starts++;
				const d = createDeferred();
				deferreds.push(d);
				return d.promise;
			},
			onFailure: () => {},
		});

		for (let i = 0; i < 10; i++) gate.trigger();
		await new Promise(resolve => setTimeout(resolve, 0));
		expect(starts).toBe(1);

		deferreds[0]!.resolve();
		await new Promise(resolve => setTimeout(resolve, 0));
		expect(starts).toBe(2);

		deferreds[1]!.resolve();
		await gate.drain();
		expect(starts).toBe(2);
	});

	it("does not start the next compile until the current one settles", async () => {
		const start = createDeferred();
		const inProgress = createDeferred();
		const ordering = new Array<string>();
		const gate = createCompileGate({
			runCompile: async () => {
				ordering.push(`start#${ordering.length}`);
				await start.promise;
				ordering.push(`end#${ordering.length}`);
				inProgress.resolve();
			},
			onFailure: () => {},
		});

		gate.trigger();
		gate.trigger();

		// Verify only the first compile has started.
		await new Promise(resolve => setTimeout(resolve, 0));
		expect(ordering).toEqual(["start#0"]);

		start.resolve();
		await gate.drain();

		// The trailing compile must run AFTER the first ends.
		expect(ordering).toEqual(["start#0", "end#1", "start#2", "end#3"]);
	});

	it("surfaces non-DiagnosticError throws via onFailure", async () => {
		const failures = new Array<unknown>();
		const synthetic = new Error("synthetic write failure");
		const gate = createCompileGate({
			runCompile: async () => {
				throw synthetic;
			},
			onFailure: error => failures.push(error),
		});

		gate.trigger();
		await gate.drain();
		expect(failures).toEqual([synthetic]);
	});

	it("clears inFlight after failure so the next trigger runs", async () => {
		const failures = new Array<unknown>();
		let cycle = 0;
		const gate = createCompileGate({
			runCompile: async () => {
				cycle++;
				if (cycle === 1) throw new Error("first cycle failure");
			},
			onFailure: error => failures.push(error),
		});

		gate.trigger();
		await gate.drain();
		expect(failures.length).toBe(1);

		gate.trigger();
		await gate.drain();
		expect(cycle).toBe(2);
		expect(failures.length).toBe(1);
	});

	it("does not collapse failure into the trailing compile", async () => {
		// Documents that a failure in compile #1 still allows compile #2 to
		// run when it was triggered during #1's flight.
		const failures = new Array<unknown>();
		const first = createDeferred();
		let cycle = 0;
		const gate = createCompileGate({
			runCompile: async () => {
				cycle++;
				if (cycle === 1) {
					await first.promise;
					throw new Error("first failed");
				}
			},
			onFailure: error => failures.push(error),
		});

		gate.trigger();
		await new Promise(resolve => setTimeout(resolve, 0));
		gate.trigger(); // pendingTrigger set while #1 is in flight
		first.resolve();
		await gate.drain();

		expect(cycle).toBe(2);
		expect(failures.length).toBe(1);
	});

	it("survives an onFailure that itself throws", async () => {
		// onFailure throwing must not wedge the gate: future triggers must
		// still run.
		let cycle = 0;
		const gate = createCompileGate({
			runCompile: async () => {
				cycle++;
				if (cycle === 1) throw new Error("first failed");
			},
			onFailure: () => {
				throw new Error("onFailure itself blew up");
			},
		});

		gate.trigger();
		await gate.drain();
		expect(cycle).toBe(1);

		gate.trigger();
		await gate.drain();
		expect(cycle).toBe(2);
	});
});
