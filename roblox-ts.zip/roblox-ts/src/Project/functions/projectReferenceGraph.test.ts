import path from "path";
import type ts from "typescript";
import { describe, expect, it } from "vitest";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import type { ProjectReferenceGraphHost } from "./projectReferenceGraph.ts";
import { buildProjectReferenceGraph } from "./projectReferenceGraph.ts";

interface GraphFixture {
	root: string;
	configs: ReadonlyArray<string>;
	references: Record<string, ReadonlyArray<string>>;
}

function canonicalize(p: string): string {
	return getCanonicalFileName(path.normalize(p));
}

function createFakeBuilder(fixture: GraphFixture): ts.SolutionBuilder<ts.EmitAndSemanticDiagnosticsBuilderProgram> {
	return {
		getBuildOrder: () => fixture.configs as unknown as ts.BuildOrder,
	} as unknown as ts.SolutionBuilder<ts.EmitAndSemanticDiagnosticsBuilderProgram>;
}

function createHost(fixture: GraphFixture): ProjectReferenceGraphHost {
	return {
		getParsedCommandLine: fileName => {
			const refs = fixture.references[fileName];
			if (refs === undefined) return undefined;
			return {
				options: {},
				fileNames: [],
				errors: [],
				projectReferences: refs.map(p => ({ path: p })),
			} as unknown as ts.ParsedCommandLine;
		},
	};
}

describe("buildProjectReferenceGraph", () => {
	it("returns empty set for an unreferenced project", () => {
		const fixture: GraphFixture = {
			root: "/repo",
			configs: ["/repo/a/tsconfig.json"],
			references: { "/repo/a/tsconfig.json": [] },
		};
		const graph = buildProjectReferenceGraph(createFakeBuilder(fixture), createHost(fixture));

		expect(graph.dependentsOf("/repo/a/tsconfig.json").size).toBe(0);
	});

	it("returns direct dependent for A->B reference", () => {
		const fixture: GraphFixture = {
			root: "/repo",
			configs: ["/repo/a/tsconfig.json", "/repo/b/tsconfig.json"],
			references: {
				"/repo/a/tsconfig.json": [],
				// B references A
				"/repo/b/tsconfig.json": ["/repo/a/tsconfig.json"],
			},
		};
		const graph = buildProjectReferenceGraph(createFakeBuilder(fixture), createHost(fixture));

		const dependents = graph.dependentsOf("/repo/a/tsconfig.json");
		expect(dependents.size).toBe(1);
		expect(dependents.has(canonicalize("/repo/b/tsconfig.json"))).toBe(true);
	});

	it("walks transitive A->B->C chain", () => {
		const fixture: GraphFixture = {
			root: "/repo",
			configs: ["/repo/a/tsconfig.json", "/repo/b/tsconfig.json", "/repo/c/tsconfig.json"],
			references: {
				"/repo/a/tsconfig.json": [],
				"/repo/b/tsconfig.json": ["/repo/a/tsconfig.json"],
				"/repo/c/tsconfig.json": ["/repo/b/tsconfig.json"],
			},
		};
		const graph = buildProjectReferenceGraph(createFakeBuilder(fixture), createHost(fixture));

		const dependents = graph.dependentsOf("/repo/a/tsconfig.json");
		expect(dependents.size).toBe(2);
		expect(dependents.has(canonicalize("/repo/b/tsconfig.json"))).toBe(true);
		expect(dependents.has(canonicalize("/repo/c/tsconfig.json"))).toBe(true);
	});

	it("resolves directory-style reference paths to tsconfig.json", () => {
		const fixture: GraphFixture = {
			root: "/repo",
			configs: ["/repo/a/tsconfig.json", "/repo/b/tsconfig.json"],
			references: {
				"/repo/a/tsconfig.json": [],
				"/repo/b/tsconfig.json": ["/repo/a"],
			},
		};
		const graph = buildProjectReferenceGraph(createFakeBuilder(fixture), createHost(fixture));

		expect(graph.dependentsOf("/repo/a/tsconfig.json").has(canonicalize("/repo/b/tsconfig.json"))).toBe(true);
	});

	it("normalizes path separators when looking up dependents", () => {
		const fixture: GraphFixture = {
			root: "/repo",
			configs: ["/repo/a/tsconfig.json", "/repo/b/tsconfig.json"],
			references: {
				"/repo/a/tsconfig.json": [],
				"/repo/b/tsconfig.json": ["/repo/a/tsconfig.json"],
			},
		};
		const graph = buildProjectReferenceGraph(createFakeBuilder(fixture), createHost(fixture));

		// Looking up via an un-normalized path must still hit.
		expect(graph.dependentsOf("/repo/a/sub/../tsconfig.json").size).toBe(1);
	});
});
