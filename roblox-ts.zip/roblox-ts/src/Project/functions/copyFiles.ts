import type { PathTranslator } from "@roblox-ts/path-translator";

import type { ProjectData } from "../../Shared/types.ts";
import { benchmarkIfVerbose } from "../../Shared/util/benchmark.ts";
import { copyItem } from "./copyItem.ts";

export function copyFiles(data: ProjectData, pathTranslator: PathTranslator, sources: Set<string>) {
	benchmarkIfVerbose("copy non-compiled files", () => {
		for (const source of sources) {
			copyItem(data, pathTranslator, source);
		}
	});
}
