import nodeFs from "fs";
import fs from "fs-extra";
import path from "path";
import type ts from "typescript";
import { describe, expect, it, onTestFinished } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { compileFiles } from "./compileFiles.ts";
import { createPathTranslator } from "./createPathTranslator.ts";
import { createProjectData } from "./createProjectData.ts";
import { createProjectProgram } from "./createProjectProgram.ts";
import { getChangedSourceFiles } from "./getChangedSourceFiles.ts";

// compileFiles is driven directly here — the same shape `setupProjectWatchProgram`
// uses. The `runRbxtsEmit` wrapper (build / --build) forces `declaration:false`
// for the duration of the Luau pass, so it never reaches the declaration emit
// this file is about.
const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/transformer-declarations");
const TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.json");
const RBXTS_TYPEROOT_SRC = path.resolve(__dirname, "../../..", "tests/node_modules/@rbxts/compiler-types");
const RBXTS_TYPEROOT_DEST = path.join(FIXTURE_DIR, "node_modules/@rbxts/compiler-types");
const OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

interface Visit {
	fileName: string;
	isDeclarationFile: boolean;
}

interface VisitRecorder {
	__declarationVisits?: Array<Visit>;
}

interface CompiledFixture {
	result: ts.EmitResult;
	visits: Array<Visit>;
}

function ensureCompilerTypes(): void {
	// validateCompilerOptions requires `<projectPath>/node_modules/@rbxts` to
	// match a typeRoot AND `types: ["compiler-types"]` to resolve on disk. Same
	// dereferenced copy the single-incremental fixture uses — git-bash symlinks
	// are not traversable by Node fs on Windows.
	if (nodeFs.existsSync(RBXTS_TYPEROOT_DEST)) return;
	nodeFs.mkdirSync(path.dirname(RBXTS_TYPEROOT_DEST), { recursive: true });
	fs.copySync(RBXTS_TYPEROOT_SRC, RBXTS_TYPEROOT_DEST, { dereference: true });
}

/**
 * Compiles the fixture and returns the emit result alongside the files the
 * plugin was invoked on. The plugin records onto `globalThis`, so the recorder
 * is seeded per call and torn down with the test rather than crossing into the
 * next one.
 */
async function compileFixture(): Promise<CompiledFixture> {
	ensureCompilerTypes();

	const recorder = globalThis as VisitRecorder;
	const visits = new Array<Visit>();
	recorder.__declarationVisits = visits;

	onTestFinished(() => {
		delete recorder.__declarationVisits;
		fs.removeSync(path.join(FIXTURE_DIR, "out"));
		fs.removeSync(path.join(FIXTURE_DIR, "include"));
	});

	const data = createProjectData(TSCONFIG, { ...OPTIONS });
	const program = createProjectProgram(data);
	const pathTranslator = createPathTranslator(program, data);
	const sourceFiles = getChangedSourceFiles(program, getRootDirs(program.getCompilerOptions()));
	const result = await compileFiles(program.getProgram(), data, pathTranslator, sourceFiles);

	return { result, visits };
}

describe("afterDeclarations transformer plugins", () => {
	it("runs the plugin over the emitted declaration file", async () => {
		expect.assertions(2);

		const { result } = await compileFixture();
		const declaration = fs.readFileSync(path.join(FIXTURE_DIR, "out/index.d.ts"), "utf-8");

		expect(result.emitSkipped).toBe(false);
		expect(declaration).toContain("__DECLARATION_MARKER__");
	});

	it("never invokes the plugin on a source file", async () => {
		expect.assertions(2);

		// Previously `flattenIntoTransformers` folded the afterDeclarations
		// bucket into the `ts.transformNodes` list, so the plugin saw `index.ts`
		// and its output was consumed by the Luau emit instead.
		const { visits } = await compileFixture();

		// TS keeps the original `.ts` name on the SourceFile it hands to the
		// declaration pass, so `isDeclarationFile` — not the extension — is what
		// distinguishes the two passes.
		expect(visits).not.toEqual([]);
		expect(visits.every(visit => visit.isDeclarationFile)).toBe(true);
	});

	it("keeps the declaration-only output out of the Luau emit", async () => {
		expect.assertions(1);

		await compileFixture();
		const luau = fs.readFileSync(path.join(FIXTURE_DIR, "out/init.luau"), "utf-8");

		expect(luau).not.toContain("__DECLARATION_MARKER__");
	});
});
