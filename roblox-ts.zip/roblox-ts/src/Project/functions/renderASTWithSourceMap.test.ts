import { originalPositionFor, TraceMap } from "@jridgewell/trace-mapping";
import luau from "@roblox-ts/luau-ast";
import { describe, expect, it } from "vitest";

import type { SourcePosition } from "../../Shared/types.ts";
import { renderASTWithSourceMap } from "./renderASTWithSourceMap.ts";

const emptyEndMap = new WeakMap<luau.Node, SourcePosition>();

describe("renderASTWithSourceMap", () => {
	it("produces valid V3 sourcemap with empty code for an empty AST", () => {
		const ast = luau.list.make<luau.Statement>();
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		expect(result.code).toBe("");
		expect(result.map.version).toBe(3);
		expect(result.map.file).toBe("output.luau");
		expect(result.map.sources).toEqual([]);
		expect(result.map.mappings).toBe("");
	});

	it("maps a single statement to its source position", () => {
		const stmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(42),
		});
		const ast = luau.list.make<luau.Statement>(stmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(stmt, { line: 5, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		expect(result.code).toContain("local x = 42");
		const traced = new TraceMap(result.map);
		const pos = originalPositionFor(traced, { line: 1, column: 0 });
		expect(pos.source).toBe("input.ts");
		expect(pos.line).toBe(6);
		expect(pos.column).toBe(0);
	});

	it("maps multiple statements to sequential output lines", () => {
		const stmt1 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("a"),
			right: luau.number(1),
		});
		const stmt2 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("b"),
			right: luau.number(2),
		});
		const ast = luau.list.make<luau.Statement>(stmt1, stmt2);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(stmt1, { line: 0, column: 0 });
		sourcePositionMap.set(stmt2, { line: 1, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		const traced = new TraceMap(result.map);
		const pos1 = originalPositionFor(traced, { line: 1, column: 0 });
		expect(pos1.line).toBe(1);
		const pos2 = originalPositionFor(traced, { line: 2, column: 0 });
		expect(pos2.line).toBe(2);
	});

	it("renders statements without source positions but does not map them", () => {
		const stmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("y"),
			right: luau.number(99),
		});
		const ast = luau.list.make<luau.Statement>(stmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		expect(result.code).toContain("local y = 99");
		const traced = new TraceMap(result.map);
		const pos = originalPositionFor(traced, { line: 1, column: 0 });
		expect(pos.source).toBeNull();
		expect(pos.line).toBeNull();
	});

	it("tracks output lines correctly across multi-line statements", () => {
		const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
			condition: luau.bool(true),
			statements: luau.list.make<luau.Statement>(
				luau.create(luau.SyntaxKind.VariableDeclaration, {
					left: luau.id("inner"),
					right: luau.number(1),
				}),
			),
			elseBody: luau.list.make<luau.Statement>(),
		});
		const afterStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("after"),
			right: luau.number(2),
		});
		const ast = luau.list.make<luau.Statement>(ifStmt, afterStmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
		sourcePositionMap.set(afterStmt, { line: 5, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// if/end takes 3 lines: "if true then\n\tlocal inner = 1\nend\n"
		// afterStmt starts on line 4
		const traced = new TraceMap(result.map);
		const posAfter = originalPositionFor(traced, { line: 4, column: 0 });
		expect(posAfter.line).toBe(6);
	});

	it("maps inner statements of a function declaration", () => {
		const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(1),
		});
		const funcDecl = luau.create(luau.SyntaxKind.FunctionDeclaration, {
			localize: true,
			name: luau.id("foo"),
			statements: luau.list.make<luau.Statement>(innerStmt),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const ast = luau.list.make<luau.Statement>(funcDecl);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(funcDecl, { line: 0, column: 0 });
		sourcePositionMap.set(innerStmt, { line: 1, column: 4 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: local function foo()
		// 2: \tlocal x = 1
		// 3: end
		const traced = new TraceMap(result.map);
		const funcPos = originalPositionFor(traced, { line: 1, column: 0 });
		expect(funcPos.line).toBe(1);

		const innerPos = originalPositionFor(traced, { line: 2, column: 0 });
		expect(innerPos.source).toBe("input.ts");
		expect(innerPos.line).toBe(2);
		expect(innerPos.column).toBe(4);
	});

	it("maps inner statements of an if statement", () => {
		const thenStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("a"),
			right: luau.number(1),
		});
		const elseStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("b"),
			right: luau.number(2),
		});
		const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
			condition: luau.bool(true),
			statements: luau.list.make<luau.Statement>(thenStmt),
			elseBody: luau.list.make<luau.Statement>(elseStmt),
		});
		const ast = luau.list.make<luau.Statement>(ifStmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
		sourcePositionMap.set(thenStmt, { line: 1, column: 0 });
		sourcePositionMap.set(elseStmt, { line: 3, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: if true then
		// 2: \tlocal a = 1
		// 3: else
		// 4: \tlocal b = 2
		// 5: end
		const traced = new TraceMap(result.map);
		const thenPos = originalPositionFor(traced, { line: 2, column: 0 });
		expect(thenPos.line).toBe(2);

		const elsePos = originalPositionFor(traced, { line: 4, column: 0 });
		expect(elsePos.line).toBe(4);
	});

	it("includes source text in sourcesContent when sourceContent is provided", () => {
		const stmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(42),
		});
		const ast = luau.list.make<luau.Statement>(stmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(stmt, { line: 0, column: 0 });
		const sourceText = "const x = 42;\n";

		const result = renderASTWithSourceMap(
			ast,
			sourcePositionMap,
			emptyEndMap,
			"input.ts",
			"output.luau",
			sourceText,
		);

		expect(result.map.sourcesContent).toEqual([sourceText]);
	});

	it("has null sourcesContent entry when sourceContent is omitted", () => {
		const stmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(42),
		});
		const ast = luau.list.make<luau.Statement>(stmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(stmt, { line: 0, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		expect(result.map.sourcesContent).toEqual([null]);
	});

	it("maps statements inside callback arguments (CallStatement with FunctionExpression)", () => {
		// Models: describe("test", function() local x = 1 end)
		const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(1),
		});
		const callbackFn = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(innerStmt),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const callExpr = luau.create(luau.SyntaxKind.CallExpression, {
			expression: luau.id("describe"),
			args: luau.list.make<luau.Expression>(luau.string("test"), callbackFn),
		});
		const callStmt = luau.create(luau.SyntaxKind.CallStatement, {
			expression: callExpr,
		});
		const ast = luau.list.make<luau.Statement>(callStmt);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(callStmt, { line: 0, column: 0 });
		sourcePositionMap.set(innerStmt, { line: 1, column: 4 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: describe("test", function()
		// 2: \tlocal x = 1
		// 3: end)
		const traced = new TraceMap(result.map);
		const innerPos = originalPositionFor(traced, { line: 2, column: 0 });
		expect(innerPos.source).toBe("input.ts");
		expect(innerPos.line).toBe(2);
	});

	it("maps deeply nested callback statements (describe > it > expect)", () => {
		// Models: describe("suite", function() it("test", function() local x = 1 end) end)
		const deepStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("x"),
			right: luau.number(1),
		});
		const itCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(deepStmt),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const itCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("it"),
				args: luau.list.make<luau.Expression>(luau.string("test"), itCallback),
			}),
		});
		const describeCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(itCall),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const describeCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("suite"), describeCallback),
			}),
		});
		const ast = luau.list.make<luau.Statement>(describeCall);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(describeCall, { line: 0, column: 0 });
		sourcePositionMap.set(itCall, { line: 1, column: 4 });
		sourcePositionMap.set(deepStmt, { line: 2, column: 8 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: describe("suite", function()
		// 2: \tit("test", function()
		// 3: \t\tlocal x = 1
		// 4: \tend)
		// 5: end)
		const traced = new TraceMap(result.map);
		const itPos = originalPositionFor(traced, { line: 2, column: 0 });
		expect(itPos.source).toBe("input.ts");
		expect(itPos.line).toBe(2);

		const deepPos = originalPositionFor(traced, { line: 3, column: 0 });
		expect(deepPos.source).toBe("input.ts");
		expect(deepPos.line).toBe(3);
	});

	it("maps multiple statements inside a nested callback correctly", () => {
		// Models: describe("suite", function() it("test", function() stmt1; stmt2; stmt3 end) end)
		const stmt1 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("a"),
			right: luau.number(1),
		});
		const stmt2 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("b"),
			right: luau.number(2),
		});
		const stmt3 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("c"),
			right: luau.number(3),
		});
		const itCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(stmt1, stmt2, stmt3),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const itCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("it"),
				args: luau.list.make<luau.Expression>(luau.string("test"), itCallback),
			}),
		});
		const describeCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(itCall),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const describeCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("suite"), describeCallback),
			}),
		});
		const ast = luau.list.make<luau.Statement>(describeCall);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(describeCall, { line: 0, column: 0 });
		sourcePositionMap.set(itCall, { line: 1, column: 4 });
		// Non-consecutive TS lines (blank lines between statements, like real code)
		sourcePositionMap.set(stmt1, { line: 2, column: 8 });
		sourcePositionMap.set(stmt2, { line: 4, column: 8 });
		sourcePositionMap.set(stmt3, { line: 6, column: 8 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: describe("suite", function()
		// 2: \tit("test", function()
		// 3: \t\tlocal a = 1
		// 4: \t\tlocal b = 2
		// 5: \t\tlocal c = 3
		// 6: \tend)
		// 7: end)
		const traced = new TraceMap(result.map);
		const pos1 = originalPositionFor(traced, { line: 3, column: 0 });
		expect(pos1.line).toBe(3); // stmt1: TS line 2 (0-indexed) + 1 = 3

		const pos2 = originalPositionFor(traced, { line: 4, column: 0 });
		expect(pos2.line).toBe(5); // stmt2: TS line 4 (0-indexed) + 1 = 5

		const pos3 = originalPositionFor(traced, { line: 5, column: 0 });
		expect(pos3.line).toBe(7); // stmt3: TS line 6 (0-indexed) + 1 = 7
	});

	it("maps statements when there are multiple it blocks in a describe", () => {
		// describe("suite", function()
		//   it("test1", function() local a = 1 end)
		//   it("test2", function() local b = 2; local c = 3; local d = 4 end)
		// end)
		const stmt1 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("a"),
			right: luau.number(1),
		});
		const it1Callback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(stmt1),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const it1Call = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("it"),
				args: luau.list.make<luau.Expression>(luau.string("test1"), it1Callback),
			}),
		});

		const stmt2 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("b"),
			right: luau.number(2),
		});
		const stmt3 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("c"),
			right: luau.number(3),
		});
		const stmt4 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("d"),
			right: luau.number(4),
		});
		const it2Callback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(stmt2, stmt3, stmt4),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const it2Call = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("it"),
				args: luau.list.make<luau.Expression>(luau.string("test2"), it2Callback),
			}),
		});

		const describeCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(it1Call, it2Call),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const describeCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("suite"), describeCallback),
			}),
		});

		const ast = luau.list.make<luau.Statement>(describeCall);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(describeCall, { line: 0, column: 0 });
		sourcePositionMap.set(it1Call, { line: 1, column: 4 });
		sourcePositionMap.set(stmt1, { line: 2, column: 8 });
		sourcePositionMap.set(it2Call, { line: 5, column: 4 });
		sourcePositionMap.set(stmt2, { line: 6, column: 8 });
		sourcePositionMap.set(stmt3, { line: 8, column: 8 });
		sourcePositionMap.set(stmt4, { line: 10, column: 8 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: describe("suite", function()
		// 2: \tit("test1", function()
		// 3: \t\tlocal a = 1
		// 4: \tend)
		// 5: \tit("test2", function()
		// 6: \t\tlocal b = 2
		// 7: \t\tlocal c = 3
		// 8: \t\tlocal d = 4
		// 9: \tend)
		// 10: end)
		const traced = new TraceMap(result.map);

		// stmt1 in first it
		const pos1 = originalPositionFor(traced, { line: 3, column: 0 });
		expect(pos1.line).toBe(3);

		// stmt2 in second it (first statement)
		const pos2 = originalPositionFor(traced, { line: 6, column: 0 });
		expect(pos2.line).toBe(7);

		// stmt3 in second it (second statement)
		const pos3 = originalPositionFor(traced, { line: 7, column: 0 });
		expect(pos3.line).toBe(9);

		// stmt4 in second it (third statement)
		const pos4 = originalPositionFor(traced, { line: 8, column: 0 });
		expect(pos4.line).toBe(11);
	});

	it("maps statements in 3-level nested callbacks (describe > describe > it)", () => {
		// describe("outer", function()
		//   describe("inner", function()
		//     it("test", function()
		//       local a = 1
		//       local b = 2
		//       local c = 3
		//     end)
		//   end)
		// end)
		const stmt1 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("a"),
			right: luau.number(1),
		});
		const stmt2 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("b"),
			right: luau.number(2),
		});
		const stmt3 = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("c"),
			right: luau.number(3),
		});
		const itCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(stmt1, stmt2, stmt3),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const itCall = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("it"),
				args: luau.list.make<luau.Expression>(luau.string("test"), itCallback),
			}),
		});
		const innerDescribeCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(itCall),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const innerDescribe = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("inner"), innerDescribeCallback),
			}),
		});
		const outerDescribeCallback = luau.create(luau.SyntaxKind.FunctionExpression, {
			statements: luau.list.make<luau.Statement>(innerDescribe),
			parameters: luau.list.make(),
			hasDotDotDot: false,
		});
		const outerDescribe = luau.create(luau.SyntaxKind.CallStatement, {
			expression: luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("outer"), outerDescribeCallback),
			}),
		});

		const ast = luau.list.make<luau.Statement>(outerDescribe);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(outerDescribe, { line: 0, column: 0 });
		sourcePositionMap.set(innerDescribe, { line: 1, column: 4 });
		sourcePositionMap.set(itCall, { line: 2, column: 8 });
		sourcePositionMap.set(stmt1, { line: 3, column: 12 });
		sourcePositionMap.set(stmt2, { line: 5, column: 12 });
		sourcePositionMap.set(stmt3, { line: 7, column: 12 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		// Renders as:
		// 1: describe("outer", function()
		// 2: \tdescribe("inner", function()
		// 3: \t\tit("test", function()
		// 4: \t\t\tlocal a = 1
		// 5: \t\t\tlocal b = 2
		// 6: \t\t\tlocal c = 3
		// 7: \t\tend)
		// 8: \tend)
		// 9: end)
		const traced = new TraceMap(result.map);

		const pos1 = originalPositionFor(traced, { line: 4, column: 0 });
		expect(pos1.line).toBe(4); // stmt1: 0-indexed 3, +1 = 4

		const pos2 = originalPositionFor(traced, { line: 5, column: 0 });
		expect(pos2.line).toBe(6); // stmt2: 0-indexed 5, +1 = 6

		const pos3 = originalPositionFor(traced, { line: 6, column: 0 });
		expect(pos3.line).toBe(8); // stmt3: 0-indexed 7, +1 = 8
	});

	it("stops rendering after a final statement", () => {
		const returnStmt = luau.create(luau.SyntaxKind.ReturnStatement, {
			expression: luau.number(1),
		});
		const unreachable = luau.create(luau.SyntaxKind.VariableDeclaration, {
			left: luau.id("dead"),
			right: luau.number(0),
		});
		const ast = luau.list.make<luau.Statement>(returnStmt, unreachable);
		const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
		sourcePositionMap.set(returnStmt, { line: 0, column: 0 });
		sourcePositionMap.set(unreachable, { line: 1, column: 0 });

		const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

		expect(result.code).toContain("return 1");
		expect(result.code).not.toContain("dead");
	});

	describe("end keyword mappings", () => {
		it("maps function declaration `end` to source", () => {
			const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const funcDecl = luau.create(luau.SyntaxKind.FunctionDeclaration, {
				localize: true,
				name: luau.id("foo"),
				statements: luau.list.make<luau.Statement>(innerStmt),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const ast = luau.list.make<luau.Statement>(funcDecl);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(funcDecl, { line: 0, column: 0 });
			sourcePositionMap.set(innerStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: local function foo()
			// 2: \tlocal x = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1); // maps to function start (0-indexed + 1)
		});

		it("maps IfStatement `end` to source (no else)", () => {
			const thenStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("a"),
				right: luau.number(1),
			});
			const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(thenStmt),
				elseBody: luau.list.make<luau.Statement>(),
			});
			const ast = luau.list.make<luau.Statement>(ifStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
			sourcePositionMap.set(thenStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: if true then
			// 2: \tlocal a = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("maps IfStatement `end` with else body", () => {
			const thenStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("a"),
				right: luau.number(1),
			});
			const elseStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("b"),
				right: luau.number(2),
			});
			const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(thenStmt),
				elseBody: luau.list.make<luau.Statement>(elseStmt),
			});
			const ast = luau.list.make<luau.Statement>(ifStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
			sourcePositionMap.set(thenStmt, { line: 1, column: 4 });
			sourcePositionMap.set(elseStmt, { line: 3, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: if true then
			// 2: \tlocal a = 1
			// 3: else
			// 4: \tlocal b = 2
			// 5: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 5, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("maps IfStatement elseif chain — single `end`, no duplicates", () => {
			const thenStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("a"),
				right: luau.number(1),
			});
			const elseifStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("b"),
				right: luau.number(2),
			});
			const elseifNode = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.bool(false),
				statements: luau.list.make<luau.Statement>(elseifStmt),
				elseBody: luau.list.make<luau.Statement>(),
			});
			const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(thenStmt),
				elseBody: elseifNode,
			});
			const ast = luau.list.make<luau.Statement>(ifStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
			sourcePositionMap.set(thenStmt, { line: 1, column: 4 });
			sourcePositionMap.set(elseifNode, { line: 2, column: 0 });
			sourcePositionMap.set(elseifStmt, { line: 3, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: if true then
			// 2: \tlocal a = 1
			// 3: elseif false then
			// 4: \tlocal b = 2
			// 5: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 5, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1); // maps to outermost if
		});

		it("maps WhileStatement `end` to source", () => {
			const bodyStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const whileStmt = luau.create(luau.SyntaxKind.WhileStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(bodyStmt),
			});
			const ast = luau.list.make<luau.Statement>(whileStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(whileStmt, { line: 0, column: 0 });
			sourcePositionMap.set(bodyStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: while true do
			// 2: \tlocal x = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("maps ForStatement `end` to source", () => {
			const bodyStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const forStmt = luau.create(luau.SyntaxKind.ForStatement, {
				ids: luau.list.make(luau.id("k"), luau.id("v")),
				expression: luau.call(luau.id("pairs"), [luau.id("t")]),
				statements: luau.list.make<luau.Statement>(bodyStmt),
			});
			const ast = luau.list.make<luau.Statement>(forStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(forStmt, { line: 0, column: 0 });
			sourcePositionMap.set(bodyStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: for k, v in pairs(t) do
			// 2: \tlocal x = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("maps NumericForStatement `end` to source", () => {
			const bodyStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const numForStmt = luau.create(luau.SyntaxKind.NumericForStatement, {
				id: luau.id("i"),
				start: luau.number(1),
				end: luau.number(10),
				step: undefined,
				statements: luau.list.make<luau.Statement>(bodyStmt),
			});
			const ast = luau.list.make<luau.Statement>(numForStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(numForStmt, { line: 0, column: 0 });
			sourcePositionMap.set(bodyStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: for i = 1, 10 do
			// 2: \tlocal x = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("maps DoStatement `end` to source", () => {
			const bodyStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const doStmt = luau.create(luau.SyntaxKind.DoStatement, {
				statements: luau.list.make<luau.Statement>(bodyStmt),
			});
			const ast = luau.list.make<luau.Statement>(doStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(doStmt, { line: 0, column: 0 });
			sourcePositionMap.set(bodyStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: do
			// 2: \tlocal x = 1
			// 3: end
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1);
		});

		it("does NOT map RepeatStatement `until` line", () => {
			const bodyStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const repeatStmt = luau.create(luau.SyntaxKind.RepeatStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(bodyStmt),
			});
			const ast = luau.list.make<luau.Statement>(repeatStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(repeatStmt, { line: 0, column: 0 });
			sourcePositionMap.set(bodyStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: repeat
			// 2: \tlocal x = 1
			// 3: until true
			// The `until` line (3) should NOT get an end mapping
			const traced = new TraceMap(result.map);
			const untilPos = originalPositionFor(traced, { line: 3, column: 0 });
			// Line 3 should not map to source (no mapping for `until`)
			expect(untilPos.source).toBeNull();
		});

		it("maps FunctionExpression callback `end)` to source", () => {
			const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const callbackFn = luau.create(luau.SyntaxKind.FunctionExpression, {
				statements: luau.list.make<luau.Statement>(innerStmt),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const callExpr = luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("test"), callbackFn),
			});
			const callStmt = luau.create(luau.SyntaxKind.CallStatement, {
				expression: callExpr,
			});
			const ast = luau.list.make<luau.Statement>(callStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(callStmt, { line: 0, column: 0 });
			sourcePositionMap.set(innerStmt, { line: 1, column: 4 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Renders as:
			// 1: describe("test", function()
			// 2: \tlocal x = 1
			// 3: end)
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1); // maps to call statement start
		});

		it("does NOT map empty FunctionExpression (single-line)", () => {
			const callbackFn = luau.create(luau.SyntaxKind.FunctionExpression, {
				statements: luau.list.make<luau.Statement>(),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const callExpr = luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("noop"),
				args: luau.list.make<luau.Expression>(callbackFn),
			});
			const callStmt = luau.create(luau.SyntaxKind.CallStatement, {
				expression: callExpr,
			});
			const ast = luau.list.make<luau.Statement>(callStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(callStmt, { line: 0, column: 0 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			// Single-line: noop(function() end)
			// Only 1 output line, so no spurious end mapping beyond the statement itself
			const lines = result.code.split("\n").filter(l => l.length > 0);
			expect(lines.length).toBe(1);
		});

		it("prefers sourceEndPositionMap for function `end` mapping", () => {
			const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const funcDecl = luau.create(luau.SyntaxKind.FunctionDeclaration, {
				localize: true,
				name: luau.id("foo"),
				statements: luau.list.make<luau.Statement>(innerStmt),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const ast = luau.list.make<luau.Statement>(funcDecl);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(funcDecl, { line: 0, column: 0 });
			sourcePositionMap.set(innerStmt, { line: 1, column: 4 });
			const sourceEndPositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourceEndPositionMap.set(funcDecl, { line: 2, column: 0 }); // closing `}`

			const result = renderASTWithSourceMap(
				ast,
				sourcePositionMap,
				sourceEndPositionMap,
				"input.ts",
				"output.luau",
			);

			// `end` (line 3) should map to line 2+1=3 (the `}` line)
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(3); // 0-indexed 2 + 1
			expect(endPos.column).toBe(0);
		});

		it("prefers sourceEndPositionMap for IfStatement `end` mapping", () => {
			const thenStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("a"),
				right: luau.number(1),
			});
			const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.bool(true),
				statements: luau.list.make<luau.Statement>(thenStmt),
				elseBody: luau.list.make<luau.Statement>(),
			});
			const ast = luau.list.make<luau.Statement>(ifStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(ifStmt, { line: 0, column: 0 });
			sourcePositionMap.set(thenStmt, { line: 1, column: 4 });
			const sourceEndPositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourceEndPositionMap.set(ifStmt, { line: 2, column: 0 }); // closing `}`

			const result = renderASTWithSourceMap(
				ast,
				sourcePositionMap,
				sourceEndPositionMap,
				"input.ts",
				"output.luau",
			);

			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(3);
		});

		it("prefers sourceEndPositionMap for callback `end)` mapping", () => {
			const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const callbackFn = luau.create(luau.SyntaxKind.FunctionExpression, {
				statements: luau.list.make<luau.Statement>(innerStmt),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const callExpr = luau.create(luau.SyntaxKind.CallExpression, {
				expression: luau.id("describe"),
				args: luau.list.make<luau.Expression>(luau.string("test"), callbackFn),
			});
			const callStmt = luau.create(luau.SyntaxKind.CallStatement, {
				expression: callExpr,
			});
			const ast = luau.list.make<luau.Statement>(callStmt);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(callStmt, { line: 0, column: 0 });
			sourcePositionMap.set(innerStmt, { line: 1, column: 4 });
			const sourceEndPositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourceEndPositionMap.set(callStmt, { line: 2, column: 1 }); // closing `}`

			const result = renderASTWithSourceMap(
				ast,
				sourcePositionMap,
				sourceEndPositionMap,
				"input.ts",
				"output.luau",
			);

			// `end)` (line 3) should map to the closing `}` position
			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(3); // 0-indexed 2 + 1
			expect(endPos.column).toBe(1);
		});

		it("maps nested IfStatement `end` inside function body", () => {
			// Simulates optional chaining: GetPlayers()[0]?.Name compiles to
			// local _result = GetPlayers()[1]
			// if _result ~= nil then
			//     _result = _result.Name
			// end
			// These are prerequisite statements for the parent expression,
			// so only the top-level list nodes get source positions (matching
			// how transformStatementList sets positions on prereqs).
			const localDecl = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("_result"),
				right: luau.id("x"),
			});
			const thenStmt = luau.create(luau.SyntaxKind.Assignment, {
				left: luau.id("_result"),
				operator: "=",
				right: luau.property(luau.id("_result"), "Name"),
			});
			const ifStmt = luau.create(luau.SyntaxKind.IfStatement, {
				condition: luau.binary(luau.id("_result"), "~=", luau.nil()),
				statements: luau.list.make<luau.Statement>(thenStmt),
				elseBody: luau.list.make<luau.Statement>(),
			});
			const printStmt = luau.create(luau.SyntaxKind.CallStatement, {
				expression: luau.call(luau.id("print"), [luau.id("_result")]),
			});
			const funcDecl = luau.create(luau.SyntaxKind.FunctionDeclaration, {
				localize: true,
				name: luau.id("subtract"),
				statements: luau.list.make<luau.Statement>(localDecl, ifStmt, printStmt),
				parameters: luau.list.make(luau.id("a"), luau.id("b")),
				hasDotDotDot: false,
			});
			const ast = luau.list.make<luau.Statement>(funcDecl);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			// Only set positions on list-level nodes (like transformStatementList does)
			sourcePositionMap.set(funcDecl, { line: 4, column: 0 });
			sourcePositionMap.set(localDecl, { line: 5, column: 1 });
			sourcePositionMap.set(ifStmt, { line: 5, column: 1 });
			// thenStmt is NOT in sourcePositionMap — it's an inner node of
			// the IfStatement, not a top-level prereq
			sourcePositionMap.set(printStmt, { line: 5, column: 1 });

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			const traced = new TraceMap(result.map);
			// Line 5 is the `end` of the inner if — it should have a mapping
			const ifEndPos = originalPositionFor(traced, { line: 5, column: 0 });
			expect(ifEndPos.source).toBe("input.ts");
			expect(ifEndPos.line).toBe(6); // 0-indexed line 5 + 1
		});

		it("falls back to sourcePositionMap when sourceEndPositionMap has no entry", () => {
			const innerStmt = luau.create(luau.SyntaxKind.VariableDeclaration, {
				left: luau.id("x"),
				right: luau.number(1),
			});
			const funcDecl = luau.create(luau.SyntaxKind.FunctionDeclaration, {
				localize: true,
				name: luau.id("foo"),
				statements: luau.list.make<luau.Statement>(innerStmt),
				parameters: luau.list.make(),
				hasDotDotDot: false,
			});
			const ast = luau.list.make<luau.Statement>(funcDecl);
			const sourcePositionMap = new WeakMap<luau.Node, SourcePosition>();
			sourcePositionMap.set(funcDecl, { line: 0, column: 0 });
			sourcePositionMap.set(innerStmt, { line: 1, column: 4 });
			// No end position — should fall back to start position

			const result = renderASTWithSourceMap(ast, sourcePositionMap, emptyEndMap, "input.ts", "output.luau");

			const traced = new TraceMap(result.map);
			const endPos = originalPositionFor(traced, { line: 3, column: 0 });
			expect(endPos.source).toBe("input.ts");
			expect(endPos.line).toBe(1); // falls back to start position
		});
	});
});
