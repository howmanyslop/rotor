import { RojoResolver } from "@isentinel/rojo-utils";
import fs from "fs-extra";
import path from "path";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { realPathExistsSync } from "../../Shared/util/realPathExistsSync.ts";
import { type PackageJsonWithExports, resolvePackageExports } from "./resolvePackageExports.ts";

/**
 * When a package has a `*.project.json` with a `$path`, the Rojo-served
 * directory may differ from the exports field's runtime directory (e.g. `out/`
 * vs `dist/`). Remap runtime paths so the Rojo resolver can find them.
 */
function remapToRojoTree(pkgPath: string, runtimePath: string): string {
	const { path: projectJsonPath } = RojoResolver.findRojoConfigFilePath(pkgPath);
	if (projectJsonPath === undefined) return runtimePath;

	const rojoTreePath = (fs.readJsonSync(projectJsonPath) as { tree?: { $path?: unknown } })?.tree?.["$path"];
	if (typeof rojoTreePath !== "string") return runtimePath;

	const rojoDir = path.resolve(pkgPath, rojoTreePath);
	const normalizedRuntime = path.normalize(runtimePath);

	// Already inside the Rojo-served directory — no remap needed
	if (normalizedRuntime.startsWith(rojoDir + path.sep) || normalizedRuntime === rojoDir) return runtimePath;

	// Replace the first directory segment with $path, preserving nested structure.
	// e.g. dist/utils/init.luau → out/utils/init.luau
	const relRuntime = path.relative(pkgPath, runtimePath);
	const segments = relRuntime.split(path.sep);
	segments[0] = rojoTreePath;
	return path.join(pkgPath, ...segments);
}

export function createNodeModulesPathMapping(typeRoots: Array<string>, customConditions?: ReadonlyArray<string>) {
	const nodeModulesPathMapping = new Map<string, string>();
	// go through each org
	for (const scopePath of typeRoots) {
		if (fs.pathExistsSync(scopePath)) {
			// map module paths
			for (const pkgName of fs.readdirSync(scopePath)) {
				const pkgPath = path.join(scopePath, pkgName);
				const pkgJsonPath = realPathExistsSync(path.join(pkgPath, "package.json"));
				if (pkgJsonPath !== undefined) {
					const pkgJson = fs.readJsonSync(pkgJsonPath) as PackageJsonWithExports;

					const exportsMappings =
						pkgJson.exports !== undefined
							? resolvePackageExports(pkgPath, pkgJson, customConditions)
							: undefined;

					if (exportsMappings !== undefined && exportsMappings.size > 0) {
						for (const [typesPath, runtimePath] of exportsMappings) {
							nodeModulesPathMapping.set(typesPath, remapToRojoTree(pkgPath, runtimePath));
						}
						// Node10 moduleResolution ignores `exports` and resolves via
						// top-level `types`/`typings`. Add a fallback mapping so the
						// lookup in createImportExpression succeeds either way.
						const legacyTypes = pkgJson.types ?? pkgJson.typings;
						if (legacyTypes !== undefined && pkgJson.main !== undefined) {
							const canonicalLegacy = getCanonicalFileName(path.resolve(pkgPath, legacyTypes));
							if (!nodeModulesPathMapping.has(canonicalLegacy)) {
								nodeModulesPathMapping.set(
									canonicalLegacy,
									remapToRojoTree(pkgPath, path.resolve(pkgPath, pkgJson.main)),
								);
							}
						}
					} else {
						// Fallback: main/types/typings (original behavior, also when exports yields nothing)
						const typesPath = pkgJson.types ?? pkgJson.typings ?? "index.d.ts";
						if (pkgJson.main) {
							nodeModulesPathMapping.set(
								getCanonicalFileName(path.resolve(pkgPath, typesPath)),
								remapToRojoTree(pkgPath, path.resolve(pkgPath, pkgJson.main)),
							);
						}
					}

					// For symlinked packages, add real-path keys pointing to
					// the same virtual-path runtime values. TS resolves to real
					// paths, so lookups need to match. Runtime values stay as
					// virtual (node_modules) paths for Rojo resolution.
					const realPkgPath = path.dirname(pkgJsonPath);
					if (getCanonicalFileName(realPkgPath) !== getCanonicalFileName(pkgPath)) {
						const realMappings = resolvePackageExports(realPkgPath, pkgJson, customConditions);
						const virtualMappings =
							exportsMappings ?? resolvePackageExports(pkgPath, pkgJson, customConditions);
						const virtualValues = [...virtualMappings.values()];
						let i = 0;
						for (const [realKey] of realMappings) {
							if (!nodeModulesPathMapping.has(realKey) && i < virtualValues.length) {
								nodeModulesPathMapping.set(realKey, virtualValues[i]);
							}
							i++;
						}
					}
				}
			}
		}
	}
	return nodeModulesPathMapping;
}
