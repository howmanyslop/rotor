import type { RojoResolver } from "@isentinel/rojo-utils";
import ts from "typescript";
import { describe, expect, it, vi } from "vitest";

import type { WatchHostSubset } from "./rojoWatchSet.ts";
import { registerRojoWatchers } from "./rojoWatchSet.ts";

type FileCallback = ts.FileWatcherCallback;
type DirCallback = ts.DirectoryWatcherCallback;

interface FakeFileWatcher {
	path: string;
	callback: FileCallback;
	closed: boolean;
}

interface FakeDirWatcher {
	path: string;
	callback: DirCallback;
	closed: boolean;
	recursive: boolean | undefined;
}

function createMockResolver(walkedConfigFiles: ReadonlyArray<string>, walkedDirectories: ReadonlyArray<string>) {
	return {
		walkedConfigFiles: new Set(walkedConfigFiles),
		walkedDirectories: new Set(walkedDirectories),
	} as unknown as RojoResolver;
}

function createFakeHost() {
	const files = new Array<FakeFileWatcher>();
	const dirs = new Array<FakeDirWatcher>();
	const host: WatchHostSubset = {
		watchFile: (path, callback) => {
			const entry: FakeFileWatcher = { path, callback, closed: false };
			files.push(entry);
			return { close: () => (entry.closed = true) };
		},
		watchDirectory: (path, callback, recursive) => {
			const entry: FakeDirWatcher = { path, callback, closed: false, recursive };
			dirs.push(entry);
			return { close: () => (entry.closed = true) };
		},
	};
	return { host, files, dirs };
}

describe("registerRojoWatchers", () => {
	it("registers one file watcher per walkedConfigFile", () => {
		const { host, files } = createFakeHost();
		const resolver = createMockResolver(["/repo/a/default.project.json", "/repo/a/sub/sub.project.json"], []);

		registerRojoWatchers({ host, resolver, onInvalidate: vi.fn() });

		expect(files.length).toBe(2);
		expect(files[0]!.path).toBe("/repo/a/default.project.json");
		expect(files[1]!.path).toBe("/repo/a/sub/sub.project.json");
	});

	it("registers one directory watcher per walkedDirectory", () => {
		const { host, dirs } = createFakeHost();
		const resolver = createMockResolver([], ["/repo/a", "/repo/a/sub"]);

		registerRojoWatchers({ host, resolver, onInvalidate: vi.fn() });

		expect(dirs.length).toBe(2);
	});

	it("fires onInvalidate when a watched config file changes", () => {
		const { host, files } = createFakeHost();
		const resolver = createMockResolver(["/repo/a/default.project.json"], []);
		const onInvalidate = vi.fn();

		registerRojoWatchers({ host, resolver, onInvalidate });
		files[0]!.callback("/repo/a/default.project.json", ts.FileWatcherEventKind.Changed);

		expect(onInvalidate).toHaveBeenCalledOnce();
	});

	it("fires onInvalidate when a new .project.json appears in a watched directory", () => {
		const { host, dirs } = createFakeHost();
		const resolver = createMockResolver([], ["/repo/a"]);
		const onInvalidate = vi.fn();

		registerRojoWatchers({ host, resolver, onInvalidate });
		dirs[0]!.callback("/repo/a/nested.project.json");

		expect(onInvalidate).toHaveBeenCalledOnce();
	});

	it("registers recursive directory watchers so new nested subdirs are covered", () => {
		const { host, dirs } = createFakeHost();
		const resolver = createMockResolver([], ["/repo/a"]);

		registerRojoWatchers({ host, resolver, onInvalidate: vi.fn() });

		expect(dirs[0]!.recursive).toBe(true);
	});

	it("fires onInvalidate when a .project.json appears deeper than a direct child", () => {
		const { host, dirs } = createFakeHost();
		const resolver = createMockResolver([], ["/repo/a"]);
		const onInvalidate = vi.fn();

		registerRojoWatchers({ host, resolver, onInvalidate });
		// recursive=true: events under a newly-created subdir reach the
		// parent watcher. Pre-fix used recursive=false so the same event
		// was invisible.
		dirs[0]!.callback("/repo/a/brand-new-subdir/default.project.json");

		expect(onInvalidate).toHaveBeenCalledOnce();
	});

	it("ignores non-rojo file events inside a watched directory", () => {
		const { host, dirs } = createFakeHost();
		const resolver = createMockResolver([], ["/repo/a"]);
		const onInvalidate = vi.fn();

		registerRojoWatchers({ host, resolver, onInvalidate });
		dirs[0]!.callback("/repo/a/some-source.ts");
		dirs[0]!.callback("/repo/a/random.json");

		expect(onInvalidate).not.toHaveBeenCalled();
	});

	it("dispose() closes all watchers", () => {
		const { host, files, dirs } = createFakeHost();
		const resolver = createMockResolver(["/repo/a/default.project.json"], ["/repo/a"]);

		const dispose = registerRojoWatchers({ host, resolver, onInvalidate: vi.fn() });
		dispose();

		expect(files[0]!.closed).toBe(true);
		expect(dirs[0]!.closed).toBe(true);
	});
});
