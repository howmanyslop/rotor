import nodeFs from "fs";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { runRbxtsEmit } from "../util/runRbxtsEmit.ts";
import { snapshotBuildState } from "../util/snapshotBuildState.ts";
import { compileFiles } from "./compileFiles.ts";
import { createPathTranslator } from "./createPathTranslator.ts";
import { createProjectData } from "./createProjectData.ts";
import { createProjectProgram } from "./createProjectProgram.ts";
import { getChangedSourceFiles } from "./getChangedSourceFiles.ts";

// Mirrors the CLI's single-project (non-`--build`) path:
//   places/main $ rbxtsc -p tsconfig.lib.json
// This is what build.ts's handler does for non-`--build` invocations. The
// `--build` path goes through buildSolution (see buildSolution.test.ts) and
// already has an idempotency test; this file covers the single-project
// emit -> tsbuildinfo -> readBuilderProgram round-trip.
const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/single-incremental");
const TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.json");
const RBXTS_TYPEROOT_SRC = path.resolve(__dirname, "../../..", "tests/node_modules/@rbxts/compiler-types");
const RBXTS_TYPEROOT_DEST = path.join(FIXTURE_DIR, "node_modules/@rbxts/compiler-types");
const OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

function ensureCompilerTypes() {
	// validateCompilerOptions requires `<projectPath>/node_modules/@rbxts` to
	// match a typeRoot, AND `types: ["compiler-types"]` to actually resolve
	// (it's a real fs.existsSync). The shared test root has the @rbxts
	// typeRoot stubs but we can't symlink them into the fixture (git-bash
	// emits a non-Windows symlink that Node fs can stat() the link itself
	// but not paths *under* it). Dereferenced copy is small enough (~80KB)
	// to be cheap, and we keep it out of git via .gitignore.
	if (nodeFs.existsSync(RBXTS_TYPEROOT_DEST)) return;
	nodeFs.mkdirSync(path.dirname(RBXTS_TYPEROOT_DEST), { recursive: true });
	fs.copySync(RBXTS_TYPEROOT_SRC, RBXTS_TYPEROOT_DEST, { dereference: true });
}

function cleanFixtureOutput() {
	// tsBuildInfoFile lives under out/ (see tests/single-incremental/tsconfig.json),
	// so the out/ removal also drops tsconfig.tsbuildinfo.
	fs.removeSync(path.join(FIXTURE_DIR, "out"));
	fs.removeSync(path.join(FIXTURE_DIR, "include"));
}

async function runSingleProjectBuild() {
	// Mirrors `tools/roblox-ts/src/CLI/commands/build.ts` exactly — same
	// snapshot → changedSourceFiles → runRbxtsEmit flow. Reconstructing only
	// the createProjectProgram + compileFiles pair (as an earlier draft did)
	// would bypass the very wrapper this regression exists to verify.
	const data = createProjectData(TSCONFIG, { ...OPTIONS });
	const program = createProjectProgram(data);
	const pathTranslator = createPathTranslator(program, data);
	const snapshot = snapshotBuildState(program);
	const rootDirs = getRootDirs(program.getCompilerOptions());
	const changed = getChangedSourceFiles(program, rootDirs, [...snapshot.changedFilePaths]);
	const { compileResult } = await runRbxtsEmit({
		program,
		compileThunk: innerProgram => compileFiles(innerProgram, data, pathTranslator, changed),
	});
	return { result: compileResult, compiledCount: changed.length };
}

describe("single-project incremental no-op", () => {
	beforeAll(ensureCompilerTypes);

	afterEach(() => {
		cleanFixtureOutput();
		vi.restoreAllMocks();
	});

	it("compiles every source file on the cold build", async () => {
		const { compiledCount } = await runSingleProjectBuild();
		// The fixture has 2 .ts sources (index.ts, helper.ts).
		expect(compiledCount).toBe(2);
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/init.luau"))).toBe(true);
	});

	it("does not pass any files to compileFiles on a no-op rerun", async () => {
		const first = await runSingleProjectBuild();
		expect(first.compiledCount).toBe(2);

		// `compiledCount` mirrors what the verbose CLI prints as
		// `N/N compile <file>`. A correct no-op rerun has zero.
		const second = await runSingleProjectBuild();
		expect(second.compiledCount).toBe(0);
	});

	it("does not rewrite any .luau on a no-op rerun", async () => {
		await runSingleProjectBuild();

		// The async-write path uses `fs.promises.writeFile` for queues >=
		// `syncCutoff` (16) and `fs.writeFileSync` below that. The shared
		// fixture has 2 sources, so the sync path is the one actually used,
		// but spy both for robustness against a future cutoff change.
		const asyncSpy = vi.spyOn(fs.promises, "writeFile");
		const syncSpy = vi.spyOn(nodeFs, "writeFileSync");

		await runSingleProjectBuild();

		const isLuau = (p: unknown) => typeof p === "string" && p.endsWith(".luau");
		const luauWrites = [
			...asyncSpy.mock.calls.filter(([p]) => isLuau(p)),
			...syncSpy.mock.calls.filter(([p]) => isLuau(p)),
		];
		expect(luauWrites).toEqual([]);
	});

	it("persists an empty changeFileSet for root sources in tsbuildinfo", async () => {
		// Direct test of the underlying TS incremental contract: after a
		// successful emit, the saved tsbuildinfo must not still mark every
		// root source as pending — that's what would force the next build to
		// recompile from scratch.
		await runSingleProjectBuild();

		// rbxtsc suffixes every tsbuildinfo with `.rbxtsc` so it can't collide
		// with tsgo's incremental cache when both tools share an outDir.
		const tsBuildInfoPath = path.join(FIXTURE_DIR, "out/tsconfig.rbxtsc.tsbuildinfo");
		expect(fs.existsSync(tsBuildInfoPath)).toBe(true);
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/tsconfig.tsbuildinfo"))).toBe(false);

		const buildInfo = JSON.parse(fs.readFileSync(tsBuildInfoPath, "utf-8")) as {
			fileNames?: ReadonlyArray<string>;
			changeFileSet?: ReadonlyArray<number>;
		};

		// Root-source indices are 1-based in `changeFileSet`.
		const rootFileIndices = new Set<number>();
		(buildInfo.fileNames ?? []).forEach((name, index) => {
			const normalized = name.replace(/\\/g, "/");
			if (normalized.includes("/src/") && normalized.endsWith(".ts") && !normalized.endsWith(".d.ts")) {
				rootFileIndices.add(index + 1);
			}
		});

		const pending = new Set(buildInfo.changeFileSet ?? []);
		const stillPendingRoots = [...rootFileIndices].filter(index => pending.has(index));
		expect(stillPendingRoots).toEqual([]);
	});

	it("rolls tsbuildinfo back to absent when the Luau emit fails on a cold build", async () => {
		// runRbxtsEmit advances the BuilderProgram BEFORE compileFiles, so a
		// failed Luau emit must drop the newly-emitted tsbuildinfo — otherwise
		// the next run would see "up to date" and skip the .luau pass over
		// partial output. The pre-emit `.d.ts` writes are accepted as a
		// trade-off: declarations need to land for cross-project resolution
		// before the Luau pass even runs, and they're idempotent on retry.
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/tsconfig.rbxtsc.tsbuildinfo"))).toBe(false);

		// Force the Luau write to fail mid-emit (covers both sync + async
		// writeEmittedFiles paths).
		vi.spyOn(fs.promises, "writeFile").mockImplementation((async (p: string) => {
			if (typeof p === "string" && p.endsWith(".luau")) {
				throw new Error("synthetic luau write failure");
			}
			return undefined;
		}) as never);
		vi.spyOn(nodeFs, "writeFileSync").mockImplementation(((p: string) => {
			if (typeof p === "string" && p.endsWith(".luau")) {
				throw new Error("synthetic luau write failure");
			}
			return undefined;
		}) as never);

		await expect(runSingleProjectBuild()).rejects.toThrow(/synthetic luau write failure/);

		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/tsconfig.rbxtsc.tsbuildinfo"))).toBe(false);
	});

	it("keeps the prior tsbuildinfo on disk while an incremental Luau emit runs", async () => {
		// Ctrl-C resilience through the real compileFiles + Flamework path (the
		// unit test mocks those seams). Buffer-and-write must leave the prior
		// tsbuildinfo untouched on disk for the entire compile window, so an
		// interrupt mid-emit leaves an incremental-ready buildinfo instead of
		// forcing a cold rebuild.
		const tsBuildInfoPath = path.join(FIXTURE_DIR, "out/tsconfig.rbxtsc.tsbuildinfo");

		// Cold build settles the prior tsbuildinfo (+ flamework.build) on disk.
		await runSingleProjectBuild();
		const priorBuildInfo = fs.readFileSync(tsBuildInfoPath, "utf-8");

		// Invalidate a source so the rerun actually emits Luau, exercising the
		// compile window where a Ctrl-C would land.
		const sourcePath = path.join(FIXTURE_DIR, "src/helper.ts");
		const originalSource = nodeFs.readFileSync(sourcePath, "utf-8");

		let buildInfoDuringCompile: string | undefined;
		const captureMidCompile = (target: unknown) => {
			// Reading the prior buildinfo here is the assertion: under the old
			// delete-then-restore flow it would be absent (ENOENT) at this point.
			if (typeof target === "string" && target.endsWith(".luau") && buildInfoDuringCompile === undefined) {
				buildInfoDuringCompile = fs.readFileSync(tsBuildInfoPath, "utf-8");
			}
		};

		try {
			nodeFs.writeFileSync(sourcePath, `${originalSource}export const touched = true;\n`);

			// The fixture's 2 sources take the sync write path, but spy both for
			// robustness against a future cutoff change.
			const realWriteFileSync = nodeFs.writeFileSync.bind(nodeFs);
			vi.spyOn(nodeFs, "writeFileSync").mockImplementation(((target: string, ...rest: Array<unknown>) => {
				captureMidCompile(target);
				return (realWriteFileSync as (...args: Array<unknown>) => unknown)(target, ...rest);
			}) as never);
			const realWriteFile = fs.promises.writeFile.bind(fs.promises);
			vi.spyOn(fs.promises, "writeFile").mockImplementation((async (target: string, ...rest: Array<unknown>) => {
				captureMidCompile(target);
				return (realWriteFile as (...args: Array<unknown>) => Promise<unknown>)(target, ...rest);
			}) as never);

			const { compiledCount } = await runSingleProjectBuild();
			expect(compiledCount).toBeGreaterThan(0);
		} finally {
			nodeFs.writeFileSync(sourcePath, originalSource);
		}

		// Mid-compile the prior tsbuildinfo was intact (never deleted)...
		expect(buildInfoDuringCompile).toBe(priorBuildInfo);
		// ...and the fresh buildinfo is flushed once the emit succeeds.
		expect(fs.readFileSync(tsBuildInfoPath, "utf-8")).not.toBe(priorBuildInfo);
	});
});
