import path from "path";
import { describe, expect, it, vi } from "vitest";

import { getChangedSourceFiles } from "./getChangedSourceFiles.ts";

vi.mock("./getChangedFilePaths.ts", () => ({
	getChangedFilePaths: vi.fn(),
}));

import { getChangedFilePaths } from "./getChangedFilePaths.ts";

function createSourceFile(fileName: string, isDeclarationFile = false) {
	return { fileName, isDeclarationFile };
}

function createProgram(sourceFilesByName: Map<string, ReturnType<typeof createSourceFile>>) {
	return {
		getSourceFile: (name: string) => sourceFilesByName.get(name),
	} as never;
}

describe("getChangedSourceFiles", () => {
	const rootDir = path.normalize("/project/src");

	it("returns source files within rootDirs", () => {
		const insideFile = createSourceFile(path.join(rootDir, "index.ts"));
		const files = new Map([[insideFile.fileName, insideFile]]);
		vi.mocked(getChangedFilePaths).mockReturnValue(new Set(files.keys()));

		const result = getChangedSourceFiles(createProgram(files), [rootDir]);

		expect(result).toHaveLength(1);
		expect(result[0]).toBe(insideFile);
	});

	it("filters out source files outside rootDirs", () => {
		const insideFile = createSourceFile(path.join(rootDir, "index.ts"));
		const outsideFile = createSourceFile(path.normalize("/packages/core/src/index.ts"));
		const files = new Map([
			[insideFile.fileName, insideFile],
			[outsideFile.fileName, outsideFile],
		]);
		vi.mocked(getChangedFilePaths).mockReturnValue(new Set(files.keys()));

		const result = getChangedSourceFiles(createProgram(files), [rootDir]);

		expect(result).toHaveLength(1);
		expect(result[0]).toBe(insideFile);
	});

	it("filters out declaration files", () => {
		const declFile = createSourceFile(path.join(rootDir, "types.d.ts"), true);
		const files = new Map([[declFile.fileName, declFile]]);
		vi.mocked(getChangedFilePaths).mockReturnValue(new Set(files.keys()));

		const result = getChangedSourceFiles(createProgram(files), [rootDir]);

		expect(result).toHaveLength(0);
	});

	it("does not match directories that share a prefix with rootDir", () => {
		const insideFile = createSourceFile(path.join(rootDir, "index.ts"));
		const prefixFile = createSourceFile(path.join(path.normalize("/project/srcExtra"), "index.ts"));
		const files = new Map([
			[insideFile.fileName, insideFile],
			[prefixFile.fileName, prefixFile],
		]);
		vi.mocked(getChangedFilePaths).mockReturnValue(new Set(files.keys()));

		const result = getChangedSourceFiles(createProgram(files), [rootDir]);

		expect(result).toHaveLength(1);
		expect(result[0]).toBe(insideFile);
	});

	it("supports multiple rootDirs", () => {
		const secondRootDir = path.normalize("/project/shared");
		const file1 = createSourceFile(path.join(rootDir, "a.ts"));
		const file2 = createSourceFile(path.join(secondRootDir, "b.ts"));
		const outside = createSourceFile(path.normalize("/deps/src/c.ts"));
		const files = new Map([
			[file1.fileName, file1],
			[file2.fileName, file2],
			[outside.fileName, outside],
		]);
		vi.mocked(getChangedFilePaths).mockReturnValue(new Set(files.keys()));

		const result = getChangedSourceFiles(createProgram(files), [rootDir, secondRootDir]);

		expect(result).toHaveLength(2);
		expect(result).toContain(file1);
		expect(result).toContain(file2);
	});
});
