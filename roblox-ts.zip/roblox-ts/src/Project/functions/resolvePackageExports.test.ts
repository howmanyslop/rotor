import path from "path";
import { describe, expect, it } from "vitest";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { resolvePackageExports } from "./resolvePackageExports.ts";

const PKG = path.resolve("/fake/node_modules/@rbxts/test-pkg");

/** Build the canonical types key the same way production code does */
function typesKey(...segments: Array<string>): string {
	return getCanonicalFileName(path.resolve(PKG, ...segments));
}

/** Build the resolved runtime path */
function runtimePath(...segments: Array<string>): string {
	return path.resolve(PKG, ...segments);
}

describe("resolvePackageExports", () => {
	describe("when package has no exports field", () => {
		it("returns empty map", () => {
			const result = resolvePackageExports(PKG, { main: "out/init.lua" });
			expect(result.size).toBe(0);
		});
	});

	describe("when exports is a string", () => {
		it("maps adjacent .d.ts to runtime path", () => {
			const result = resolvePackageExports(PKG, {
				exports: "./out/init.lua",
			});

			expect(result.size).toBe(1);
			expect(result.get(typesKey("out", "init.d.ts"))).toBe(runtimePath("out", "init.lua"));
		});

		it("falls back to top-level types for '.' subpath", () => {
			const result = resolvePackageExports(PKG, {
				types: "typings/index.d.ts",
				exports: "./out/init.lua",
			});

			expect(result.size).toBe(1);
			expect(result.get(typesKey("typings", "index.d.ts"))).toBe(runtimePath("out", "init.lua"));
		});
	});

	describe("when exports is a subpath map with conditions", () => {
		it("resolves types and require conditions for '.'", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						require: "./dist/init.lua",
					},
				},
			});

			expect(result.size).toBe(1);
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});

		it("resolves multiple subpaths", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						require: "./dist/init.lua",
					},
					"./utils": {
						types: "./dist/utils.d.ts",
						require: "./dist/utils.lua",
					},
				},
			});

			expect(result.size).toBe(2);
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
			expect(result.get(typesKey("dist", "utils.d.ts"))).toBe(runtimePath("dist", "utils.lua"));
		});
		it("resolves nested conditions", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						require: {
							types: "./dist/index.d.ts",
							default: "./dist/init.lua",
						},
					},
				},
			});

			expect(result.size).toBe(1);
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});
	});

	describe("when export is null", () => {
		it("produces no mapping for that subpath", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						require: "./dist/init.lua",
					},
					"./internal": null,
				},
			});

			expect(result.size).toBe(1);
			expect(result.has(typesKey("dist", "index.d.ts"))).toBe(true);
		});
	});

	describe("when '.' is missing from exports map", () => {
		it("produces no root mapping", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					"./utils": {
						types: "./dist/utils.d.ts",
						require: "./dist/utils.lua",
					},
				},
			});

			expect(result.size).toBe(1);
			expect(result.has(typesKey("dist", "utils.d.ts"))).toBe(true);
			// No root "." mapping exists
			expect(result.has(typesKey("dist", "index.d.ts"))).toBe(false);
		});
	});

	describe("when export value is an array", () => {
		it("uses first non-null entry", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": [null, { types: "./dist/index.d.ts", require: "./dist/init.lua" }],
				},
			});

			expect(result.size).toBe(1);
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});
	});

	describe("when subpath contains wildcard", () => {
		it("skips wildcard subpaths", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						require: "./dist/init.lua",
					},
					"./features/*": {
						types: "./dist/features/*.d.ts",
						require: "./dist/features/*.lua",
					},
				},
			});

			expect(result.size).toBe(1);
			expect(result.has(typesKey("dist", "index.d.ts"))).toBe(true);
		});
	});

	describe("custom conditions (source export pattern)", () => {
		it("maps source condition target to import runtime path", () => {
			const result = resolvePackageExports(
				PKG,
				{
					exports: {
						".": {
							source: "./src/index.ts",
							import: "./dist/init.luau",
							types: "./dist/index.d.ts",
						},
					},
				},
				["source"],
			);

			// Standard types → runtime mapping
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.luau"));
			// Source → runtime mapping (so rbxtsc can find the .luau when TS resolved via source)
			expect(result.get(typesKey("src", "index.ts"))).toBe(runtimePath("dist", "init.luau"));
		});

		it("handles source condition without explicit types", () => {
			const result = resolvePackageExports(
				PKG,
				{
					exports: {
						".": {
							source: "./src/index.ts",
							import: "./dist/init.luau",
						},
					},
				},
				["source"],
			);

			expect(result.get(typesKey("src", "index.ts"))).toBe(runtimePath("dist", "init.luau"));
		});

		it("ignores unknown custom conditions not present in exports", () => {
			const result = resolvePackageExports(
				PKG,
				{
					exports: {
						".": {
							types: "./dist/index.d.ts",
							import: "./dist/init.luau",
						},
					},
				},
				["source"],
			);

			expect(result.size).toBe(1);
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.luau"));
		});

		it("works without custom conditions (backward compat)", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						require: "./dist/init.lua",
					},
				},
			});

			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});
	});

	describe("condition matching", () => {
		it("picks first matching condition (declaration order)", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						node: "./dist/node.lua",
						require: "./dist/require.lua",
						default: "./dist/default.lua",
					},
				},
			});

			// "node" comes first among runtime conditions
			expect(result.get(typesKey("dist", "index.d.ts"))).toBe(runtimePath("dist", "node.lua"));
		});

		it("falls back to top-level types for '.' when condition object has no types key", () => {
			const result = resolvePackageExports(PKG, {
				types: "./typings/index.d.ts",
				exports: {
					".": {
						require: "./dist/init.lua",
					},
				},
			});

			expect(result.get(typesKey("typings", "index.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});

		it("resolves runtime target without explicit types via adjacent .d.ts", () => {
			const result = resolvePackageExports(PKG, {
				exports: {
					".": {
						require: "./dist/init.lua",
					},
				},
			});

			// No explicit "types" — falls back to adjacent .d.ts
			expect(result.get(typesKey("dist", "init.d.ts"))).toBe(runtimePath("dist", "init.lua"));
		});
	});
});
