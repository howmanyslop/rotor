import type ts from "typescript";

import type { ProjectData } from "../../Shared/types.ts";
import { profile } from "../../Shared/util/profile.ts";
import { createProgramFactory } from "./createProgramFactory.ts";
import { getParsedCommandLine } from "./getParsedCommandLine.ts";

export function createProjectProgram(data: ProjectData, host?: ts.CompilerHost) {
	const { fileNames, options } = profile("getParsedCommandLine", () => getParsedCommandLine(data));
	const createProgram = createProgramFactory(data, options);
	return createProgram(fileNames, options, host);
}
