import { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { DEFAULT_PROJECT_OPTIONS } from "../../Shared/constants.ts";
import type { ProjectData } from "../../Shared/types.ts";
import { copyItem } from "./copyItem.ts";

const TMP_DIR = path.join(__dirname, "__copyItem_tmp__");
const ROOT_DIR = path.join(TMP_DIR, "src");
const OUT_DIR = path.join(TMP_DIR, "out");

function createPathTranslator(rootDir = ROOT_DIR) {
	return new PathTranslator(rootDir, OUT_DIR, undefined, false, true);
}

function createProjectData(overrides: Partial<ProjectData["projectOptions"]> = {}): ProjectData {
	return {
		projectOptions: { ...DEFAULT_PROJECT_OPTIONS, ...overrides },
		rojoResolver: undefined as never,
	} as never;
}

function touch(filePath: string, content = "") {
	fs.outputFileSync(filePath, content);
	return filePath;
}

describe("copyItem", () => {
	beforeEach(() => {
		fs.mkdirpSync(ROOT_DIR);
		fs.mkdirpSync(OUT_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
	});

	it("should copy non-compilable files from rootDir to outDir", () => {
		touch(path.join(ROOT_DIR, "module.luau"), "print('hello')");
		const data = createProjectData();
		const translator = createPathTranslator();

		copyItem(data, translator, ROOT_DIR);

		expect(fs.existsSync(path.join(OUT_DIR, "module.luau"))).toBe(true);
	});

	it("should not copy outDir when rootDir encompasses it", () => {
		// rootDir is the project root (TMP_DIR), outDir is TMP_DIR/out
		// This simulates rootDir: "." with outDir: "out"
		const projectRootTranslator = createPathTranslator(TMP_DIR);

		touch(path.join(TMP_DIR, "src", "module.luau"), "print('hello')");
		touch(path.join(OUT_DIR, "stale.luau"), "print('stale')");

		const data = createProjectData();

		copyItem(data, projectRootTranslator, TMP_DIR);

		// Source file should be copied
		expect(fs.existsSync(path.join(OUT_DIR, "src", "module.luau"))).toBe(true);
		// outDir should not be recursively copied into itself
		expect(fs.existsSync(path.join(OUT_DIR, "out"))).toBe(false);
	});

	it("should copy sibling files when outDir is nested (e.g. build/out)", () => {
		const nestedOutDir = path.join(TMP_DIR, "build", "out");
		fs.mkdirpSync(nestedOutDir);
		const nestedTranslator = new PathTranslator(TMP_DIR, nestedOutDir, undefined, false, true);

		touch(path.join(TMP_DIR, "build", "assets", "texture.rbxm"), "binary");
		touch(path.join(TMP_DIR, "src", "module.luau"), "print('hello')");

		const data = createProjectData();

		copyItem(data, nestedTranslator, TMP_DIR);

		// Files alongside nested outDir should still be copied
		expect(fs.existsSync(path.join(nestedOutDir, "build", "assets", "texture.rbxm"))).toBe(true);
		expect(fs.existsSync(path.join(nestedOutDir, "src", "module.luau"))).toBe(true);
		// outDir should not be recursively copied into itself
		expect(fs.existsSync(path.join(nestedOutDir, "build", "out"))).toBe(false);
	});

	it("should not copy node_modules when rootDir encompasses it", () => {
		const projectRootTranslator = createPathTranslator(TMP_DIR);

		touch(path.join(TMP_DIR, "src", "module.luau"), "print('hello')");
		touch(path.join(TMP_DIR, "node_modules", "@rbxts", "some-package", "init.luau"), "");

		const data = createProjectData();

		copyItem(data, projectRootTranslator, TMP_DIR);

		expect(fs.existsSync(path.join(OUT_DIR, "src", "module.luau"))).toBe(true);
		expect(fs.existsSync(path.join(OUT_DIR, "node_modules"))).toBe(false);
	});
});
