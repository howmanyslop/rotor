import { type } from "arktype";
import { createRequire } from "node:module";
import path from "path";
import ts from "typescript";

import { LogService } from "../../Shared/classes/LogService.ts";
import { ProjectError } from "../../Shared/errors/ProjectError.ts";
import type { ProjectOptions } from "../../Shared/types.ts";

// Resolve tsconfig "extends" paths whether rbxtsc runs from the bundled CJS
// dist or directly from ESM source under node, where bare `require` is undefined.
const requireModule = createRequire(import.meta.url);

export const rbxtsTsConfigSchema = type({
	"+": "delete",
	"allowCommentDirectives?": "boolean",
	"includePath?": "string",
	"logTruthyChanges?": "boolean",
	"luau?": "boolean",
	"noInclude?": "boolean",
	"optimizedLoops?": "boolean",
	"rojo?": "string",
	"type?": "'game' | 'model' | 'package'",
});

export const RBXTS_TSCONFIG_KEYS: ReadonlySet<string> = new Set([
	"allowCommentDirectives",
	"includePath",
	"logTruthyChanges",
	"luau",
	"noInclude",
	"optimizedLoops",
	"rojo",
	"type",
]);

const PATH_FIELDS: ReadonlyArray<"includePath" | "rojo"> = ["includePath", "rojo"];

function readRbxtsFromChain(tsConfigPath: string, visited: Set<string>): Partial<ProjectOptions> | undefined {
	const normalized = path.resolve(tsConfigPath);
	if (visited.has(normalized)) return undefined;
	visited.add(normalized);

	if (!ts.sys.fileExists(normalized)) return undefined;

	const rawJson = ts.sys.readFile(normalized);
	if (rawJson === undefined) return undefined;

	// TypeScript internals canonicalize paths to forward slashes; passing a Windows
	// backslash path here trips a debug assertion on malformed JSON.
	const posixPath = normalized.replace(/\\/g, "/");
	const parsed = ts.parseConfigFileTextToJson(posixPath, rawJson);
	if (parsed.error) {
		throw new ProjectError(
			`Failed to parse tsconfig at ${normalized}: ${ts.flattenDiagnosticMessageText(parsed.error.messageText, "\n")}`,
		);
	}

	const config = parsed.config as { extends?: string; rbxts?: unknown } | undefined;
	if (config === undefined) return undefined;

	let merged: Partial<ProjectOptions> = {};
	if (typeof config.extends === "string") {
		const extendedPath = requireModule.resolve(config.extends, {
			paths: [path.dirname(normalized)],
		});
		const parent = readRbxtsFromChain(extendedPath, visited);
		if (parent !== undefined) merged = { ...parent };
	}

	if (config.rbxts === undefined) {
		return Object.keys(merged).length > 0 ? merged : undefined;
	}

	const raw = config.rbxts;
	if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
		throw new ProjectError(`tsconfig "rbxts" field at ${normalized} must be an object`);
	}

	const rawRecord = raw as Record<string, unknown>;
	for (const key of Object.keys(rawRecord)) {
		if (!RBXTS_TSCONFIG_KEYS.has(key)) {
			LogService.warn(`Unknown "rbxts" option "${key}" in ${normalized} (ignored)`);
		}
	}

	const validated = rbxtsTsConfigSchema(rawRecord);
	if (validated instanceof type.errors) {
		throw new ProjectError(`Invalid "rbxts" config in ${normalized}: ${validated.summary}`);
	}

	// Cast: arktype returns string literal "game" | "model" | "package", ProjectOptions.type is ProjectType enum.
	// Values are identical but TS treats string enums as nominal.
	const current = { ...validated } as Partial<ProjectOptions>;

	const tsConfigDir = path.dirname(normalized);
	for (const field of PATH_FIELDS) {
		const value = current[field];
		if (typeof value === "string" && value.length > 0) {
			current[field] = path.resolve(tsConfigDir, value);
		}
	}

	return { ...merged, ...current };
}

/**
 * If `visitedOut` is provided, it receives the absolute paths of every tsconfig
 * file encountered during the extends walk (including missing files). Watch mode
 * subscribes to these so rbxts edits trigger a reload.
 */
export function getTsConfigProjectOptions(
	tsConfigPath: string,
	visitedOut?: Set<string>,
): Partial<ProjectOptions> | undefined {
	return readRbxtsFromChain(tsConfigPath, visitedOut ?? new Set());
}
