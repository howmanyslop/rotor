import fs from "fs-extra";
import path from "path";
import ts from "typescript";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { buildSolution } from "./buildSolution.ts";
import { buildSolutionWatch } from "./buildSolutionWatch.ts";

// Dedicated fixture (copy of tests/build-mode) so the watch tests can run in
// parallel with buildSolution.test.ts without disk contention on shared/out.
const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/build-mode-watch");
const ROOT_TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.json");
const LUA_OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

// Dedicated copy of tests/cross-project-dts so this file can run in parallel
// with buildSolution.test.ts without disk contention on lib/out and game/out.
const CROSS_DTS_FIXTURE = path.resolve(__dirname, "../../..", "tests/cross-project-dts-watch");
const CROSS_DTS_LIB_DIR = path.join(CROSS_DTS_FIXTURE, "lib");
const CROSS_DTS_GAME_DIR = path.join(CROSS_DTS_FIXTURE, "game");
const CROSS_DTS_LIB_TSCONFIG = path.join(CROSS_DTS_LIB_DIR, "tsconfig.json");
const CROSS_DTS_GAME_TSCONFIG = path.join(CROSS_DTS_GAME_DIR, "tsconfig.json");

function cleanCrossDtsOutput() {
	for (const sub of [CROSS_DTS_LIB_DIR, CROSS_DTS_GAME_DIR]) {
		fs.removeSync(path.join(sub, "out"));
		fs.removeSync(path.join(sub, "include"));
		fs.removeSync(path.join(sub, "tsconfig.rbxtsc.tsbuildinfo"));
	}
}

interface Deferred<T = void> {
	readonly promise: Promise<T>;
	readonly resolve: (value: T | PromiseLike<T>) => void;
	readonly reject: (reason?: unknown) => void;
}

function createDeferred<T = void>(): Deferred<T> {
	let resolve!: (value: T | PromiseLike<T>) => void;
	let reject!: (reason?: unknown) => void;
	const promise = new Promise<T>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

function cleanFixtureOutput() {
	for (const sub of ["shared", "game"]) {
		fs.removeSync(path.join(FIXTURE_DIR, sub, "out"));
		fs.removeSync(path.join(FIXTURE_DIR, sub, "include"));
		fs.removeSync(path.join(FIXTURE_DIR, sub, "tsconfig.rbxtsc.tsbuildinfo"));
	}
}

describe("buildSolutionWatch", () => {
	afterEach(() => {
		cleanFixtureOutput();
	});

	describe("initial drain", () => {
		it("emits .luau files for all referenced projects on initial drain", async () => {
			const drainComplete = createDeferred();
			const shutdown = createDeferred();
			const watchPromise = buildSolutionWatch(
				ROOT_TSCONFIG,
				{ ...LUA_OPTIONS },
				{},
				{
					testHooks: {
						onReady: () => drainComplete.resolve(),
					},
					shutdown: shutdown.promise,
				},
			);

			await drainComplete.promise;
			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/init.luau"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/init.luau"))).toBe(true);

			shutdown.resolve();
			await watchPromise;
		});
	});

	describe("source-edit incremental drain", () => {
		it("re-emits affected files on TS source edit", async () => {
			const readyDeferred = createDeferred();
			let drainCount = 0;
			let secondDrain: Deferred | undefined;
			const shutdown = createDeferred();
			const watchPromise = buildSolutionWatch(
				ROOT_TSCONFIG,
				{ ...LUA_OPTIONS },
				{},
				{
					testHooks: {
						onReady: () => readyDeferred.resolve(),
						onDrainComplete: () => {
							drainCount++;
							if (drainCount === 2 && secondDrain !== undefined) {
								secondDrain.resolve();
							}
						},
					},
					shutdown: shutdown.promise,
				},
			);

			await readyDeferred.promise;
			expect(drainCount).toBe(1);

			const sharedIndex = path.join(FIXTURE_DIR, "shared/src/index.ts");
			const originalContent = fs.readFileSync(sharedIndex, "utf-8");

			secondDrain = createDeferred();
			fs.writeFileSync(sharedIndex, originalContent + "\nexport const watchMarker = 1;\n");

			try {
				await secondDrain.promise;
				const sharedLuau = fs.readFileSync(path.join(FIXTURE_DIR, "shared/out/init.luau"), "utf-8");
				expect(sharedLuau).toContain("watchMarker");
			} finally {
				fs.writeFileSync(sharedIndex, originalContent);
			}

			shutdown.resolve();
			await watchPromise;
		}, 30000);
	});

	describe("asset drain", () => {
		it("copies non-TS files into outDir when added under rootDir", async () => {
			const readyDeferred = createDeferred();
			let assetDrainCount = 0;
			let assetDrained: Deferred | undefined;
			const shutdown = createDeferred();
			const watchPromise = buildSolutionWatch(
				ROOT_TSCONFIG,
				{ ...LUA_OPTIONS },
				{},
				{
					testHooks: {
						onReady: () => readyDeferred.resolve(),
						onAssetDrainComplete: () => {
							assetDrainCount++;
							assetDrained?.resolve();
						},
					},
					shutdown: shutdown.promise,
				},
			);

			await readyDeferred.promise;

			const assetPath = path.join(FIXTURE_DIR, "shared/src/asset.luau");
			assetDrained = createDeferred();
			fs.writeFileSync(assetPath, "return { value = 42 }\n");

			try {
				await assetDrained.promise;
				expect(assetDrainCount).toBeGreaterThanOrEqual(1);
				expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/asset.luau"))).toBe(true);
			} finally {
				fs.removeSync(assetPath);
				fs.removeSync(path.join(FIXTURE_DIR, "shared/out/asset.luau"));
			}

			shutdown.resolve();
			await watchPromise;
		}, 30000);

		it("removes orphan output when its asset is deleted", async () => {
			const assetPath = path.join(FIXTURE_DIR, "shared/src/orphan.luau");
			const assetOutPath = path.join(FIXTURE_DIR, "shared/out/orphan.luau");
			fs.writeFileSync(assetPath, "return { stale = true }\n");

			const readyDeferred = createDeferred();
			let deleteDrained: Deferred | undefined;
			const shutdown = createDeferred();
			const watchPromise = buildSolutionWatch(
				ROOT_TSCONFIG,
				{ ...LUA_OPTIONS },
				{},
				{
					testHooks: {
						onReady: () => readyDeferred.resolve(),
						onAssetDrainComplete: () => deleteDrained?.resolve(),
					},
					shutdown: shutdown.promise,
				},
			);

			try {
				await readyDeferred.promise;
				expect(fs.existsSync(assetOutPath)).toBe(true);

				deleteDrained = createDeferred();
				fs.removeSync(assetPath);
				await deleteDrained.promise;
				expect(fs.existsSync(assetOutPath)).toBe(false);
			} finally {
				if (fs.existsSync(assetPath)) fs.removeSync(assetPath);
				if (fs.existsSync(assetOutPath)) fs.removeSync(assetOutPath);
			}

			shutdown.resolve();
			await watchPromise;
		}, 30000);
	});

	describe("cross-project import resolution", () => {
		beforeEach(() => {
			cleanCrossDtsOutput();
		});

		afterEach(() => {
			cleanCrossDtsOutput();
		});

		it("routes cross-project imports through the owning project's outDir when lib is up-to-date at watch startup", async () => {
			// Pre-build lib via batch so its tsbuildinfo + out/ exist. When the
			// watcher starts on game's tsconfig, TS's solution builder will see
			// lib as up-to-date and never drain it — the same condition that
			// triggers the bug in batch mode. populateCrossProjectImportPathMap
			// runs once at watch startup and must cover lib's source files so
			// game's drain emits the correct Rojo mount.
			const libResult = await buildSolution(CROSS_DTS_LIB_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(libResult).toBe(ts.ExitStatus.Success);

			const ready = createDeferred();
			const shutdown = createDeferred();
			const watchPromise = buildSolutionWatch(
				CROSS_DTS_GAME_TSCONFIG,
				{ ...LUA_OPTIONS },
				{},
				{
					testHooks: {
						onReady: () => ready.resolve(),
					},
					shutdown: shutdown.promise,
				},
			);

			try {
				await ready.promise;

				const gameIndex = fs.readFileSync(path.join(CROSS_DTS_GAME_DIR, "out/init.luau"), "utf-8");
				expect(gameIndex).toContain('"shared", "regular")');
				expect(gameIndex).toContain('"shared", "handauth")');
				expect(gameIndex).not.toContain('"game", "regular")');
				expect(gameIndex).not.toContain('"game", "handauth")');
			} finally {
				shutdown.resolve();
				await watchPromise;
			}
		}, 30000);
	});

	describe("CLI guard: --build --watch --emitDeclarationOnly", () => {
		it("rejects the combination via the build command handler", async () => {
			// Import the build command lazily so the rest of the suite doesn't pay
			// the import cost on every file load.
			const buildCommand = (await import("../../CLI/commands/build.ts")) as unknown as {
				default: { handler: (argv: Record<string, unknown>) => Promise<void> };
			};
			const handler = buildCommand.default.handler;

			const writeSpy = vi.spyOn(process.stderr, "write").mockImplementation(() => true);
			const stdoutSpy = vi.spyOn(process.stdout, "write").mockImplementation(() => true);
			const priorExitCode = process.exitCode;
			process.exitCode = undefined;

			try {
				await handler({
					project: ROOT_TSCONFIG,
					build: true,
					watch: true,
					emitDeclarationOnly: true,
				});
				expect(process.exitCode).toBe(1);
				const stderrText = writeSpy.mock.calls.map(c => String(c[0])).join("");
				const stdoutText = stdoutSpy.mock.calls.map(c => String(c[0])).join("");
				expect(stderrText + stdoutText).toMatch(/emitDeclarationOnly/);
			} finally {
				process.exitCode = priorExitCode;
				writeSpy.mockRestore();
				stdoutSpy.mockRestore();
			}
		});
	});
});
