import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { createNodeModulesPathMapping } from "./createNodeModulesPathMapping.ts";

const TMP_DIR = path.join(__dirname, "__createNodeModulesPathMapping_tmp__");
const SCOPE_PATH = path.join(TMP_DIR, "@test");

function writePkg(name: string, pkgJson: object, extras?: Record<string, object>) {
	const pkgDir = path.join(SCOPE_PATH, name);
	fs.outputJsonSync(path.join(pkgDir, "package.json"), pkgJson);
	if (extras) {
		for (const [file, content] of Object.entries(extras)) {
			fs.outputJsonSync(path.join(pkgDir, file), content);
		}
	}
	return pkgDir;
}

describe("createNodeModulesPathMapping", () => {
	beforeEach(() => fs.mkdirpSync(SCOPE_PATH));
	afterEach(() => fs.removeSync(TMP_DIR));

	it("remaps runtime path to Rojo project $path", () => {
		const pkgDir = writePkg(
			"flux",
			{
				exports: {
					".": {
						types: "./dist/index.d.ts",
						import: "./dist/init.luau",
					},
				},
			},
			{ "default.project.json": { name: "flux", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "out", "init.luau"));
	});

	it("does not remap when runtime already matches $path", () => {
		const pkgDir = writePkg(
			"flux",
			{
				exports: {
					".": {
						types: "./out/index.d.ts",
						import: "./out/init.luau",
					},
				},
			},
			{ "default.project.json": { name: "flux", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "out", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "out", "init.luau"));
	});

	it("discovers custom-named *.project.json for remap", () => {
		const pkgDir = writePkg(
			"flux",
			{
				exports: {
					".": {
						types: "./dist/index.d.ts",
						import: "./dist/init.luau",
					},
				},
			},
			{ "game.project.json": { name: "flux", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "out", "init.luau"));
	});

	it("does not remap when no *.project.json exists", () => {
		const pkgDir = writePkg("flux", {
			exports: {
				".": {
					types: "./dist/index.d.ts",
					import: "./dist/init.luau",
				},
			},
		});

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "dist", "init.luau"));
	});

	it("remaps main fallback through rojo tree", () => {
		const pkgDir = writePkg(
			"flux",
			{
				main: "./dist/init.luau",
				types: "./dist/index.d.ts",
			},
			{ "default.project.json": { name: "flux", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "out", "init.luau"));
	});

	it("does not double-remap when runtime already inside multi-segment $path", () => {
		const pkgDir = writePkg(
			"regexp",
			{
				main: "./build/wally/src/init.lua",
				types: "./build/wally/src/index.d.ts",
			},
			{ "default.project.json": { name: "RegExp", tree: { $path: "build/wally/src" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "build", "wally", "src", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "build", "wally", "src", "init.lua"));
	});

	it("remaps to multi-segment $path when runtime differs", () => {
		const pkgDir = writePkg(
			"regexp",
			{
				exports: {
					".": {
						types: "./dist/index.d.ts",
						import: "./dist/init.lua",
					},
				},
			},
			{ "default.project.json": { name: "RegExp", tree: { $path: "build/wally/src" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "build", "wally", "src", "init.lua"));
	});

	it("preserves nested subpath structure during remap", () => {
		const pkgDir = writePkg(
			"pkg",
			{
				exports: {
					".": { types: "./dist/index.d.ts", import: "./dist/init.luau" },
					"./utils": { types: "./dist/utils.d.ts", import: "./dist/utils.luau" },
				},
			},
			{ "default.project.json": { name: "pkg", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		expect(result.get(getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts")))).toBe(
			path.join(pkgDir, "out", "init.luau"),
		);
		expect(result.get(getCanonicalFileName(path.resolve(pkgDir, "dist", "utils.d.ts")))).toBe(
			path.join(pkgDir, "out", "utils.luau"),
		);
	});

	it("skips remap when $path is not a string", () => {
		const pkgDir = writePkg(
			"pkg",
			{
				exports: {
					".": { types: "./dist/index.d.ts", import: "./dist/init.luau" },
				},
			},
			{ "default.project.json": { name: "pkg", tree: { $path: { optional: "out" } } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH]);

		const typesKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
		expect(result.get(typesKey)).toBe(path.join(pkgDir, "dist", "init.luau"));
	});

	it("remaps custom condition targets through rojo tree", () => {
		const pkgDir = writePkg(
			"flux",
			{
				exports: {
					".": {
						source: "./src/index.ts",
						import: "./dist/init.luau",
						types: "./dist/index.d.ts",
					},
				},
			},
			{ "default.project.json": { name: "flux", tree: { $path: "out" } } },
		);

		const result = createNodeModulesPathMapping([SCOPE_PATH], ["source"]);

		const sourceKey = getCanonicalFileName(path.resolve(pkgDir, "src", "index.ts"));
		expect(result.get(sourceKey)).toBe(path.join(pkgDir, "out", "init.luau"));
	});

	describe("legacy types fallback for Node10 moduleResolution", () => {
		it("adds legacy types mapping when exports types differs from top-level types", () => {
			const pkgDir = writePkg("jest-extended", {
				exports: {
					".": {
						types: "./dist/index.d.ts",
						default: "./dist/init.luau",
					},
				},
				main: "./dist/init.luau",
				types: "./types/types.d.ts",
			});

			const result = createNodeModulesPathMapping([SCOPE_PATH]);

			const exportsKey = getCanonicalFileName(path.resolve(pkgDir, "dist", "index.d.ts"));
			expect(result.get(exportsKey)).toBe(path.join(pkgDir, "dist", "init.luau"));

			const legacyKey = getCanonicalFileName(path.resolve(pkgDir, "types", "types.d.ts"));
			expect(result.get(legacyKey)).toBe(path.join(pkgDir, "dist", "init.luau"));
		});

		it("does not duplicate when top-level types matches exports types", () => {
			writePkg("pkg", {
				exports: { ".": { types: "./dist/index.d.ts", import: "./dist/init.luau" } },
				types: "./dist/index.d.ts",
			});

			const result = createNodeModulesPathMapping([SCOPE_PATH]);
			expect(result.size).toBe(1);
		});

		it("remaps legacy types through rojo tree", () => {
			const pkgDir = writePkg(
				"pkg",
				{
					exports: { ".": { types: "./dist/index.d.ts", default: "./dist/init.luau" } },
					main: "./dist/init.luau",
					types: "./types/types.d.ts",
				},
				{ "default.project.json": { name: "pkg", tree: { $path: "out" } } },
			);

			const result = createNodeModulesPathMapping([SCOPE_PATH]);

			const legacyKey = getCanonicalFileName(path.resolve(pkgDir, "types", "types.d.ts"));
			expect(result.get(legacyKey)).toBe(path.join(pkgDir, "out", "init.luau"));
		});
	});
});
