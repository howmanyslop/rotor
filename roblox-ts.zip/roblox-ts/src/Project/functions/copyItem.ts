import type { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";

import { DTS_EXT, NODE_MODULES } from "../../Shared/constants.ts";
import type { ProjectData } from "../index.ts";
import { isCompilableFile } from "../util/isCompilableFile.ts";

function isDescendantOf(child: string, parent: string): boolean {
	const normalizedChild = path.normalize(child);
	const normalizedParent = path.normalize(parent);
	return normalizedChild === normalizedParent || normalizedChild.startsWith(normalizedParent + path.sep);
}

export function copyItem(data: ProjectData, pathTranslator: PathTranslator, item: string) {
	const normalizedItem = path.normalize(item);
	const normalizedOutDir = path.normalize(pathTranslator.outDir);

	// When rootDir encompasses outDir (e.g. rootDir: "."), fs.copySync throws
	// "Cannot copy to a subdirectory of itself". Copy children individually,
	// skipping outDir.
	if (isDescendantOf(normalizedOutDir, normalizedItem)) {
		for (const child of fs.readdirSync(normalizedItem)) {
			const childPath = path.join(normalizedItem, child);
			if (child === NODE_MODULES || childPath === normalizedOutDir) {
				continue;
			}
			if (isDescendantOf(normalizedOutDir, childPath)) {
				// outDir is nested deeper under this child — recurse to preserve siblings
				copyItem(data, pathTranslator, childPath);
				continue;
			}
			copyItemSingle(data, pathTranslator, childPath);
		}
		return;
	}

	copyItemSingle(data, pathTranslator, item);
}

function copyItemSingle(data: ProjectData, pathTranslator: PathTranslator, item: string) {
	fs.copySync(item, pathTranslator.getOutputPath(item), {
		filter: (src, dest) => {
			if (
				data.projectOptions.writeOnlyChanged &&
				fs.pathExistsSync(dest) &&
				!fs.lstatSync(src).isDirectory() &&
				fs.readFileSync(src).toString() === fs.readFileSync(dest).toString()
			) {
				return false;
			}

			if (src.endsWith(DTS_EXT)) {
				return pathTranslator.declaration;
			}

			return !isCompilableFile(src);
		},
		dereference: true,
	});
}
