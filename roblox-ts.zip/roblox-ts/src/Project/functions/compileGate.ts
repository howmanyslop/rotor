/**
 * Single-flight gate that serializes overlapping watch-mode compiles.
 *
 * The watcher's chokidar handlers may fire `trigger()` while a previous
 * compile is still flushing async writes. Without a gate the second compile
 * would interleave with the first, racing over `out/`, the tsbuildinfo, and
 * the transformer service.
 *
 * Properties:
 *
 * - At most one `runCompile` runs at a time (emit + clean + copy fully
 *   settled before the next starts).
 * - File changes during an in-flight compile accumulate in the caller's
 *   filesTo* sets (chokidar handlers mutate them synchronously outside
 *   `runCompile`). The gate guarantees exactly one trailing compile
 *   absorbs all changes — `pendingTrigger` collapses N intermediate
 *   triggers to one.
 * - Every fire-and-forget call site has an explicit `.catch()` via
 *   `onFailure` — no `void` unhandled-rejection trap.
 */
export interface CompileGate {
	/** Schedules a compile if none in flight, else marks one pending. */
	trigger: () => void;
	/**
	 * Awaits the current in-flight compile and any pending trailing one.
	 * Useful for tests that need to observe completion.
	 */
	drain: () => Promise<void>;
}

export interface CompileGateOptions {
	/**
	 * Runs the compile pipeline (read+emit+copy+clean). Errors thrown here
	 * are routed to `onFailure`. Returning normally implies the compile
	 * finished — no `onSuccess` callback is required.
	 */
	readonly runCompile: () => Promise<void>;
	/**
	 * Called for any throw escaping `runCompile`. Must NOT throw — its
	 * own exceptions would otherwise leak as an unhandled rejection on
	 * the fire-and-forget path that triggered the run.
	 */
	readonly onFailure: (error: unknown) => void;
}

export function createCompileGate(options: CompileGateOptions): CompileGate {
	let inFlight: Promise<void> | undefined;
	let pendingTrigger = false;

	function trigger(): void {
		if (inFlight) {
			pendingTrigger = true;
			return;
		}
		const run = (async () => {
			try {
				await options.runCompile();
			} catch (error) {
				try {
					options.onFailure(error);
				} catch {
					// Swallow — if onFailure itself throws there's nothing
					// safer we can do from a fire-and-forget context. The
					// gate must still clear inFlight and run trailing
					// triggers; otherwise a buggy onFailure would wedge
					// the watcher.
				}
			} finally {
				inFlight = undefined;
				if (pendingTrigger) {
					pendingTrigger = false;
					trigger();
				}
			}
		})();
		inFlight = run;
	}

	async function drain(): Promise<void> {
		while (inFlight) {
			await inFlight;
		}
	}

	return { trigger, drain };
}
