import fs from "fs-extra";
import path from "path";
import { describe, expect, it } from "vitest";

import { rbxtsTsConfigSchema } from "./getTsConfigProjectOptions.ts";

const SCHEMA_FILE = path.resolve(__dirname, "../../../schemas/rbxts-tsconfig.schema.json");

interface JsonSchemaProperty {
	description?: string;
	[key: string]: unknown;
}

function stripDescriptions(value: unknown): unknown {
	if (Array.isArray(value)) {
		return value.map(stripDescriptions);
	}
	if (value !== null && typeof value === "object") {
		const out: Record<string, unknown> = {};
		for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
			if (key === "description") continue;
			out[key] = stripDescriptions(entry);
		}
		return out;
	}
	return value;
}

describe("rbxts tsconfig schema file", () => {
	it("exists", () => {
		expect(fs.existsSync(SCHEMA_FILE)).toBe(true);
	});

	it("matches the arktype schema output", () => {
		const committed = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf-8")) as {
			properties: { rbxts: JsonSchemaProperty };
		};
		const generated = rbxtsTsConfigSchema.toJsonSchema() as JsonSchemaProperty;

		// Strip the outer $schema meta from the generated schema and the committed schema's
		// description/$schema keys that aren't part of the structural shape.
		const { $schema: _generatedMeta, ...generatedBody } = generated;
		const committedRbxts = stripDescriptions(committed.properties.rbxts) as JsonSchemaProperty;
		const normalizedGenerated = stripDescriptions(generatedBody) as JsonSchemaProperty;

		// committed wrapper adds "additionalProperties: false"; arktype output already has that
		// (via "+": "delete"), so we compare the body directly.
		expect(committedRbxts).toEqual(normalizedGenerated);
	});

	it("has a $schema reference", () => {
		const committed = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf-8")) as { $schema?: string };
		expect(committed.$schema).toBe("http://json-schema.org/draft-07/schema#");
	});
});
