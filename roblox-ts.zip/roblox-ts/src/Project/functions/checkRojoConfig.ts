import type { RojoResolver } from "@isentinel/rojo-utils";
import type { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";

import { errors } from "../../Shared/diagnostics.ts";
import { isPathDescendantOf } from "../../Shared/util/isPathDescendantOf.ts";
import { DiagnosticService } from "../../TSTransformer/classes/DiagnosticService.ts";
import type { ProjectData } from "../index.ts";

export function checkRojoConfig(
	data: ProjectData,
	rojoResolver: RojoResolver,
	rootDirs: ReadonlyArray<string>,
	pathTranslator: PathTranslator,
) {
	if (data.rojoConfigPath !== undefined) {
		for (const partition of rojoResolver.getPartitions()) {
			for (const rootDir of rootDirs) {
				if (isPathDescendantOf(partition.fsPath, rootDir)) {
					const rojoConfigDir = path.dirname(data.rojoConfigPath);
					const outPath = pathTranslator.getOutputPath(partition.fsPath);

					const inputPath = path.relative(rojoConfigDir, partition.fsPath);
					const suggestedPath = path.relative(rojoConfigDir, outPath);
					DiagnosticService.addDiagnostic(errors.rojoPathInSrc(inputPath, suggestedPath));
				}
			}
		}
	}
}
