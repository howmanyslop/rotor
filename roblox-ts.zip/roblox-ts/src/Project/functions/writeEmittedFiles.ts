import fs from "fs";
import path from "path";

export interface PendingWrite {
	readonly path: string;
	readonly data: string;
}

export interface WriteEmittedFilesOptions {
	/**
	 * Skip write if the target already contains `data` byte-for-byte.
	 * Mirrors `projectOptions.writeOnlyChanged`.
	 */
	readonly writeOnlyChanged: boolean;
	/**
	 * Max concurrent `writeFile` operations. Default computation lives in
	 * `defaultConcurrency()`: reads `RBXTSC_WRITE_CONCURRENCY` if set, else
	 * `UV_THREADPOOL_SIZE × 2`, else `8` (pool=4 × 2). Single source of truth.
	 */
	readonly concurrency?: number;
	/**
	 * Fallback to a serial sync path when the queue is smaller than this.
	 * Avoids worker/promise overhead on incremental builds. Default 16.
	 */
	readonly syncCutoff?: number;
	/**
	 * Whether the host filesystem treats `Foo.txt` and `foo.txt` as different
	 * files. Used by the duplicate-path guard. The helper itself does not
	 * import `ts`, so the caller passes this in.
	 */
	readonly useCaseSensitiveFileNames: boolean;
}

const CONCURRENCY_HARD_CAP = 256;
const DEFAULT_SYNC_CUTOFF = 16;

export function defaultConcurrency(): number {
	const overrideRaw = process.env.RBXTSC_WRITE_CONCURRENCY;
	if (overrideRaw !== undefined && overrideRaw !== "") {
		const override = Number(overrideRaw);
		if (Number.isFinite(override) && override > 0) {
			return Math.min(Math.floor(override), CONCURRENCY_HARD_CAP);
		}
	}
	const poolRaw = Number(process.env.UV_THREADPOOL_SIZE);
	const pool = Number.isFinite(poolRaw) && poolRaw > 0 ? poolRaw : 4;
	return Math.min(pool * 2, CONCURRENCY_HARD_CAP);
}

/**
 * Returns the subset of `writes` that were actually emitted (skipped
 * unchanged files are excluded). Order matches input order.
 */
async function settle<T>(promise: Promise<T>): Promise<{ ok: true; value: T } | { ok: false; error: unknown }> {
	try {
		return { ok: true, value: await promise };
	} catch (error) {
		return { ok: false, error };
	}
}

function normalizePathForGuard(p: string, caseSensitive: boolean): string {
	const resolved = path.resolve(p);
	return caseSensitive ? resolved : resolved.toLowerCase();
}

function checkForDuplicates(writes: ReadonlyArray<PendingWrite>, caseSensitive: boolean): void {
	const seen = new Map<string, string>();
	for (const { path: writePath } of writes) {
		const key = normalizePathForGuard(writePath, caseSensitive);
		const existing = seen.get(key);
		if (existing !== undefined) {
			throw new RangeError(`writeEmittedFiles: duplicate output path detected: ${existing} and ${writePath}`);
		}
		seen.set(key, writePath);
	}
}

export async function writeEmittedFiles(
	writes: ReadonlyArray<PendingWrite>,
	options: WriteEmittedFilesOptions,
): Promise<ReadonlyArray<string>> {
	if (writes.length === 0) {
		return [];
	}

	// Reject duplicates before any IO so a partial write can't strand state.
	// `forceConsistentCasingInFileNames` catches the common case-collision in
	// TS, but `paths` mapping and transformer-generated outputs can still
	// produce collisions; this is the second line of defense.
	checkForDuplicates(writes, options.useCaseSensitiveFileNames);

	// Pre-create unique parent dirs once — avoids the per-file dentry walk
	// inside fs-extra.outputFile and matches the bench's "leg 1" win.
	const dirs = new Set<string>();
	for (const { path: writePath } of writes) {
		dirs.add(path.dirname(writePath));
	}
	await Promise.all(Array.from(dirs, dir => fs.promises.mkdir(dir, { recursive: true })));

	// `emitted[i]` records whether index `i` was written. Filter at the end
	// so the returned order matches input order, matching the previous sync
	// loop's "push in input order" semantics.
	const emitted = new Array<boolean>(writes.length).fill(false);

	const syncCutoff = options.syncCutoff ?? DEFAULT_SYNC_CUTOFF;
	if (writes.length < syncCutoff) {
		// Small queue: skip async/drainer overhead. Mirrors the original
		// sync loop's semantics so incremental builds don't pay for fan-out.
		for (let index = 0; index < writes.length; index++) {
			const { path: writePath, data } = writes[index];
			if (options.writeOnlyChanged && fs.existsSync(writePath)) {
				const existing = fs.readFileSync(writePath, "utf-8");
				if (existing === data) {
					continue;
				}
			}
			fs.writeFileSync(writePath, data);
			emitted[index] = true;
		}
	} else {
		const requested = options.concurrency ?? defaultConcurrency();
		const drainCount = Math.max(1, Math.min(Math.floor(requested), CONCURRENCY_HARD_CAP));

		let nextIndex = 0;
		let firstError: unknown | undefined;
		let cancelled = false;

		async function drain(): Promise<void> {
			// Drainers race for indices on a shared counter. The cancel flag
			// is checked at two points (before and after the increment) so a
			// reject visible to peers can't slip past on the same tick.
			// In-flight writeFile calls can't be cancelled, but no new index
			// is claimed once cancelled — bounding post-error writes to at
			// most `drainCount` already past the second check at error time.
			while (true) {
				if (cancelled) return;
				const index = nextIndex++;
				if (index >= writes.length) return;
				if (cancelled) return;
				try {
					const { path: writePath, data } = writes[index];
					if (options.writeOnlyChanged) {
						let existing: string | undefined;
						try {
							existing = await fs.promises.readFile(writePath, "utf-8");
						} catch {
							existing = undefined;
						}
						if (existing === data) {
							continue;
						}
					}
					await fs.promises.writeFile(writePath, data);
					emitted[index] = true;
				} catch (error) {
					if (firstError === undefined) {
						firstError = error;
						cancelled = true;
					}
					return;
				}
			}
		}

		// `Promise.allSettled` is ES2020, tsconfig.lib targets ES2019 — use
		// an ES2015-safe settle helper so the helper compiles cleanly.
		const drainers = new Array<Promise<void>>(drainCount);
		for (let index = 0; index < drainCount; index++) {
			drainers[index] = drain();
		}
		const results = await Promise.all(drainers.map(settle));
		void results;
		if (firstError !== undefined) {
			throw firstError;
		}
	}

	const result = new Array<string>();
	for (let index = 0; index < writes.length; index++) {
		if (emitted[index]) {
			result.push(writes[index].path);
		}
	}
	return result;
}
