import { addMapping, GenMapping, setSourceContent, toEncodedMap } from "@jridgewell/gen-mapping";
import luau, { render, RenderState, solveTempIds } from "@roblox-ts/luau-ast";

import type { SourcePosition } from "../../Shared/types.ts";

function countNewlines(text: string): number {
	let count = 0;
	for (let i = 0; i < text.length; i++) {
		if (text.charCodeAt(i) === 10) count++;
	}
	return count;
}

function hasStatements(node: luau.Statement): node is luau.Statement & { statements: luau.List<luau.Statement> } {
	return "statements" in node && luau.list.isList((node as never as { statements: unknown }).statements);
}

function getElseBody(node: luau.Statement): luau.IfStatement | luau.List<luau.Statement> | undefined {
	if (node.kind === luau.SyntaxKind.IfStatement) {
		return (node as luau.IfStatement).elseBody;
	}
}

function addStatementListMappings(
	state: RenderState,
	map: GenMapping,
	stmtList: luau.List<luau.Statement>,
	startLine: number,
	sourcePositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceEndPositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceFileName: string,
) {
	let innerLine = startLine;
	let listNode = stmtList.head;
	while (listNode !== undefined) {
		const sourcePos = sourcePositionMap.get(listNode.value);
		if (sourcePos) {
			addMapping(map, {
				generated: { line: innerLine, column: 0 },
				source: sourceFileName,
				original: { line: sourcePos.line + 1, column: sourcePos.column },
			});
		}

		state.pushListNode(listNode);
		const rendered = render(state, listNode.value);
		state.popListNode();
		const lines = countNewlines(rendered);

		addInnerMappings(
			state,
			map,
			listNode.value,
			innerLine,
			sourcePositionMap,
			sourceEndPositionMap,
			sourceFileName,
		);

		innerLine += lines;
		listNode = listNode.next;
	}
}

function getCallArgs(stmt: luau.Statement): luau.List<luau.Expression> | undefined {
	if (stmt.kind !== luau.SyntaxKind.CallStatement) return undefined;
	return (stmt as luau.CallStatement).expression.args;
}

function addEndMapping(map: GenMapping, endLine: number, sourcePos: SourcePosition, sourceFileName: string) {
	addMapping(map, {
		generated: { line: endLine, column: 0 },
		source: sourceFileName,
		original: { line: sourcePos.line + 1, column: sourcePos.column },
	});
}

function shouldMapEnd(stmt: luau.Statement): boolean {
	return stmt.kind !== luau.SyntaxKind.RepeatStatement;
}

// Returns the source position for the closing `end` keyword. Falls back to the
// statement's start position when no explicit end position exists (maps `end`
// to the opening statement line rather than the closing brace).
function getEndPos(
	stmt: luau.Node,
	sourcePositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceEndPositionMap: WeakMap<luau.Node, SourcePosition>,
): SourcePosition | undefined {
	return sourceEndPositionMap.get(stmt) ?? sourcePositionMap.get(stmt);
}

function addInnerMappings(
	state: RenderState,
	map: GenMapping,
	stmt: luau.Statement,
	startLine: number,
	sourcePositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceEndPositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceFileName: string,
	isElseifChild?: boolean,
) {
	if (!hasStatements(stmt)) {
		const args = getCallArgs(stmt);
		if (args === undefined) return;

		// Walk call args to find FunctionExpression callbacks
		// The call header (e.g. `describe("test", function()\n`) is on the same
		// line as the statement, so the function body starts at startLine + 1.
		// For multiple function args, we need the rendered text to count newlines.
		const fullRendered = render(state, stmt);
		let argNode = args.head;
		while (argNode !== undefined) {
			if (argNode.value.kind === luau.SyntaxKind.FunctionExpression) {
				const fnExpr = argNode.value as luau.FunctionExpression;
				const fnRendered = render(state, fnExpr);
				const fnIndex = fullRendered.indexOf(fnRendered);
				if (fnIndex !== -1) {
					const linesBeforeFn = countNewlines(fullRendered.slice(0, fnIndex));
					const fnBodyStart = startLine + linesBeforeFn + 1;
					addStatementListMappings(
						state,
						map,
						fnExpr.statements,
						fnBodyStart,
						sourcePositionMap,
						sourceEndPositionMap,
						sourceFileName,
					);

					// Map `end)` line for multi-line FunctionExpressions
					const fnLines = countNewlines(fnRendered);
					if (fnLines > 0) {
						const endPos = getEndPos(stmt, sourcePositionMap, sourceEndPositionMap);
						if (endPos) {
							addEndMapping(map, startLine + linesBeforeFn + fnLines, endPos, sourceFileName);
						}
					}
				}
			}
			argNode = argNode.next;
		}
		return;
	}

	// Header (e.g. `local function name()\n`, `if cond then\n`) takes 1 line
	addStatementListMappings(
		state,
		map,
		stmt.statements,
		startLine + 1,
		sourcePositionMap,
		sourceEndPositionMap,
		sourceFileName,
	);

	// Handle elseif/else bodies for IfStatement
	const elseBody = getElseBody(stmt);
	if (elseBody) {
		const statementsRendered = luau.list
			.toArray(stmt.statements)
			.map(s => render(state, s))
			.join("");
		const headerLines = 1; // "if cond then\n"
		const bodyLines = countNewlines(statementsRendered);

		if (luau.list.isList(elseBody)) {
			// `else\n` takes 1 line after the then-body
			const elseStartLine = startLine + headerLines + bodyLines + 1;
			addStatementListMappings(
				state,
				map,
				elseBody,
				elseStartLine,
				sourcePositionMap,
				sourceEndPositionMap,
				sourceFileName,
			);
		} else {
			// elseif — it's an IfStatement, recurse
			const elseifLine = startLine + headerLines + bodyLines;
			const sourcePos = sourcePositionMap.get(elseBody);
			if (sourcePos) {
				addMapping(map, {
					generated: { line: elseifLine, column: 0 },
					source: sourceFileName,
					original: { line: sourcePos.line + 1, column: sourcePos.column },
				});
			}
			addInnerMappings(
				state,
				map,
				elseBody,
				elseifLine,
				sourcePositionMap,
				sourceEndPositionMap,
				sourceFileName,
				true,
			);
		}
	}

	// Map `end` line for block statements (not elseif children — outermost owns `end`)
	if (!isElseifChild && shouldMapEnd(stmt)) {
		const endPos = getEndPos(stmt, sourcePositionMap, sourceEndPositionMap);
		if (endPos) {
			const rendered = render(state, stmt);
			const totalLines = countNewlines(rendered);
			addEndMapping(map, startLine + totalLines - 1, endPos, sourceFileName);
		}
	}
}

export function renderASTWithSourceMap(
	ast: luau.List<luau.Statement>,
	sourcePositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceEndPositionMap: WeakMap<luau.Node, SourcePosition>,
	sourceFileName: string,
	outputFileName: string,
	sourceContent?: string,
) {
	const state = new RenderState();
	solveTempIds(state, ast);

	const map = new GenMapping({ file: outputFileName });
	if (sourceContent !== undefined) {
		setSourceContent(map, sourceFileName, sourceContent);
	}
	let outputLine = 1;
	let code = "";

	let listNode = ast.head;
	let hasFinalStatement = false;
	while (listNode !== undefined) {
		if (hasFinalStatement && !luau.isComment(listNode.value)) break;
		hasFinalStatement ||= luau.isFinalStatement(listNode.value);

		state.pushListNode(listNode);

		const sourcePos = sourcePositionMap.get(listNode.value);
		if (sourcePos) {
			addMapping(map, {
				generated: { line: outputLine, column: 0 },
				source: sourceFileName,
				original: { line: sourcePos.line + 1, column: sourcePos.column },
			});
		}

		const rendered = render(state, listNode.value);
		const lines = countNewlines(rendered);

		addInnerMappings(
			state,
			map,
			listNode.value,
			outputLine,
			sourcePositionMap,
			sourceEndPositionMap,
			sourceFileName,
		);

		outputLine += lines;
		code += rendered;

		state.popListNode();
		listNode = listNode.next;
	}

	return { code, map: toEncodedMap(map) };
}
