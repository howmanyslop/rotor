import fs from "fs-extra";
import nodeFs from "node:fs";
import path from "path";
import ts from "typescript";
import { afterEach, describe, expect, it } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { buildSolution } from "./buildSolution.ts";

const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/langservice-realpath");
const BUILD_TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.build.json");
const PROJECT_OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

const NODE_MODULES = path.join(FIXTURE_DIR, "node_modules");
// Shared scope directory mimicking pnpm's `.pnpm/<pkg>/node_modules/@rbxts`,
// where a package and its dependencies sit as SIBLINGS (not nested under each
// other). This is the layout that makes a transitive dep reachable only via the
// host's real path. Everything lives under the fixture's own (gitignored)
// node_modules so no stray files are left if a run is interrupted.
const STORE_SCOPE = path.join(NODE_MODULES, ".pnpm/@rbxts+langservice-host@1.0.0/node_modules/@rbxts");
const HOST_REAL = path.join(STORE_SCOPE, "langservice-host");
const LEAF_REAL = path.join(STORE_SCOPE, "langservice-leaf");
const HOST_LINK = path.join(NODE_MODULES, "@rbxts/langservice-host");

// The packages are generated at runtime (rather than committed) so pnpm never
// adopts them as @rbxts-scoped workspace projects.
const LEAF_DTS = "export interface LeafOptions {\n\tphantom?: boolean;\n}\n";
const HOST_DTS =
	'import { LeafOptions } from "@rbxts/langservice-leaf";\n\n' +
	"export interface HostOptions extends LeafOptions {\n\textra?: number;\n}\n";

function writePackage(dir: string, name: string, dts: string) {
	fs.mkdirpSync(dir);
	fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ name, version: "1.0.0", types: "index.d.ts" }));
	fs.writeFileSync(path.join(dir, "index.d.ts"), dts);
}

// Recreate the relevant part of pnpm's isolated node_modules:
//   node_modules/.pnpm/<host>/node_modules/@rbxts/langservice-host   (real host)
//   node_modules/.pnpm/<host>/node_modules/@rbxts/langservice-leaf   (real leaf, SIBLING)
//   node_modules/@rbxts/langservice-host  ->  .pnpm/<host>/.../langservice-host
// `langservice-leaf` is reachable only by walking up from the host's REAL path
// to the shared scope's node_modules — so resolving it requires canonicalizing
// the host symlink via realpath first. There is deliberately no top-level
// `node_modules/@rbxts/langservice-leaf`.
function buildIsolatedLayout() {
	cleanLayout();
	writePackage(HOST_REAL, "@rbxts/langservice-host", HOST_DTS);
	writePackage(LEAF_REAL, "@rbxts/langservice-leaf", LEAF_DTS);
	fs.mkdirpSync(path.dirname(HOST_LINK));
	// `junction` works on Windows without elevated privileges and is resolved by
	// realpath; on other platforms Node ignores the type and makes a dir symlink.
	nodeFs.symlinkSync(HOST_REAL, HOST_LINK, "junction");
}

function cleanLayout() {
	fs.removeSync(NODE_MODULES);
}

function cleanOutput() {
	fs.removeSync(path.join(FIXTURE_DIR, "out"));
	fs.removeSync(path.join(FIXTURE_DIR, "tsconfig.rbxtsc.tsbuildinfo"));
}

describe("language service resolves transitive deps through pnpm symlinks", () => {
	afterEach(() => {
		cleanOutput();
		cleanLayout();
	});

	// Regression: the transformer language-service host must forward `realpath`,
	// otherwise a transitive @rbxts type re-exported through a top-level-symlinked
	// package fails to resolve under pnpm's isolated node_modules, producing a
	// phantom TS2353 (`'phantom' does not exist`). See createTransformerWatcher.ts.
	it("compiles a transitive type re-exported through a symlinked package", async () => {
		buildIsolatedLayout();

		const result = await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});

		expect(result).toBe(ts.ExitStatus.Success);
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/init.luau"))).toBe(true);
	});
});
