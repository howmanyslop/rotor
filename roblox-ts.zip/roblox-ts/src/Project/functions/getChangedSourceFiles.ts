import path from "path";
import ts from "typescript";

import { getChangedFilePaths } from "./getChangedFilePaths.ts";

export function getChangedSourceFiles(
	program: ts.BuilderProgram,
	rootDirs: ReadonlyArray<string>,
	pathHints?: Array<string>,
) {
	const normalizedRootDirs = rootDirs.map(d => path.normalize(d) + path.sep);
	const sourceFiles = new Array<ts.SourceFile>();
	for (const fileName of getChangedFilePaths(program, pathHints)) {
		const sourceFile = program.getSourceFile(fileName);
		if (sourceFile && !sourceFile.isDeclarationFile && !ts.isJsonSourceFile(sourceFile)) {
			const normalized = path.normalize(sourceFile.fileName);
			if (normalizedRootDirs.some(rootDir => normalized.startsWith(rootDir))) {
				sourceFiles.push(sourceFile);
			}
		}
	}
	return sourceFiles;
}
