import type { RbxPath, RojoResolver } from "@isentinel/rojo-utils";
import { NetworkType } from "@isentinel/rojo-utils";
import { renderAST } from "@roblox-ts/luau-ast";
import type { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";
import ts from "typescript";

import { LogService } from "../../Shared/classes/LogService.ts";
import { ProjectType } from "../../Shared/constants.ts";
import type { ProjectData } from "../../Shared/types.ts";
import { assert } from "../../Shared/util/assert.ts";
import { benchmarkAsyncIfVerbose, benchmarkIfVerbose } from "../../Shared/util/benchmark.ts";
import { createTextDiagnostic } from "../../Shared/util/createTextDiagnostic.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { profile } from "../../Shared/util/profile.ts";
import { DiagnosticService } from "../../TSTransformer/classes/DiagnosticService.ts";
import { MultiTransformState, transformSourceFile, TransformState } from "../../TSTransformer/index.ts";
import { createTransformServices } from "../../TSTransformer/util/createTransformServices.ts";
import { rojoResolverCache } from "../classes/RojoResolverCache.ts";
import transformPathsTransformer from "../transformers/builtin/transformPaths.ts";
import { transformTypeReferenceDirectives } from "../transformers/builtin/transformTypeReferenceDirectives.ts";
import { createTransformerList, flattenIntoTransformers } from "../transformers/createTransformerList.ts";
import { createTransformerWatcher } from "../transformers/createTransformerWatcher.ts";
import { getPluginConfigs } from "../transformers/getPluginConfigs.ts";
import { wrapTransformersWithParentFix } from "../transformers/wrapTransformersWithParentFix.ts";
import { getCustomPreEmitDiagnostics } from "../util/getCustomPreEmitDiagnostics.ts";
import { checkFileName } from "./checkFileName.ts";
import { checkRojoConfig } from "./checkRojoConfig.ts";
import { createNodeModulesPathMapping } from "./createNodeModulesPathMapping.ts";
import { printSourceFileWithTraceMap } from "./printSourceFileWithTraceMap.ts";
import { renderASTWithSourceMap } from "./renderASTWithSourceMap.ts";
import type { PendingWrite } from "./writeEmittedFiles.ts";
import { writeEmittedFiles } from "./writeEmittedFiles.ts";

function inferProjectType(data: ProjectData, rojoResolver: RojoResolver): ProjectType {
	if (data.isPackage) {
		return ProjectType.Package;
	} else if (rojoResolver.isGame) {
		return ProjectType.Game;
	} else {
		return ProjectType.Model;
	}
}

function emitResultFailure(messageText: string): ts.EmitResult {
	return {
		emitSkipped: true,
		diagnostics: [createTextDiagnostic(messageText)],
	};
}

/**
 * 'transpiles' TypeScript project into a logically identical Luau project.
 *
 * writes rendered Luau source to the out directory.
 */
export async function compileFiles(
	program: ts.Program,
	data: ProjectData,
	pathTranslator: PathTranslator,
	sourceFiles: Array<ts.SourceFile>,
	importPathMap: ReadonlyMap<string, string> = new Map(),
): Promise<ts.EmitResult> {
	const compilerOptions = program.getCompilerOptions();

	const multiTransformState = new MultiTransformState();

	const outDir = compilerOptions.outDir!;

	const rojoResolver = profile(data.rojoConfigPath ? "rojoResolver (fromPath)" : "rojoResolver (synthetic)", () =>
		data.rojoConfigPath
			? rojoResolverCache.getFromPath(data.rojoConfigPath)
			: rojoResolverCache.getSynthetic(outDir),
	);

	for (const warning of rojoResolver.getWarnings()) {
		LogService.warn(warning);
	}

	profile("checkRojoConfig", () => checkRojoConfig(data, rojoResolver, getRootDirs(compilerOptions), pathTranslator));

	profile("checkFileName loop (program.getSourceFiles)", () => {
		for (const sourceFile of program.getSourceFiles()) {
			if (!path.normalize(sourceFile.fileName).startsWith(data.nodeModulesPath)) {
				checkFileName(sourceFile.fileName);
			}
		}
	});

	const pkgRojoResolvers = profile("pkgRojoResolvers", () =>
		compilerOptions.typeRoots!.map(root => rojoResolverCache.getSynthetic(root)),
	);
	const nodeModulesPathMapping = profile("createNodeModulesPathMapping", () =>
		createNodeModulesPathMapping(compilerOptions.typeRoots!, compilerOptions.customConditions),
	);

	const projectType = data.projectOptions.type ?? inferProjectType(data, rojoResolver);

	if (projectType !== ProjectType.Package && data.rojoConfigPath === undefined) {
		return emitResultFailure("Non-package projects must have a Rojo project file!");
	}

	let runtimeLibRbxPath: RbxPath | undefined;
	if (projectType !== ProjectType.Package) {
		runtimeLibRbxPath = rojoResolver.getRbxPathFromFilePath(
			path.join(data.projectOptions.includePath, "RuntimeLib.lua"),
		);
		if (!runtimeLibRbxPath) {
			return emitResultFailure("Rojo project contained no data for include folder!");
		} else if (rojoResolver.getNetworkType(runtimeLibRbxPath) !== NetworkType.Unknown) {
			return emitResultFailure("Runtime library cannot be in a server-only or client-only container!");
		} else if (rojoResolver.isIsolated(runtimeLibRbxPath)) {
			return emitResultFailure("Runtime library cannot be in an isolated container!");
		}
	}

	if (DiagnosticService.hasErrors()) return { emitSkipped: true, diagnostics: DiagnosticService.flush() };

	LogService.writeLineIfVerbose(`compiling as ${projectType}..`);

	const fileWriteQueue = new Array<{ sourceFile: ts.SourceFile; source: string; sourceMapJson?: string }>();
	const progressMaxLength = `${sourceFiles.length}/${sourceFiles.length}`.length;

	let proxyProgram = program;
	const originalSourceTexts = new Map<string, string>();
	const transformedPending = new Array<PendingWrite>();
	// Plugins configured with `"afterDeclarations": true` belong to the
	// declaration printer's pass, not the source-file pass — they're handed to
	// `proxyProgram.emit` below rather than to `ts.transformNodes`.
	const pluginAfterDeclarations: NonNullable<ts.CustomTransformers["afterDeclarations"]> = [];

	if (compilerOptions.plugins && compilerOptions.plugins.length > 0 && sourceFiles.length > 0) {
		await benchmarkAsyncIfVerbose(`running transformers..`, async () => {
			const pluginConfigs = profile("getPluginConfigs", () => getPluginConfigs(data.tsConfigPath));
			const transformers = profile("createTransformerList", () => {
				const transformerList = createTransformerList(program, pluginConfigs, data.projectPath);
				pluginAfterDeclarations.push(...(transformerList.afterDeclarations ?? []));
				return wrapTransformersWithParentFix(flattenIntoTransformers(transformerList));
			});
			if (transformers.length > 0) {
				// capture original source text before reprinting for sourcesContent
				if (compilerOptions.sourceMap) {
					for (const sf of sourceFiles) {
						originalSourceTexts.set(sf.fileName, sf.text);
					}
				}

				if (data.transformerWatcher === undefined) {
					data.transformerWatcher = profile("createTransformerWatcher", () =>
						createTransformerWatcher(program),
					);
				}
				const { service, updateFile } = data.transformerWatcher;
				const sourceFileByName = new Map(sourceFiles.map(sf => [sf.fileName, sf]));
				const transformResult = profile("ts.transformNodes", () =>
					ts.transformNodes(
						undefined,
						undefined,
						ts.factory,
						compilerOptions,
						sourceFiles,
						transformers,
						false,
					),
				);

				if (transformResult.diagnostics) DiagnosticService.addDiagnostics(transformResult.diagnostics);

				profile("transformer reprint loop", () => {
					for (const sourceFile of transformResult.transformed) {
						if (!ts.isSourceFile(sourceFile)) continue;
						// Identity-preserving transformers leave the SourceFile reference untouched.
						// Skipping the reprint here saves the print cost, and the watcher's
						// content-equality check in updateFile prevents a spurious version bump
						// so service.getProgram() can reuse the existing bound parse.
						if (sourceFileByName.get(sourceFile.fileName) === sourceFile) {
							updateFile(sourceFile.fileName, sourceFile.text);
							if (data.projectOptions.writeTransformedFiles) {
								const outPath = pathTranslator.getOutputTransformedPath(sourceFile.fileName);
								transformedPending.push({ path: outPath, data: sourceFile.text });
							}
							continue;
						}
						// transformed nodes don't have symbol or type information (or they have out of date information)
						// there's no way to "rebind" an existing file, so we have to reprint it
						const { text: source, traceMap } = printSourceFileWithTraceMap(sourceFile, compilerOptions);
						updateFile(sourceFile.fileName, source);
						if (traceMap) {
							multiTransformState.reprintTraceMaps.set(sourceFile.fileName, traceMap);
						}
						if (data.projectOptions.writeTransformedFiles) {
							const outPath = pathTranslator.getOutputTransformedPath(sourceFile.fileName);
							transformedPending.push({ path: outPath, data: source });
						}
					}
				});

				proxyProgram = profile("service.getProgram", () => service.getProgram()!);
			}
		});
	}

	// Flush transformed-output writes between the transformer block and the
	// main compile loop — same on-disk ordering as the prior inline
	// fs.outputFileSync calls, faster execution via bounded fan-out.
	if (transformedPending.length > 0) {
		await writeEmittedFiles(transformedPending, {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
		});
	}

	if (DiagnosticService.hasErrors()) return { emitSkipped: true, diagnostics: DiagnosticService.flush() };

	const typeChecker = profile("proxyProgram.getTypeChecker", () => proxyProgram.getTypeChecker());
	const services = profile("createTransformServices", () => createTransformServices(typeChecker));

	// Program-level diagnostics are file-independent, but ts.getPreEmitDiagnostics
	// re-collects them for every file — hoist them out of the per-file loop and
	// request only the syntactic + semantic sets per file below.
	DiagnosticService.addDiagnostics(
		profile("programLevelDiagnostics", () => [
			...proxyProgram.getConfigFileParsingDiagnostics(),
			...proxyProgram.getOptionsDiagnostics(),
			...proxyProgram.getGlobalDiagnostics(),
		]),
	);
	if (DiagnosticService.hasErrors()) return { emitSkipped: true, diagnostics: DiagnosticService.flush() };

	for (let i = 0; i < sourceFiles.length; i++) {
		const sourceFile = proxyProgram.getSourceFile(sourceFiles[i].fileName);
		assert(sourceFile);
		const progress = `${i + 1}/${sourceFiles.length}`.padStart(progressMaxLength);
		benchmarkIfVerbose(`${progress} compile ${path.relative(process.cwd(), sourceFile.fileName)}`, () => {
			DiagnosticService.addDiagnostics(
				profile("getPreEmitDiagnostics", () => [
					...proxyProgram.getSyntacticDiagnostics(sourceFile),
					...proxyProgram.getSemanticDiagnostics(sourceFile),
				]),
			);
			DiagnosticService.addDiagnostics(
				profile("getCustomPreEmitDiagnostics", () => getCustomPreEmitDiagnostics(data, sourceFile)),
			);
			if (DiagnosticService.hasErrors()) return;

			const transformState = new TransformState(
				proxyProgram,
				data,
				services,
				pathTranslator,
				multiTransformState,
				compilerOptions,
				rojoResolver,
				pkgRojoResolvers,
				nodeModulesPathMapping,
				runtimeLibRbxPath,
				typeChecker,
				projectType,
				sourceFile,
				importPathMap,
			);

			const luauAST = profile("transformSourceFile", () => transformSourceFile(transformState, sourceFile));
			if (DiagnosticService.hasErrors()) return;

			if (compilerOptions.sourceMap) {
				const outPath = pathTranslator.getOutputPath(sourceFile.fileName);
				const sourceRelative = path.relative(path.dirname(outPath), sourceFile.fileName);
				const sourceContent = originalSourceTexts.get(sourceFile.fileName) ?? sourceFile.text;
				const result = profile("renderASTWithSourceMap", () =>
					renderASTWithSourceMap(
						luauAST,
						transformState.sourcePositionMap,
						transformState.sourceEndPositionMap,
						sourceRelative,
						path.basename(outPath),
						sourceContent,
					),
				);
				fileWriteQueue.push({ sourceFile, source: result.code, sourceMapJson: JSON.stringify(result.map) });
			} else {
				const source = profile("renderAST", () => renderAST(luauAST));
				fileWriteQueue.push({ sourceFile, source });
			}
		});
	}

	if (DiagnosticService.hasErrors()) return { emitSkipped: true, diagnostics: DiagnosticService.flush() };

	const emittedFiles = new Array<string>();
	if (fileWriteQueue.length > 0) {
		const pending = new Array<PendingWrite>();
		for (const { sourceFile, source, sourceMapJson } of fileWriteQueue) {
			const outPath = pathTranslator.getOutputPath(sourceFile.fileName);
			pending.push({ path: outPath, data: source });
			if (sourceMapJson) {
				pending.push({ path: outPath + ".map", data: sourceMapJson });
			}
		}
		await benchmarkAsyncIfVerbose("writing compiled files", async () => {
			const emitted = await writeEmittedFiles(pending, {
				writeOnlyChanged: data.projectOptions.writeOnlyChanged,
				useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
			});
			for (const outPath of emitted) {
				if (!outPath.endsWith(".map")) emittedFiles.push(outPath);
			}
			// Declaration emit stays serial (per-file ts.sys.writeFile callback)
			// and runs for EVERY queued file, mirroring the prior unconditional
			// behavior. We must NOT gate declarations on whether the source was
			// actually written: under writeOnlyChanged, a type-only change leaves
			// the Luau output identical while still requiring a fresh .d.ts —
			// gating on source-write success would silently leave declarations
			// stale (Codex round 9 finding).
			if (compilerOptions.declaration) {
				// Plugin factories run first so the builtin rewrites see (and
				// normalize) any module specifiers a plugin introduced.
				const afterDeclarations = [
					...pluginAfterDeclarations,
					transformTypeReferenceDirectives,
					transformPathsTransformer(program, {}),
				];
				for (const { sourceFile } of fileWriteQueue) {
					proxyProgram.emit(sourceFile, ts.sys.writeFile, undefined, true, { afterDeclarations });
				}
			}
		});
	}

	profile("emitBuildInfo", () => program.emitBuildInfo());

	return { emittedFiles, emitSkipped: false, diagnostics: DiagnosticService.flush() };
}
