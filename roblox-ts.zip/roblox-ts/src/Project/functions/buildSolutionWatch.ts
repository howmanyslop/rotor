import type { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";
import ts from "typescript";

import { DTS_EXT } from "../../Shared/constants.ts";
import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
import type { ProjectOptions } from "../../Shared/types.ts";
import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { applyRbxtscBuildInfoPath } from "../../Shared/util/rbxtscBuildInfo.ts";
import { rojoResolverCache } from "../classes/RojoResolverCache.ts";
import { isCompilableFile } from "../util/isCompilableFile.ts";
import { populateCrossProjectImportPathMap } from "../util/populateCrossProjectImportPathMap.ts";
import { createCompileGate } from "./compileGate.ts";
import { copyItem } from "./copyItem.ts";
import type { createProjectData } from "./createProjectData.ts";
import type { DrainContext, LoadedResolverInfo } from "./drainInvalidatedProject.ts";
import { drainInvalidatedProject } from "./drainInvalidatedProject.ts";
import type { ProjectReferenceGraph } from "./projectReferenceGraph.ts";
import { buildProjectReferenceGraph } from "./projectReferenceGraph.ts";
import { registerRojoWatchers } from "./rojoWatchSet.ts";
import { tryRemoveOutput } from "./tryRemoveOutput.ts";

// TypeScript pins this name as a positional arg to `host.setTimeout`, which is
// how the multiplexer below tells the build trigger apart from the
// program-update, polling, and failed-lookup timers it passes straight through.
// The string is hardcoded in `typescript.js`; a version bump that renames it
// breaks the watch suite loudly, which is the design — there is no supported
// API for this hook.
const BUILD_TIMER_NAME = "timerToBuildInvalidatedProject";

export interface BuildSolutionWatchTestHooks {
	/** Fired after every build-drain cycle (after persists flush). */
	readonly onDrainComplete?: () => void;
	/** Fired after every asset-drain cycle. */
	readonly onAssetDrainComplete?: () => void;
	/** Fired once after the initial drain settles (post-create). */
	readonly onReady?: () => void;
}

export interface BuildSolutionWatchOptions {
	/** Test-only hooks. Never used by the CLI. */
	readonly testHooks?: BuildSolutionWatchTestHooks;
	/**
	 * Resolves when the caller asks the watcher to stop. The CLI never resolves
	 * this (SIGINT-or-bust); tests pass a Deferred so the watcher cleanly tears
	 * down between cases.
	 */
	readonly shutdown?: Promise<void>;
}

interface ProjectAssetContext {
	// data + pathTranslator land after the first drain's stashProjectArtifacts
	// call. They start undefined because asset-dir watchers are armed earlier
	// (on the rootDirs resolution hook) and may fire before the drain has
	// populated artifacts. runAssetDrain skips events whose project has no
	// artifacts yet.
	readonly data: ReturnType<typeof createProjectData> | undefined;
	readonly pathTranslator: PathTranslator | undefined;
	readonly rootDirs: ReadonlyArray<string>;
	readonly assetDirWatchers: Array<ts.FileWatcher>;
}

interface AssetEvent {
	readonly fsPath: string;
}

function canonical(p: string): string {
	return getCanonicalFileName(path.normalize(p));
}

function shouldDelegateToTs(fsPath: string): boolean {
	// TS owns invalidation of source + declaration files; the asset drain
	// must only handle non-compilable assets (.luau, .json, ...). Extension
	// check first so a delete event (file gone, isCompilableFile would
	// statSync-throw) still routes correctly. Directory events are filtered
	// by extension — we never delegate directories to TS.
	if (fsPath.endsWith(DTS_EXT)) return true;
	if (!fsPath.endsWith(".ts") && !fsPath.endsWith(".tsx")) return false;
	// File still on disk: confirm it's not a directory.
	try {
		return isCompilableFile(fsPath);
	} catch {
		// Stat failed (deleted) — treat as compilable since the path looks like
		// .ts/.tsx and TS owns it.
		return true;
	}
}

/**
 * Long-running watch implementation for `--build --watch`. Owns the
 * SolutionBuilderWithWatch, intercepts TS's build trigger to run an async
 * rbxts drain, and adds rojo + non-TS asset watchers on top of TS's own
 * source-file watching.
 *
 * Returns when the optional shutdown promise resolves. The CLI does not
 * provide a shutdown promise, so the call effectively never resolves and
 * the process exits via SIGINT.
 */
export async function buildSolutionWatch(
	configPath: string,
	projectOptions: ProjectOptions,
	buildOptions: ts.BuildOptions,
	watchOptions?: BuildSolutionWatchOptions,
): Promise<void> {
	const verbose = projectOptions.verbose === true;
	const diagnosticReporter = ts.createDiagnosticReporter(ts.sys, verbose);
	const watchReporter = ts.createWatchStatusReporter(ts.sys, true);

	function reportText(messageText: string, options: ts.CompilerOptions = {}) {
		watchReporter(
			{
				category: ts.DiagnosticCategory.Message,
				messageText,
				code: 0,
				file: undefined,
				length: undefined,
				start: undefined,
			},
			ts.sys.newLine,
			options,
		);
	}

	function reportDrainFailure(projectName: string | undefined, err: unknown): void {
		if (err instanceof DiagnosticError) {
			for (const d of err.diagnostics) diagnosticReporter(d);
			return;
		}
		const tagged = projectName !== undefined ? `${path.relative(process.cwd(), projectName)}: ` : "";
		const messageText = `Watch build failed: ${tagged}${err instanceof Error ? err.message : String(err)}`;
		diagnosticReporter({
			category: ts.DiagnosticCategory.Error,
			messageText,
			code: 0,
			file: undefined,
			length: undefined,
			start: undefined,
		});
	}

	const parseConfigFileHost: ts.ParseConfigFileHost = {
		fileExists: ts.sys.fileExists,
		getCurrentDirectory: ts.sys.getCurrentDirectory,
		onUnRecoverableConfigFileDiagnostic: d => diagnosticReporter(d),
		readDirectory: ts.sys.readDirectory,
		readFile: ts.sys.readFile,
		useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
	};
	const optionsToExtend: ts.CompilerOptions = {};
	if (buildOptions.emitDeclarationOnly !== undefined) {
		optionsToExtend.emitDeclarationOnly = buildOptions.emitDeclarationOnly;
	}

	const host = ts.createSolutionBuilderWithWatchHost(
		ts.sys,
		undefined,
		diagnosticReporter,
		ts.createBuilderStatusReporter(ts.sys, verbose),
		(diagnostic, newLine, opts) => watchReporter(diagnostic, newLine, opts),
	);
	host.getParsedCommandLine = (fileName: string) => {
		const parsed = ts.getParsedCommandLineOfConfigFile(fileName, optionsToExtend, parseConfigFileHost);
		if (parsed) applyRbxtscBuildInfoPath(parsed.options);
		return parsed;
	};

	// setTimeout multiplexer: intercept TS's build-trigger timer name and
	// route it through our async drain gate. Pass everything else through.
	// TS pins this string at typescript.js (~136715-136725); a version bump
	// that renames it would break interception loudly via the unit tests.
	const realSetTimeout = ts.sys.setTimeout!;
	const realClearTimeout = ts.sys.clearTimeout!;
	let buildTimerId: ReturnType<typeof realSetTimeout> | undefined;

	host.setTimeout = (cb, ms, ...args) => {
		if (args.length > 0 && args[0] === BUILD_TIMER_NAME) {
			if (buildTimerId !== undefined) realClearTimeout(buildTimerId);
			buildTimerId = realSetTimeout(() => {
				buildTimerId = undefined;
				buildGate.trigger();
			}, ms);
			return buildTimerId;
		}
		return realSetTimeout(cb, ms, ...args);
	};
	host.clearTimeout = id => {
		if (id !== undefined && id === buildTimerId) buildTimerId = undefined;
		realClearTimeout(id);
	};

	// Resolver-to-projects + per-resolver watcher dispose tracking.
	// Re-registered every drain so a resolver's walkedConfigFiles change
	// (e.g. user added a nested rojo file) is reflected in the watch set.
	const resolverDisposers = new Map<string, () => void>(); // key: kind|scope-key
	const resolverOwners = new Map<string, Set<string>>(); // resolverKey -> projects
	const projectAssetCtx = new Map<string, ProjectAssetContext>();

	// Cross-project import map. Entries land per-project via the drain hook;
	// the importPathMapOwnership map (below) tracks which project wrote which
	// entries so a re-drained project replaces its own entries cleanly. A
	// renamed-then-removed source still leaves a stale entry until the
	// owning project re-drains, since the drain only re-walks files
	// `tsProgram.getSourceFiles()` still returns.
	const importPathMap = new Map<string, string>();
	const pendingRojoCachePersists = new Array<() => void>();
	const pendingCopyFilesPersists = new Array<() => void>();
	const resolvedConfigPath = canonical(configPath);

	// A solution coordinator has no compilable files of its own. Same gate
	// as buildSolution.ts so per-project rbxts options resolve consistently.
	let isSolutionCoordinator = false;
	const parsedRootConfig = ts.readConfigFile(configPath, ts.sys.readFile);
	if (parsedRootConfig.error) {
		diagnosticReporter(parsedRootConfig.error);
	}
	const rootCfg = parsedRootConfig.config ?? {};
	isSolutionCoordinator =
		Array.isArray(rootCfg.files) &&
		rootCfg.files.length === 0 &&
		!rootCfg.include &&
		Array.isArray(rootCfg.references) &&
		rootCfg.references.length > 0;

	function resolverScopeKey(info: { kind: "fromPath" | "synthetic"; key: string }): string {
		return `${info.kind}|${canonical(info.key)}`;
	}

	function handleProjectDrainStart(project: string): void {
		// Drop this project from every scope it previously owned, BEFORE the
		// drain calls onResolverLoaded with the current set. A project that
		// changes its rbxts.rojo / typeRoots mid-session would otherwise
		// leave the old scopes' watchers active and keep force-invalidating
		// itself on later rojo edits to those stale scopes.
		const projectKey = canonical(project);
		for (const [scope, owners] of resolverOwners) {
			if (!owners.has(projectKey)) continue;
			owners.delete(projectKey);
			if (owners.size === 0) {
				const dispose = resolverDisposers.get(scope);
				if (dispose !== undefined) {
					dispose();
					resolverDisposers.delete(scope);
				}
				resolverOwners.delete(scope);
			}
		}
	}

	function handleResolverLoaded(info: LoadedResolverInfo): void {
		const scope = resolverScopeKey(info);
		const projectKey = canonical(info.project);
		let owners = resolverOwners.get(scope);
		if (owners === undefined) {
			owners = new Set();
			resolverOwners.set(scope, owners);
		}
		owners.add(projectKey);

		// Re-register the watcher set so walkedConfigFiles drift since the
		// last drain is reflected — drop the old disposer first.
		const existing = resolverDisposers.get(scope);
		if (existing !== undefined) existing();

		const dispose = registerRojoWatchers({
			host,
			resolver: info.resolver,
			onInvalidate: () => onRojoChange(info.kind, info.key),
		});
		resolverDisposers.set(scope, dispose);
	}

	function handleProjectRootDirsResolved(project: string, rootDirs: ReadonlyArray<string>): void {
		const projectKey = canonical(project);
		const existing = projectAssetCtx.get(projectKey);
		// Re-derive data + pathTranslator next time we get one from the drain;
		// here we only refresh rootDirs + (re)register dir watchers.
		const oldWatchers = existing?.assetDirWatchers ?? [];
		for (const w of oldWatchers) w.close();
		const dirWatchers = new Array<ts.FileWatcher>();
		for (const rootDir of rootDirs) {
			dirWatchers.push(host.watchDirectory(rootDir, fsPath => onAssetChange(projectKey, fsPath), true));
		}
		projectAssetCtx.set(projectKey, {
			data: existing?.data,
			pathTranslator: existing?.pathTranslator,
			rootDirs,
			assetDirWatchers: dirWatchers,
		});
	}

	function stashProjectArtifacts(
		projectName: string,
		data: ReturnType<typeof createProjectData>,
		pathTranslator: PathTranslator,
	): void {
		const projectKey = canonical(projectName);
		const existing = projectAssetCtx.get(projectKey);
		projectAssetCtx.set(projectKey, {
			data,
			pathTranslator,
			rootDirs: existing?.rootDirs ?? [],
			assetDirWatchers: existing?.assetDirWatchers ?? [],
		});
	}

	// importPathMapOwnership: per-project canonical-key set tracking which
	// importPathMap entries this project owns. drainInvalidatedProject drops
	// the owned entries before repopulating so a re-drained project (e.g.
	// after a rojo mount change) overwrites its previous import paths.
	const importPathMapOwnership = new Map<string, Set<string>>();

	const ctx: DrainContext = {
		projectOptions,
		resolvedConfigPath,
		isSolutionCoordinator,
		importPathMap,
		importPathMapOwnership,
		pendingRojoCachePersists,
		pendingCopyFilesPersists,
		diagnosticReporter,
		onProjectDrainStart: handleProjectDrainStart,
		onResolverLoaded: handleResolverLoaded,
		onProjectRootDirsResolved: handleProjectRootDirsResolved,
		onProjectArtifactsResolved: stashProjectArtifacts,
	};

	// projectReferenceGraph is built once after createSolutionBuilderWithWatch
	// and refreshed at the start of each drain so a tsconfig `references` edit
	// (which TS already invalidates at the root) reaches the graph.
	let referenceGraph: ProjectReferenceGraph | undefined;
	let forceInvalidatedProjects = new Set<string>();

	function onRojoChange(kind: "fromPath" | "synthetic", key: string): void {
		if (kind === "fromPath") {
			rojoResolverCache.invalidate(key);
		} else {
			rojoResolverCache.invalidateSynthetic(key);
		}

		// Resolve current owners. handleProjectDrainStart prunes per-project
		// ownership when a project's next drain begins, so the set here is
		// always the current truth — no stale projects to force-invalidate.
		const scope = resolverScopeKey({ kind, key });
		const owners = resolverOwners.get(scope) ?? new Set<string>();

		// Force-invalidate every owning project AND its transitive dependents.
		// TS doesn't know about the rojo change so its own input-change check
		// would skip these projects' rebuilds entirely.
		const transitive = new Set<string>();
		for (const owner of owners) {
			transitive.add(owner);
			if (referenceGraph !== undefined) {
				for (const dep of referenceGraph.dependentsOf(owner)) transitive.add(dep);
			}
		}
		forceInvalidatedProjects = new Set([...forceInvalidatedProjects, ...transitive]);

		buildGate.trigger();
	}

	// Pending asset events, batched per project. The asset gate collapses
	// rapid changes into one trailing drain (matches build gate semantics).
	const pendingAssetEvents = new Map<string, Array<AssetEvent>>();

	function onAssetChange(projectKey: string, fsPath: string): void {
		if (shouldDelegateToTs(fsPath)) return;
		const queue = pendingAssetEvents.get(projectKey) ?? new Array<AssetEvent>();
		// fs.existsSync at drain time is the source of truth for delete vs
		// change — the directory callback can't reliably distinguish.
		queue.push({ fsPath });
		pendingAssetEvents.set(projectKey, queue);
		assetGate.trigger();
	}

	async function runAssetDrain(): Promise<void> {
		const snapshot = new Map(pendingAssetEvents);
		pendingAssetEvents.clear();
		for (const [projectKey, events] of snapshot) {
			const projCtx = projectAssetCtx.get(projectKey);
			// Both data + pathTranslator land in the same stashProjectArtifacts
			// call after the first drain. Guard both: an asset-dir watcher may
			// fire before the drain finishes populating them.
			if (projCtx?.pathTranslator === undefined || projCtx.data === undefined) continue;
			for (const event of events) {
				try {
					if (!ts.sys.fileExists(event.fsPath)) {
						const outPath = projCtx.pathTranslator.getOutputPath(event.fsPath);
						tryRemoveOutput(projCtx.pathTranslator, outPath);
					} else {
						copyItem(projCtx.data, projCtx.pathTranslator, event.fsPath);
					}
				} catch (err) {
					reportDrainFailure(event.fsPath, err);
				}
			}
		}
	}

	let initialDrainSettled = false;
	let builder: ts.SolutionBuilder<ts.EmitAndSemanticDiagnosticsBuilderProgram> | undefined;

	const buildGate = createCompileGate({
		runCompile: async () => {
			if (builder === undefined) return;
			// Rebuild the reference graph at the start of each drain so a root
			// tsconfig `references` edit (TS auto-invalidates the root) is
			// reflected before we start pushing force-invalidations.
			referenceGraph = buildProjectReferenceGraph(builder, { getParsedCommandLine: host.getParsedCommandLine! });

			// Push every force-invalidated project into the builder's pending
			// set before draining. Uses the ts-internal invalidateProject API —
			// the only way to make SolutionBuilder rebuild a project whose TS
			// inputs are unchanged (e.g. only its referenced project's rojo
			// mount moved). See typescript.d.ts SolutionBuilder.invalidateProject
			// @internal.
			for (const projectKey of forceInvalidatedProjects) {
				builder.invalidateProject(projectKey as ts.ResolvedConfigFilePath, ts.ProgramUpdateLevel.Full);
			}
			forceInvalidatedProjects = new Set();

			let project: ts.InvalidatedProject<ts.EmitAndSemanticDiagnosticsBuilderProgram> | undefined;
			while ((project = builder.getNextInvalidatedProject())) {
				try {
					await drainInvalidatedProject(project, ctx);
				} catch (err) {
					// Per-project failure boundary: surface diagnostic, continue
					// with siblings. Mirrors runRbxtsEmit's emittedSuccessfully
					// gate — the failed project's pending persists were never
					// pushed since the inner runRbxtsEmit threw before reaching
					// that step.
					reportDrainFailure(project.project, err);
				}
			}

			// Flush surviving persists. Each persist is independent so a single
			// throw shouldn't drop the rest.
			for (const persist of pendingRojoCachePersists) {
				try {
					persist();
				} catch (err) {
					reportDrainFailure(undefined, err);
				}
			}
			pendingRojoCachePersists.length = 0;
			for (const persist of pendingCopyFilesPersists) {
				try {
					persist();
				} catch (err) {
					reportDrainFailure(undefined, err);
				}
			}
			pendingCopyFilesPersists.length = 0;

			// Per-project pathTranslator/data already landed via the drain's
			// onProjectArtifactsResolved hook — no re-derivation here. The
			// earlier refreshProjectAssetContexts pass used entry projectOptions
			// for every project, ignoring per-project rbxts.rojo / rbxts.type
			// overrides, and asset copies would route through the wrong
			// translator on solutions with per-project Rojo configs.

			watchReporter(
				{
					category: ts.DiagnosticCategory.Message,
					messageText: "Watching for file changes.",
					code: 0,
					file: undefined,
					length: undefined,
					start: undefined,
				},
				ts.sys.newLine,
				{},
			);

			watchOptions?.testHooks?.onDrainComplete?.();
			if (!initialDrainSettled) {
				initialDrainSettled = true;
				// TS's source-file watchers arm only inside builder.build()'s
				// startWatching call — getNextInvalidatedProject alone leaves
				// them dormant. Our drain already called done() on every
				// project, so this builder.build() is a no-op pass that just
				// triggers startWatching.
				builder.build();
				watchOptions?.testHooks?.onReady?.();
			}
		},
		onFailure: err => {
			reportDrainFailure(undefined, err);
			watchOptions?.testHooks?.onDrainComplete?.();
		},
	});

	const assetGate = createCompileGate({
		runCompile: async () => {
			await runAssetDrain();
			watchOptions?.testHooks?.onAssetDrainComplete?.();
		},
		onFailure: err => {
			reportDrainFailure(undefined, err);
			watchOptions?.testHooks?.onAssetDrainComplete?.();
		},
	});

	reportText("Starting compilation in watch mode...", {});

	builder = ts.createSolutionBuilderWithWatch(host, [configPath], buildOptions);

	// Pre-populate cross-project import paths for every referenced project.
	// Matches buildSolution.ts: without this, a referenced project that's
	// already up-to-date at watch startup (no drain) leaves its source files
	// out of `importPathMap` and dependents emit the wrong Rojo mount.
	// Drain's importPathMapOwnership clears and rewrites these entries with
	// the canonical PathTranslator when the owning project later drains.
	const buildOrder = ts.getBuildOrderFromAnyBuildOrder(builder.getBuildOrder());
	populateCrossProjectImportPathMap(
		buildOrder,
		fileName => host.getParsedCommandLine!(fileName),
		projectOptions,
		importPathMap,
		importPathMapOwnership,
	);

	// Kick the initial drain manually — createSolutionBuilderWithWatch arms
	// watchers but doesn't run an immediate build, it relies on the first
	// "file change" or the user calling builder.build(). For watch mode we
	// want an upfront build.
	buildGate.trigger();

	if (watchOptions?.shutdown !== undefined) {
		await watchOptions.shutdown;
		// Cleanup on shutdown.
		for (const dispose of resolverDisposers.values()) dispose();
		resolverDisposers.clear();
		for (const ctx of projectAssetCtx.values()) {
			for (const w of ctx.assetDirWatchers) w.close();
		}
		projectAssetCtx.clear();
		if (buildTimerId !== undefined) realClearTimeout(buildTimerId);
		builder.close?.();
		return;
	}

	// CLI mode: never resolve. Process exits via SIGINT.
	await new Promise<void>(() => {});
}
