import path from "path";
import ts from "typescript";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";

export interface ProjectReferenceGraph {
	/** Projects that reference `project` either directly or transitively. */
	dependentsOf(project: string): ReadonlySet<string>;
}

export interface ProjectReferenceGraphHost {
	getParsedCommandLine(fileName: string): ts.ParsedCommandLine | undefined;
}

function canonical(fileName: string): string {
	return getCanonicalFileName(path.normalize(fileName));
}

function resolveReferencePath(referencePath: string): string {
	// `tsc` accepts `references[].path` as either a tsconfig file or a
	// directory containing tsconfig.json. SolutionBuilder normalises this
	// internally; we mirror only the basic shape since we look up via
	// getParsedCommandLine which itself accepts both.
	if (referencePath.endsWith(".json")) return referencePath;
	return path.join(referencePath, "tsconfig.json");
}

/**
 * Builds a reverse-reference graph: given a project, returns every other
 * project that transitively imports it (i.e. would need re-emit if the
 * named project's outputs / Rojo mounts change).
 *
 * Used in watch mode: a Rojo mount change inside project A alters the
 * require path that referencing project B emits, but TS sees no input
 * change to B and skips its rebuild. The graph lets the watch loop force
 * B (and everything that transitively references A) to re-emit.
 */
export function buildProjectReferenceGraph(
	builder: ts.SolutionBuilder<ts.EmitAndSemanticDiagnosticsBuilderProgram>,
	host: ProjectReferenceGraphHost,
): ProjectReferenceGraph {
	const buildOrder = ts.getBuildOrderFromAnyBuildOrder(builder.getBuildOrder());
	// Forward edges: A -> [B, C] means A references B and C.
	const forward = new Map<string, ReadonlyArray<string>>();
	for (const projectName of buildOrder) {
		const key = canonical(projectName);
		const parsed = host.getParsedCommandLine(projectName);
		const refs = parsed?.projectReferences ?? [];
		forward.set(
			key,
			refs.map(r => canonical(resolveReferencePath(r.path))),
		);
	}

	// Reverse edges: for each forward A -> B, record reverseDirect[B] += A.
	const reverseDirect = new Map<string, Set<string>>();
	for (const [from, tos] of forward) {
		for (const to of tos) {
			let set = reverseDirect.get(to);
			if (set === undefined) {
				set = new Set();
				reverseDirect.set(to, set);
			}
			set.add(from);
		}
	}

	const transitiveCache = new Map<string, ReadonlySet<string>>();

	function dependentsOf(project: string): ReadonlySet<string> {
		const key = canonical(project);
		const cached = transitiveCache.get(key);
		if (cached !== undefined) return cached;

		const result = new Set<string>();
		const stack = [key];
		while (stack.length > 0) {
			const current = stack.pop()!;
			const direct = reverseDirect.get(current);
			if (direct === undefined) continue;
			for (const dep of direct) {
				if (result.has(dep)) continue;
				result.add(dep);
				stack.push(dep);
			}
		}
		transitiveCache.set(key, result);
		return result;
	}

	return { dependentsOf };
}
