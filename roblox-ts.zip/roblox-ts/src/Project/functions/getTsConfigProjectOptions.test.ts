import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
import { getTsConfigProjectOptions } from "./getTsConfigProjectOptions.ts";

const TMP_DIR = path.join(__dirname, "__getTsConfigProjectOptions_tmp__");

function writeTsConfig(subdir: string, content: unknown): string {
	const dir = path.join(TMP_DIR, subdir);
	fs.mkdirpSync(dir);
	const tsConfigPath = path.join(dir, "tsconfig.json");
	fs.writeFileSync(tsConfigPath, JSON.stringify(content));
	return tsConfigPath;
}

describe("getTsConfigProjectOptions", () => {
	let stdoutSpy: ReturnType<typeof vi.spyOn>;

	beforeEach(() => {
		fs.mkdirpSync(TMP_DIR);
		stdoutSpy = vi.spyOn(process.stdout, "write").mockImplementation(() => true);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
		stdoutSpy.mockRestore();
	});

	function getWarnings(): Array<string> {
		return stdoutSpy.mock.calls
			.map((call: Array<unknown>) => String(call[0]))
			.filter((text: string) => text.includes("Compiler Warning"));
	}

	it("returns undefined when tsconfig file does not exist", () => {
		const missing = path.join(TMP_DIR, "missing", "tsconfig.json");
		expect(getTsConfigProjectOptions(missing)).toBeUndefined();
	});

	it("returns undefined when rbxts field is missing", () => {
		const tsConfigPath = writeTsConfig("no-rbxts", { compilerOptions: {} });
		expect(getTsConfigProjectOptions(tsConfigPath)).toBeUndefined();
	});

	it("throws when rbxts is a string", () => {
		const tsConfigPath = writeTsConfig("rbxts-string", { rbxts: "not an object" });
		expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
	});

	it("throws when rbxts is an array", () => {
		const tsConfigPath = writeTsConfig("rbxts-array", { rbxts: ["a", "b"] });
		expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
	});

	it("throws when rbxts is null", () => {
		const tsConfigPath = writeTsConfig("rbxts-null", { rbxts: null });
		expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
	});

	it("throws when rojo is not a string", () => {
		const tsConfigPath = writeTsConfig("bad-rojo", { rbxts: { rojo: 42 } });
		expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
	});

	it("throws when type is not a valid enum value", () => {
		const tsConfigPath = writeTsConfig("bad-type", { rbxts: { type: "library" } });
		expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
	});

	it("warns and strips unknown rbxts keys", () => {
		const tsConfigPath = writeTsConfig("unknown-key", {
			rbxts: { rojo: "a.project.json", unknownOpt: true },
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result).not.toHaveProperty("unknownOpt");
		expect(result?.rojo).toBe(path.resolve(path.dirname(tsConfigPath), "a.project.json"));
		const warnings = getWarnings();
		expect(warnings.some(w => w.includes("unknownOpt"))).toBe(true);
	});

	it("warns on cli-only keys placed in tsconfig", () => {
		const tsConfigPath = writeTsConfig("cli-only", {
			rbxts: { watch: true, verbose: true, writeOnlyChanged: true },
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result).toEqual({});
		const warnings = getWarnings();
		expect(warnings.some(w => w.includes("watch"))).toBe(true);
		expect(warnings.some(w => w.includes("verbose"))).toBe(true);
		expect(warnings.some(w => w.includes("writeOnlyChanged"))).toBe(true);
	});

	it("returns rbxts field contents when present", () => {
		const tsConfigPath = writeTsConfig("basic", {
			rbxts: { type: "game", luau: true },
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result).toEqual({ type: "game", luau: true });
	});

	it("resolves relative rojo path against tsconfig directory", () => {
		const tsConfigPath = writeTsConfig("rojo-rel", {
			rbxts: { rojo: "./halcyon.project.json" },
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result?.rojo).toBe(path.resolve(path.dirname(tsConfigPath), "halcyon.project.json"));
	});

	it("resolves relative includePath against tsconfig directory", () => {
		const tsConfigPath = writeTsConfig("include-rel", {
			rbxts: { includePath: "./out/include" },
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result?.includePath).toBe(path.resolve(path.dirname(tsConfigPath), "out/include"));
	});

	it("preserves absolute rojo path", () => {
		const abs = path.resolve(TMP_DIR, "abs.project.json");
		const tsConfigPath = writeTsConfig("rojo-abs", { rbxts: { rojo: abs } });
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result?.rojo).toBe(abs);
	});

	it("resolves rojo relative to tsconfig directory, not current working directory", () => {
		const tsConfigPath = writeTsConfig("cwd-diff", {
			rbxts: { rojo: "nested.project.json" },
		});
		const originalCwd = process.cwd();
		try {
			process.chdir(TMP_DIR);
			const result = getTsConfigProjectOptions(tsConfigPath);
			expect(result?.rojo).toBe(path.resolve(path.dirname(tsConfigPath), "nested.project.json"));
			expect(result?.rojo).not.toBe(path.resolve(TMP_DIR, "nested.project.json"));
		} finally {
			process.chdir(originalCwd);
		}
	});

	it("leaves non-path fields untouched", () => {
		const tsConfigPath = writeTsConfig("passthrough", {
			rbxts: {
				type: "package",
				noInclude: true,
				logTruthyChanges: true,
				allowCommentDirectives: true,
				luau: false,
				optimizedLoops: false,
			},
		});
		const result = getTsConfigProjectOptions(tsConfigPath);
		expect(result).toEqual({
			type: "package",
			noInclude: true,
			logTruthyChanges: true,
			allowCommentDirectives: true,
			luau: false,
			optimizedLoops: false,
		});
	});

	describe("extends cascade", () => {
		it("inherits rbxts from base tsconfig", () => {
			const baseDir = path.join(TMP_DIR, "extends-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(
				path.join(baseDir, "base.json"),
				JSON.stringify({ rbxts: { type: "package", luau: true } }),
			);
			const childPath = writeTsConfig("extends-child", {
				extends: "../extends-base/base.json",
			});
			const result = getTsConfigProjectOptions(childPath);
			expect(result).toEqual({ type: "package", luau: true });
		});

		it("child overrides base per-key", () => {
			const baseDir = path.join(TMP_DIR, "override-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(
				path.join(baseDir, "base.json"),
				JSON.stringify({ rbxts: { type: "package", luau: true, noInclude: false } }),
			);
			const childPath = writeTsConfig("override-child", {
				extends: "../override-base/base.json",
				rbxts: { type: "game", noInclude: true },
			});
			const result = getTsConfigProjectOptions(childPath);
			expect(result).toEqual({ type: "game", luau: true, noInclude: true });
		});

		it("resolves base rojo path against base tsconfig directory", () => {
			const baseDir = path.join(TMP_DIR, "rojo-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(
				path.join(baseDir, "base.json"),
				JSON.stringify({ rbxts: { rojo: "./base.project.json" } }),
			);
			const childPath = writeTsConfig("rojo-child", {
				extends: "../rojo-base/base.json",
			});
			const result = getTsConfigProjectOptions(childPath);
			expect(result?.rojo).toBe(path.resolve(baseDir, "base.project.json"));
		});

		it("child rojo resolves against child directory even when base also sets rojo", () => {
			const baseDir = path.join(TMP_DIR, "rojo-shadow-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(
				path.join(baseDir, "base.json"),
				JSON.stringify({ rbxts: { rojo: "./base.project.json" } }),
			);
			const childPath = writeTsConfig("rojo-shadow-child", {
				extends: "../rojo-shadow-base/base.json",
				rbxts: { rojo: "./child.project.json" },
			});
			const result = getTsConfigProjectOptions(childPath);
			expect(result?.rojo).toBe(path.resolve(path.dirname(childPath), "child.project.json"));
		});

		it("walks multi-level extends chain", () => {
			const grandparentDir = path.join(TMP_DIR, "chain-gp");
			fs.mkdirpSync(grandparentDir);
			fs.writeFileSync(
				path.join(grandparentDir, "gp.json"),
				JSON.stringify({ rbxts: { type: "package", luau: true, noInclude: true } }),
			);

			const parentDir = path.join(TMP_DIR, "chain-parent");
			fs.mkdirpSync(parentDir);
			fs.writeFileSync(
				path.join(parentDir, "parent.json"),
				JSON.stringify({
					extends: "../chain-gp/gp.json",
					rbxts: { luau: false },
				}),
			);

			const childPath = writeTsConfig("chain-child", {
				extends: "../chain-parent/parent.json",
				rbxts: { type: "game" },
			});

			const result = getTsConfigProjectOptions(childPath);
			expect(result).toEqual({ type: "game", luau: false, noInclude: true });
		});

		it("returns undefined when neither child nor base has rbxts", () => {
			const baseDir = path.join(TMP_DIR, "empty-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(path.join(baseDir, "base.json"), JSON.stringify({ compilerOptions: { strict: true } }));
			const childPath = writeTsConfig("empty-child", {
				extends: "../empty-base/base.json",
			});
			expect(getTsConfigProjectOptions(childPath)).toBeUndefined();
		});

		it("warns against the parent file when the parent has unknown keys", () => {
			const baseDir = path.join(TMP_DIR, "parent-warn-base");
			fs.mkdirpSync(baseDir);
			const parentPath = path.join(baseDir, "base.json");
			fs.writeFileSync(parentPath, JSON.stringify({ rbxts: { legacyOpt: true, rojo: "p.project.json" } }));
			const childPath = writeTsConfig("parent-warn-child", {
				extends: "../parent-warn-base/base.json",
			});
			getTsConfigProjectOptions(childPath);
			const warnings = getWarnings();
			expect(warnings.some(w => w.includes("legacyOpt") && w.includes(path.resolve(parentPath)))).toBe(true);
		});

		it("type error in base tsconfig cites the base file", () => {
			const baseDir = path.join(TMP_DIR, "base-type-error");
			fs.mkdirpSync(baseDir);
			const parentPath = path.join(baseDir, "base.json");
			fs.writeFileSync(parentPath, JSON.stringify({ rbxts: { type: "library" } }));
			const childPath = writeTsConfig("base-type-error-child", {
				extends: "../base-type-error/base.json",
			});
			const err = captureError(() => getTsConfigProjectOptions(childPath));
			expect(err).toBeInstanceOf(DiagnosticError);
			expect(String(err)).toContain(path.resolve(parentPath));
		});

		it("type error in child overrides base citation", () => {
			const baseDir = path.join(TMP_DIR, "child-type-error-base");
			fs.mkdirpSync(baseDir);
			fs.writeFileSync(path.join(baseDir, "base.json"), JSON.stringify({ rbxts: { type: "package" } }));
			const childPath = writeTsConfig("child-type-error", {
				extends: "../child-type-error-base/base.json",
				rbxts: { rojo: 42 },
			});
			const err = captureError(() => getTsConfigProjectOptions(childPath));
			expect(err).toBeInstanceOf(DiagnosticError);
			expect(String(err)).toContain(path.resolve(childPath));
		});
	});

	describe("error surfacing", () => {
		it("throws on malformed JSON tsconfig", () => {
			const dir = path.join(TMP_DIR, "bad-json");
			fs.mkdirpSync(dir);
			const tsConfigPath = path.join(dir, "tsconfig.json");
			fs.writeFileSync(tsConfigPath, "{ not valid json");
			expect(() => getTsConfigProjectOptions(tsConfigPath)).toThrow(DiagnosticError);
		});

		it("malformed JSON error includes tsconfig path", () => {
			const dir = path.join(TMP_DIR, "bad-json-path");
			fs.mkdirpSync(dir);
			const tsConfigPath = path.join(dir, "tsconfig.json");
			fs.writeFileSync(tsConfigPath, "{ not valid json");
			const err = captureError(() => getTsConfigProjectOptions(tsConfigPath));
			expect(err).toBeInstanceOf(DiagnosticError);
			expect(String(err)).toContain(path.resolve(tsConfigPath));
		});
	});

	describe("chain exposure", () => {
		it("populates visitedOut with single tsconfig", () => {
			const tsConfigPath = writeTsConfig("chain-single", { rbxts: { luau: true } });
			const chain = new Set<string>();
			getTsConfigProjectOptions(tsConfigPath, chain);
			expect(chain.has(path.resolve(tsConfigPath))).toBe(true);
		});

		it("populates visitedOut with root + all extends parents", () => {
			const gpDir = path.join(TMP_DIR, "chain-visit-gp");
			fs.mkdirpSync(gpDir);
			const gpPath = path.join(gpDir, "gp.json");
			fs.writeFileSync(gpPath, JSON.stringify({ rbxts: { luau: true } }));

			const parentDir = path.join(TMP_DIR, "chain-visit-parent");
			fs.mkdirpSync(parentDir);
			const parentPath = path.join(parentDir, "parent.json");
			fs.writeFileSync(parentPath, JSON.stringify({ extends: "../chain-visit-gp/gp.json" }));

			const childPath = writeTsConfig("chain-visit-child", {
				extends: "../chain-visit-parent/parent.json",
			});

			const chain = new Set<string>();
			getTsConfigProjectOptions(childPath, chain);
			expect(chain.has(path.resolve(childPath))).toBe(true);
			expect(chain.has(path.resolve(parentPath))).toBe(true);
			expect(chain.has(path.resolve(gpPath))).toBe(true);
		});
	});
});

function captureError(fn: () => void): unknown {
	try {
		fn();
	} catch (e) {
		return e;
	}
	return undefined;
}
