import { randomUUID } from "crypto";
import fs from "fs";
import os from "os";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { defaultConcurrency, writeEmittedFiles } from "./writeEmittedFiles.ts";

const ROOT = path.join(os.tmpdir(), "rbxts-writeEmittedFiles-tests");

function makeTmpDir(): string {
	const dir = path.join(ROOT, randomUUID());
	fs.mkdirSync(dir, { recursive: true });
	return dir;
}

describe("writeEmittedFiles", () => {
	let tmp: string;

	beforeEach(() => {
		tmp = makeTmpDir();
	});

	afterEach(() => {
		fs.rmSync(tmp, { recursive: true, force: true });
	});

	it("writes one file with content", async () => {
		const target = path.join(tmp, "one.luau");
		const result = await writeEmittedFiles([{ path: target, data: "hello" }], {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: false,
		});

		expect(result).toEqual([target]);
		expect(fs.readFileSync(target, "utf-8")).toBe("hello");
	});

	it("returns empty array for empty input", async () => {
		const result = await writeEmittedFiles([], {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: false,
		});
		expect(result).toEqual([]);
	});

	it("creates missing parent directories", async () => {
		const target = path.join(tmp, "deep", "nested", "dir", "file.luau");
		await writeEmittedFiles([{ path: target, data: "x" }], {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: false,
		});
		expect(fs.existsSync(target)).toBe(true);
	});

	it("creates each unique parent dir exactly once", async () => {
		const mkdirCalls = new Array<string>();
		const originalMkdir = fs.promises.mkdir;
		fs.promises.mkdir = (async (p: string, opts: fs.MakeDirectoryOptions & { recursive: true }) => {
			mkdirCalls.push(p);
			return originalMkdir(p, opts);
		}) as unknown as typeof fs.promises.mkdir;
		try {
			const dirA = path.join(tmp, "a");
			const dirB = path.join(tmp, "b");
			const dirC = path.join(tmp, "c");
			await writeEmittedFiles(
				[
					{ path: path.join(dirA, "1.luau"), data: "1" },
					{ path: path.join(dirA, "2.luau"), data: "2" },
					{ path: path.join(dirB, "3.luau"), data: "3" },
					{ path: path.join(dirC, "4.luau"), data: "4" },
					{ path: path.join(dirB, "5.luau"), data: "5" },
				],
				{ writeOnlyChanged: false, useCaseSensitiveFileNames: false },
			);
			const uniqueDirs = new Set(mkdirCalls);
			expect(uniqueDirs.size).toBe(3);
			expect(mkdirCalls.length).toBe(3);
		} finally {
			fs.promises.mkdir = originalMkdir;
		}
	});

	it("writes many files in parallel", async () => {
		const writes = Array.from({ length: 200 }, (_unused, index) => ({
			path: path.join(tmp, `f${index}.luau`),
			data: `data${index}`,
		}));
		const start = Date.now();
		const emitted = await writeEmittedFiles(writes, {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: false,
		});
		const elapsed = Date.now() - start;
		expect(emitted.length).toBe(200);
		// generous upper bound — async parallel should finish well under
		// 5s for 200 small files on any sane filesystem; the assertion is
		// a smoke check that the helper isn't accidentally serial.
		expect(elapsed).toBeLessThan(5000);
		for (let index = 0; index < 200; index++) {
			expect(fs.readFileSync(writes[index]!.path, "utf-8")).toBe(`data${index}`);
		}
	});

	it("preserves input order in returned emitted array", async () => {
		const writes = ["z", "y", "x", "w", "v", "u", "t", "s", "r", "q", "p", "o", "n", "m", "l", "k", "j", "i"].map(
			letter => ({
				path: path.join(tmp, `${letter}.luau`),
				data: letter,
			}),
		);
		const emitted = await writeEmittedFiles(writes, {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: false,
		});
		expect(emitted).toEqual(writes.map(w => w.path));
	});
	it("skips writes when writeOnlyChanged is true and content matches", async () => {
		const target = path.join(tmp, "match.luau");
		fs.writeFileSync(target, "same");
		const mtimeBefore = fs.statSync(target).mtimeMs;

		// Wait long enough that a fresh write would advance mtime on
		// even coarse-resolution filesystems.
		await new Promise(resolve => setTimeout(resolve, 20));

		const emitted = await writeEmittedFiles([{ path: target, data: "same" }], {
			writeOnlyChanged: true,
			useCaseSensitiveFileNames: false,
		});
		expect(emitted).toEqual([]);
		expect(fs.statSync(target).mtimeMs).toBe(mtimeBefore);
	});

	it("writes when writeOnlyChanged is true and content differs", async () => {
		const target = path.join(tmp, "differ.luau");
		fs.writeFileSync(target, "old");
		const emitted = await writeEmittedFiles([{ path: target, data: "new" }], {
			writeOnlyChanged: true,
			useCaseSensitiveFileNames: false,
		});
		expect(emitted).toEqual([target]);
		expect(fs.readFileSync(target, "utf-8")).toBe("new");
	});

	it("writes when writeOnlyChanged is true and file does not exist", async () => {
		const target = path.join(tmp, "fresh.luau");
		const emitted = await writeEmittedFiles([{ path: target, data: "data" }], {
			writeOnlyChanged: true,
			useCaseSensitiveFileNames: false,
		});
		expect(emitted).toEqual([target]);
		expect(fs.readFileSync(target, "utf-8")).toBe("data");
	});
	it("throws on duplicate output paths before writing anything", async () => {
		const target = path.join(tmp, "dup.luau");
		const writes = [
			{ path: target, data: "first" },
			{ path: target, data: "second" },
		];

		await expect(
			writeEmittedFiles(writes, {
				writeOnlyChanged: false,
				useCaseSensitiveFileNames: false,
			}),
		).rejects.toBeInstanceOf(RangeError);
		expect(fs.existsSync(target)).toBe(false);
	});

	it("throws on case-only duplicate paths on case-insensitive hosts", async () => {
		const dir = path.join(tmp, "case");
		fs.mkdirSync(dir);
		const writes = [
			{ path: path.join(dir, "Foo.luau"), data: "a" },
			{ path: path.join(dir, "foo.luau"), data: "b" },
		];

		await expect(
			writeEmittedFiles(writes, {
				writeOnlyChanged: false,
				useCaseSensitiveFileNames: false,
			}),
		).rejects.toBeInstanceOf(RangeError);
	});

	it("allows case-only duplicate paths on case-sensitive hosts", async () => {
		const dir = path.join(tmp, "sens");
		fs.mkdirSync(dir);
		const writes = [
			{ path: path.join(dir, "Foo.luau"), data: "a" },
			{ path: path.join(dir, "foo.luau"), data: "b" },
		];

		// On Windows the filesystem itself is case-insensitive, so the two
		// writes collide on disk and produce a single file. We assert only
		// that the helper does NOT throw: the per-host filesystem layer's
		// behavior is its own concern.
		const emitted = await writeEmittedFiles(writes, {
			writeOnlyChanged: false,
			useCaseSensitiveFileNames: true,
		});
		expect(emitted.length).toBe(2);
	});
	it("falls back to sync path when below syncCutoff", async () => {
		let asyncWriteCount = 0;
		const original = fs.promises.writeFile;
		fs.promises.writeFile = (async (...args: Array<unknown>) => {
			asyncWriteCount++;
			return (original as unknown as (...args: Array<unknown>) => Promise<void>)(...args);
		}) as unknown as typeof fs.promises.writeFile;
		try {
			await writeEmittedFiles(
				[
					{ path: path.join(tmp, "a.luau"), data: "a" },
					{ path: path.join(tmp, "b.luau"), data: "b" },
					{ path: path.join(tmp, "c.luau"), data: "c" },
				],
				{ writeOnlyChanged: false, useCaseSensitiveFileNames: false, syncCutoff: 16 },
			);
			expect(asyncWriteCount).toBe(0);
		} finally {
			fs.promises.writeFile = original;
		}
	});

	it("uses async path above syncCutoff", async () => {
		let asyncWriteCount = 0;
		const original = fs.promises.writeFile;
		fs.promises.writeFile = (async (...args: Array<unknown>) => {
			asyncWriteCount++;
			return (original as unknown as (...args: Array<unknown>) => Promise<void>)(...args);
		}) as unknown as typeof fs.promises.writeFile;
		try {
			const writes = Array.from({ length: 20 }, (_unused, index) => ({
				path: path.join(tmp, `f${index}.luau`),
				data: `${index}`,
			}));
			await writeEmittedFiles(writes, {
				writeOnlyChanged: false,
				useCaseSensitiveFileNames: false,
				syncCutoff: 16,
			});
			expect(asyncWriteCount).toBe(20);
		} finally {
			fs.promises.writeFile = original;
		}
	});
	it("rejects with the first write error", async () => {
		const original = fs.promises.writeFile;
		const fakeErr = new Error("synthetic write failure");
		fs.promises.writeFile = (async () => {
			throw fakeErr;
		}) as unknown as typeof fs.promises.writeFile;
		try {
			const writes = Array.from({ length: 32 }, (_unused, index) => ({
				path: path.join(tmp, `f${index}.luau`),
				data: `${index}`,
			}));
			await expect(
				writeEmittedFiles(writes, {
					writeOnlyChanged: false,
					useCaseSensitiveFileNames: false,
				}),
			).rejects.toBe(fakeErr);
		} finally {
			fs.promises.writeFile = original;
		}
	});

	it("awaits all drainers before rejecting (no ghost writes)", async () => {
		const original = fs.promises.writeFile;
		const inFlight = new Set<string>();
		const release = new Set<() => void>();
		let writeStarts = 0;
		const fakeErr = new Error("rejected one");
		let didReject = false;

		fs.promises.writeFile = (async (filePath: string) => {
			writeStarts++;
			if (!didReject) {
				didReject = true;
				throw fakeErr;
			}
			// All other writes park until the test releases them, then no-op.
			await new Promise<void>(resolve => {
				inFlight.add(filePath);
				release.add(resolve);
			});
		}) as unknown as typeof fs.promises.writeFile;

		try {
			const writes = Array.from({ length: 32 }, (_unused, index) => ({
				path: path.join(tmp, `f${index}.luau`),
				data: `${index}`,
			}));
			const helperPromise = writeEmittedFiles(writes, {
				writeOnlyChanged: false,
				useCaseSensitiveFileNames: false,
				concurrency: 4,
			});

			// Spin briefly to let drainers each pick up one task and either
			// reject or park.
			await new Promise(resolve => setTimeout(resolve, 50));

			// Release the parked writes so the drainers can return; the
			// helper must still reject with the original error.
			for (const fn of release) fn();

			await expect(helperPromise).rejects.toBe(fakeErr);

			// After settle, no additional starts: the cancel flag must have
			// stopped new index pulls.
			const startsAtSettle = writeStarts;
			await new Promise(resolve => setTimeout(resolve, 20));
			expect(writeStarts).toBe(startsAtSettle);
		} finally {
			fs.promises.writeFile = original;
		}
	});

	it("does not start new writes after first error is observed", async () => {
		const original = fs.promises.writeFile;
		const fakeErr = new Error("at index 5");
		const startedIndices = new Array<number>();
		const targets = Array.from({ length: 100 }, (_unused, index) => path.join(tmp, `f${index}.luau`));
		const indexByPath = new Map(targets.map((p, index) => [p, index]));

		fs.promises.writeFile = (async (filePath: string) => {
			const index = indexByPath.get(filePath as string);
			if (index === undefined) {
				throw new Error("unexpected path " + String(filePath));
			}
			startedIndices.push(index);
			if (index === 5) {
				throw fakeErr;
			}
		}) as unknown as typeof fs.promises.writeFile;

		try {
			const writes = targets.map(p => ({ path: p, data: "x" }));
			const concurrency = 4;
			await expect(
				writeEmittedFiles(writes, {
					writeOnlyChanged: false,
					useCaseSensitiveFileNames: false,
					concurrency,
				}),
			).rejects.toBe(fakeErr);

			// Bound: the failing index + at most `concurrency` already
			// past the second cancel check at the instant of failure.
			expect(startedIndices.length).toBeLessThanOrEqual(5 + concurrency + 1);
		} finally {
			fs.promises.writeFile = original;
		}
	});
	it("respects explicit concurrency option", async () => {
		// Stand up an instrumented writeFile that records "max simultaneous
		// in flight" so we can prove the cap actually bounds the fan-out.
		const original = fs.promises.writeFile;
		let inFlight = 0;
		let peak = 0;
		fs.promises.writeFile = (async (...args: Array<unknown>) => {
			inFlight++;
			if (inFlight > peak) peak = inFlight;
			await new Promise(resolve => setTimeout(resolve, 5));
			inFlight--;
			return (original as unknown as (...args: Array<unknown>) => Promise<void>)(...args);
		}) as unknown as typeof fs.promises.writeFile;
		try {
			const writes = Array.from({ length: 50 }, (_unused, index) => ({
				path: path.join(tmp, `c${index}.luau`),
				data: `${index}`,
			}));
			await writeEmittedFiles(writes, {
				writeOnlyChanged: false,
				useCaseSensitiveFileNames: false,
				concurrency: 3,
			});
			expect(peak).toBeLessThanOrEqual(3);
		} finally {
			fs.promises.writeFile = original;
		}
	});

	describe("defaultConcurrency", () => {
		const SAVED = {
			RBXTSC_WRITE_CONCURRENCY: process.env["RBXTSC_WRITE_CONCURRENCY"],
			UV_THREADPOOL_SIZE: process.env["UV_THREADPOOL_SIZE"],
		};

		afterEach(() => {
			if (SAVED.RBXTSC_WRITE_CONCURRENCY === undefined) {
				delete process.env["RBXTSC_WRITE_CONCURRENCY"];
			} else {
				process.env["RBXTSC_WRITE_CONCURRENCY"] = SAVED.RBXTSC_WRITE_CONCURRENCY;
			}
			if (SAVED.UV_THREADPOOL_SIZE === undefined) delete process.env["UV_THREADPOOL_SIZE"];
			else process.env["UV_THREADPOOL_SIZE"] = SAVED.UV_THREADPOOL_SIZE;
		});

		it("clamps fractional concurrency down to integer", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "2.9";
			expect(defaultConcurrency()).toBe(2);
		});

		it("clamps concurrency above hard cap to 256", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "99999";
			expect(defaultConcurrency()).toBe(256);
		});

		it("falls back to default when concurrency is 0 or negative", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "0";
			delete process.env["UV_THREADPOOL_SIZE"];
			expect(defaultConcurrency()).toBe(8);

			process.env["RBXTSC_WRITE_CONCURRENCY"] = "-5";
			expect(defaultConcurrency()).toBe(8);
		});

		it("uses RBXTSC_WRITE_CONCURRENCY env override", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "12";
			expect(defaultConcurrency()).toBe(12);
		});

		it("ignores non-numeric RBXTSC_WRITE_CONCURRENCY and falls back to pool*2", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "not-a-number";
			process.env["UV_THREADPOOL_SIZE"] = "16";
			expect(defaultConcurrency()).toBe(32);
		});

		it("scales default concurrency from UV_THREADPOOL_SIZE × 2", () => {
			delete process.env["RBXTSC_WRITE_CONCURRENCY"];
			process.env["UV_THREADPOOL_SIZE"] = "16";
			expect(defaultConcurrency()).toBe(32);
		});

		it("clamps RBXTSC_WRITE_CONCURRENCY=1e9 to hard cap", () => {
			process.env["RBXTSC_WRITE_CONCURRENCY"] = "1e9";
			expect(defaultConcurrency()).toBe(256);
		});

		it("returns 8 with no env vars (pool 4 × 2)", () => {
			delete process.env["RBXTSC_WRITE_CONCURRENCY"];
			delete process.env["UV_THREADPOOL_SIZE"];
			expect(defaultConcurrency()).toBe(8);
		});
	});
});
