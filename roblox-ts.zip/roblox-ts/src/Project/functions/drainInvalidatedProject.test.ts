import ts from "typescript";
import { describe, expect, it, vi } from "vitest";

import { DEFAULT_PROJECT_OPTIONS } from "../../Shared/constants.ts";
import type { DrainContext } from "./drainInvalidatedProject.ts";
import { drainInvalidatedProject } from "./drainInvalidatedProject.ts";

type FakeProject = ts.InvalidatedProject<ts.EmitAndSemanticDiagnosticsBuilderProgram>;

function createContext(overrides: Partial<DrainContext> = {}): DrainContext {
	return {
		projectOptions: { ...DEFAULT_PROJECT_OPTIONS },
		resolvedConfigPath: "/fake/tsconfig.json",
		isSolutionCoordinator: false,
		importPathMap: new Map(),
		pendingRojoCachePersists: [],
		pendingCopyFilesPersists: [],
		diagnosticReporter: vi.fn(),
		...overrides,
	};
}

function createBuilderProgram(compilerOptions: ts.CompilerOptions): ts.EmitAndSemanticDiagnosticsBuilderProgram {
	return { getCompilerOptions: () => compilerOptions } as unknown as ts.EmitAndSemanticDiagnosticsBuilderProgram;
}

describe("drainInvalidatedProject", () => {
	it("skips non-Build invalidated projects but still calls done", async () => {
		const done = vi.fn();
		const project = {
			kind: ts.InvalidatedProjectKind.UpdateOutputFileStamps,
			project: "/fake/project/tsconfig.json",
			done,
		} as unknown as FakeProject;

		const result = await drainInvalidatedProject(project, createContext());

		expect(result).toEqual({ hadErrors: false, skipped: true });
		expect(done).toHaveBeenCalledOnce();
	});

	it("skips when getBuilderProgram returns undefined", async () => {
		const done = vi.fn();
		const project = {
			kind: ts.InvalidatedProjectKind.Build,
			project: "/fake/project/tsconfig.json",
			done,
			getBuilderProgram: () => undefined,
		} as unknown as FakeProject;

		const result = await drainInvalidatedProject(project, createContext());

		expect(result).toEqual({ hadErrors: false, skipped: true });
		expect(done).toHaveBeenCalledOnce();
	});

	it("skips projects whose typeRoots lack the @rbxts scope", async () => {
		const done = vi.fn();
		const builderProgram = createBuilderProgram({
			typeRoots: ["/some/node_modules/@types"],
		});
		const project = {
			kind: ts.InvalidatedProjectKind.Build,
			project: "/fake/project/tsconfig.json",
			done,
			getBuilderProgram: () => builderProgram,
		} as unknown as FakeProject;

		const result = await drainInvalidatedProject(project, createContext());

		expect(result).toEqual({ hadErrors: false, skipped: true });
		expect(done).toHaveBeenCalledOnce();
	});

	it("skips projects with no typeRoots at all", async () => {
		const done = vi.fn();
		const builderProgram = createBuilderProgram({});
		const project = {
			kind: ts.InvalidatedProjectKind.Build,
			project: "/fake/project/tsconfig.json",
			done,
			getBuilderProgram: () => builderProgram,
		} as unknown as FakeProject;

		const result = await drainInvalidatedProject(project, createContext());

		expect(result).toEqual({ hadErrors: false, skipped: true });
		expect(done).toHaveBeenCalledOnce();
	});
});
