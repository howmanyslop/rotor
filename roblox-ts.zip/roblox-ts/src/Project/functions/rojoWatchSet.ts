import type { RojoResolver } from "@isentinel/rojo-utils";
import path from "path";
import type ts from "typescript";

export type WatchHostSubset = Pick<ts.WatchHost, "watchFile" | "watchDirectory">;

export interface RegisterRojoWatchersOptions {
	readonly host: WatchHostSubset;
	readonly resolver: RojoResolver;
	/**
	 * Fired when any watched file or directory associated with the resolver
	 * sees a change. Callers drop the cache entry + schedule the build drain
	 * here — registerRojoWatchers does not touch cache state itself so this
	 * module stays usable for any resolver scope (fromPath / synthetic).
	 */
	readonly onInvalidate: () => void;
}

function isProjectConfigFile(fsPath: string): boolean {
	return fsPath.endsWith(".project.json");
}

/**
 * Subscribes host watchers to every `.project.json` file the resolver walked
 * AND each directory the resolver listed (so a new nested rojo file appearing
 * inside a watched dir also triggers invalidation).
 *
 * Returns a dispose function: callers must invoke it when re-loading the
 * resolver so old watchers don't accumulate.
 */
export function registerRojoWatchers(options: RegisterRojoWatchersOptions): () => void {
	const { host, resolver, onInvalidate } = options;
	const fileWatchers = new Array<ts.FileWatcher>();
	const dirWatchers = new Array<ts.FileWatcher>();

	for (const configFile of resolver.walkedConfigFiles) {
		// pollingInterval omitted: ts.sys.watchFile picks an event-driven backend
		// when available, falls back to polling on the system default otherwise.
		const watcher = host.watchFile(configFile, () => {
			onInvalidate();
		});
		fileWatchers.push(watcher);
	}

	for (const directory of resolver.walkedDirectories) {
		// Recursive: a brand-new subdirectory that didn't exist at walk time
		// can hold a .project.json the resolver would pick up on the next
		// pass — non-recursive watching would miss the file-create event
		// because no watcher exists on the new subdir yet. The basename
		// filter below still keeps us off unrelated file events.
		const watcher = host.watchDirectory(
			directory,
			fsPath => {
				if (isProjectConfigFile(path.basename(fsPath))) {
					onInvalidate();
				}
			},
			true,
		);
		dirWatchers.push(watcher);
	}

	return () => {
		for (const w of fileWatchers) w.close();
		for (const w of dirWatchers) w.close();
		fileWatchers.length = 0;
		dirWatchers.length = 0;
	};
}
