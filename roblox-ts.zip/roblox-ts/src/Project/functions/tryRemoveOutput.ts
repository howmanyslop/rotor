import type { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";

import { LogService } from "../../Shared/classes/LogService.ts";
import { DTS_EXT } from "../../Shared/constants.ts";

const SOURCE_MAP_EXT = ".map";

// Files that compileFiles writes into outDir for its own use. They have no
// corresponding source input, so the orphan-reaper would always evict them.
const PROTECTED_OUTPUT_FILENAMES = new Set<string>([
	"rbxts.rojocache.json",
	"rbxts.typeroots.rojocache.json",
	"rbxts.copyfiles.json",
]);

function isOutputFileOrphaned(pathTranslator: PathTranslator, filePath: string): boolean {
	if (PROTECTED_OUTPUT_FILENAMES.has(path.basename(filePath))) {
		return false;
	}

	if (filePath.endsWith(DTS_EXT) && !pathTranslator.declaration) {
		return true;
	}

	if (filePath.endsWith(SOURCE_MAP_EXT)) {
		const sourcePath = filePath.slice(0, -SOURCE_MAP_EXT.length);
		return !fs.pathExistsSync(sourcePath) && isOutputFileOrphaned(pathTranslator, sourcePath);
	}

	for (const path of pathTranslator.getInputPaths(filePath)) {
		if (fs.pathExistsSync(path)) {
			return false;
		}
	}

	if (pathTranslator.buildInfoOutputPath === filePath) {
		return false;
	}

	return true;
}

export function tryRemoveOutput(pathTranslator: PathTranslator, outPath: string) {
	if (isOutputFileOrphaned(pathTranslator, outPath)) {
		fs.removeSync(outPath);
		LogService.writeLineIfVerbose(`remove ${outPath}`);
	}
}
