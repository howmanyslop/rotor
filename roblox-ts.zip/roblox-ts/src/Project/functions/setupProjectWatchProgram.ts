import type { PathTranslator } from "@roblox-ts/path-translator";
import type { ChokidarOptions } from "chokidar";
import chokidar from "chokidar";
import fs from "fs-extra";
import path from "path";
import ts from "typescript";

import { DTS_EXT } from "../../Shared/constants.ts";
import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
import { assert } from "../../Shared/util/assert.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { rojoResolverCache } from "../classes/RojoResolverCache.ts";
import type { ProjectData } from "../index.ts";
import { isCompilableFile } from "../util/isCompilableFile.ts";
import { walkDirectorySync } from "../util/walkDirectorySync.ts";
import { checkFileName } from "./checkFileName.ts";
import { cleanup } from "./cleanup.ts";
import { compileFiles } from "./compileFiles.ts";
import { createCompileGate } from "./compileGate.ts";
import { copyFiles } from "./copyFiles.ts";
import { copyInclude } from "./copyInclude.ts";
import { copyItem } from "./copyItem.ts";
import { createPathTranslator } from "./createPathTranslator.ts";
import { createProgramFactory } from "./createProgramFactory.ts";
import { getChangedSourceFiles } from "./getChangedSourceFiles.ts";
import { getParsedCommandLine } from "./getParsedCommandLine.ts";
import { tryRemoveOutput } from "./tryRemoveOutput.ts";

const CHOKIDAR_OPTIONS: ChokidarOptions = {
	awaitWriteFinish: {
		pollInterval: 10,
		stabilityThreshold: 50,
	},
	ignoreInitial: true,
};

function fixSlashes(fsPath: string) {
	return fsPath.replace(/\\/g, "/");
}

/**
 * Returns a promise that resolves to `true` when a watched tsconfig in the
 * extends chain changes (caller should reload project data and re-invoke).
 * The promise never resolves to `false` under normal operation — the caller
 * uses process signals to terminate.
 */
export function setupProjectWatchProgram(
	data: ProjectData,
	usePolling: boolean,
	tsConfigChain: Iterable<string> = [],
): Promise<boolean> {
	const { fileNames, options } = getParsedCommandLine(data);
	const fileNamesSet = new Set(fileNames);
	const tsConfigChainSet = new Set([...tsConfigChain].map(p => fixSlashes(path.resolve(p))));

	let initialCompileCompleted = false;
	let collecting = false;
	let filesToAdd = new Set<string>();
	let filesToChange = new Set<string>();
	let filesToDelete = new Set<string>();

	const watchReporter = ts.createWatchStatusReporter(ts.sys, true);
	const diagnosticReporter = ts.createDiagnosticReporter(ts.sys, true);

	function reportText(messageText: string) {
		watchReporter(
			{
				category: ts.DiagnosticCategory.Message,
				messageText,
				code: 0,
				file: undefined,
				length: undefined,
				start: undefined,
			},
			ts.sys.newLine,
			options,
		);
	}

	function reportEmitResult(emitResult: ts.EmitResult) {
		for (const diagnostic of emitResult.diagnostics) {
			diagnosticReporter(diagnostic);
		}
		const amtErrors = emitResult.diagnostics.filter(v => v.category === ts.DiagnosticCategory.Error).length;
		reportText(`Found ${amtErrors} error${amtErrors === 1 ? "" : "s"}. Watching for file changes.`);
	}

	let program: ts.EmitAndSemanticDiagnosticsBuilderProgram | undefined;
	let pathTranslator: PathTranslator | undefined;
	const createProgram = createProgramFactory(data, options);
	function refreshProgram() {
		program = createProgram([...fileNamesSet], options);
		pathTranslator = createPathTranslator(program, data);
	}

	async function runInitialCompile(): Promise<ts.EmitResult> {
		refreshProgram();
		assert(program && pathTranslator);
		cleanup(pathTranslator);
		copyInclude(data);
		copyFiles(data, pathTranslator, new Set(getRootDirs(options)));
		const sourceFiles = getChangedSourceFiles(program, getRootDirs(options));
		const emitResult = await compileFiles(program.getProgram(), data, pathTranslator, sourceFiles);
		if (!emitResult.emitSkipped) {
			initialCompileCompleted = true;
		}
		return emitResult;
	}

	const filesToCompile = new Set<string>();
	const filesToCopy = new Set<string>();
	const filesToClean = new Set<string>();
	async function runIncrementalCompile(
		additions: Set<string>,
		changes: Set<string>,
		removals: Set<string>,
	): Promise<ts.EmitResult> {
		for (const fsPath of additions) {
			if (fs.statSync(fsPath).isDirectory()) {
				walkDirectorySync(fsPath, item => {
					if (isCompilableFile(item)) {
						fileNamesSet.add(item);
						filesToCompile.add(item);
					}
				});
			} else if (isCompilableFile(fsPath)) {
				fileNamesSet.add(fsPath);
				filesToCompile.add(fsPath);
			} else {
				// checks for copying `init.*.d.ts`
				checkFileName(fsPath);
				filesToCopy.add(fsPath);
			}
		}

		for (const fsPath of changes) {
			if (isCompilableFile(fsPath)) {
				filesToCompile.add(fsPath);
			} else {
				// Transformers use a separate program that must be updated separately (which is done in compileFiles),
				// however certain files (such as d.ts files) aren't passed to that function and must be updated here.
				if (fsPath.endsWith(DTS_EXT)) {
					const transformerWatcher = data.transformerWatcher;
					if (transformerWatcher) {
						// Using ts.sys.readFile instead of fs.readFileSync here as it performs some utf conversions implicitly
						// and is also used by the program host to read files.
						const contents = ts.sys.readFile(fsPath);
						if (contents) {
							transformerWatcher.updateFile(fsPath, contents);
						}
					}
				}

				filesToCopy.add(fsPath);
			}
		}

		for (const fsPath of removals) {
			fileNamesSet.delete(fsPath);
			filesToClean.add(fsPath);
		}

		refreshProgram();
		assert(program && pathTranslator);
		const sourceFiles = getChangedSourceFiles(
			program,
			getRootDirs(options),
			options.incremental ? undefined : [...filesToCompile],
		);
		const emitResult = await compileFiles(program.getProgram(), data, pathTranslator, sourceFiles);
		if (emitResult.emitSkipped) {
			// exit before copying to prevent half-updated out directory
			return emitResult;
		}

		for (const fsPath of filesToClean) {
			tryRemoveOutput(pathTranslator, pathTranslator.getOutputPath(fsPath));
			if (options.declaration) {
				tryRemoveOutput(pathTranslator, pathTranslator.getOutputDeclarationPath(fsPath));
			}
		}
		for (const fsPath of filesToCopy) {
			copyItem(data, pathTranslator, fsPath);
		}

		filesToCompile.clear();
		filesToCopy.clear();
		filesToClean.clear();

		return emitResult;
	}

	async function runCompile(): Promise<ts.EmitResult> {
		if (!initialCompileCompleted) {
			return runInitialCompile();
		}
		const additions = filesToAdd;
		const changes = filesToChange;
		const removals = filesToDelete;
		filesToAdd = new Set();
		filesToChange = new Set();
		filesToDelete = new Set();
		return runIncrementalCompile(additions, changes, removals);
	}

	function reportWatchCompileFailure(error: unknown): void {
		// Synthesize a single-message diagnostic so the failure appears in
		// watch-mode output and CI/IDE log scrapers see it. Non-DiagnosticError
		// throws (e.g. an EACCES/ENOSPC from writeEmittedFiles) reach here.
		const messageText = `Watch compile failed: ${error instanceof Error ? error.message : String(error)}`;
		reportEmitResult({
			emitSkipped: true,
			diagnostics: [
				{
					category: ts.DiagnosticCategory.Error,
					messageText,
					code: 0,
					file: undefined,
					length: undefined,
					start: undefined,
				},
			],
		});
		// Drop the transformer watcher so a subsequent compile re-parses every
		// affected file. See plan §emitBuildInfo consistency: tsbuildinfo
		// stays un-advanced, but the in-memory transformer LanguageService can
		// still hold post-updateFile state for files whose writes never
		// completed. Re-creating it on the next compile is the cheapest
		// correctness insurance.
		data.transformerWatcher = undefined;
	}

	// Two error classes reach the gate's onFailure:
	//   1. DiagnosticError — structured TS compile diagnostics. Surface via
	//      the normal reporter so existing tooling (jest/CI/IDE) can parse
	//      the diagnostic array.
	//   2. Anything else — unexpected throw (write IO failure, transformer
	//      panic). Wrap as a synthetic diagnostic so the watcher doesn't die
	//      silently. Must NOT collapse case (1) into this path.
	const gate = createCompileGate({
		runCompile: async () => {
			const result = await runCompile();
			reportEmitResult(result);
		},
		onFailure: (error: unknown) => {
			if (error instanceof DiagnosticError) {
				reportEmitResult({
					emitSkipped: true,
					diagnostics: error.diagnostics,
				});
			} else {
				reportWatchCompileFailure(error);
			}
		},
	});

	function closeEventCollection() {
		collecting = false;
		gate.trigger();
	}

	function openEventCollection() {
		if (!collecting) {
			collecting = true;
			reportText("File change detected. Starting incremental compilation...");
			setTimeout(closeEventCollection, 100);
		}
	}

	function maybeInvalidateRojoCache(fsPath: string) {
		if (fsPath.endsWith(".project.json")) {
			// fromPath AND synthetic both depend on .project.json files. invalidateAll
			// alone leaves syntheticCache stale, so the next resolve hands back a
			// pre-edit resolver for any typeRoot pkg whose rojo file just changed.
			rojoResolverCache.invalidateAll();
			rojoResolverCache.invalidateAllSynthetic();
		}
	}

	function collectAddEvent(fsPath: string) {
		maybeInvalidateRojoCache(fsPath);
		filesToAdd.add(fixSlashes(fsPath));
		openEventCollection();
	}

	function collectChangeEvent(fsPath: string) {
		maybeInvalidateRojoCache(fsPath);
		filesToChange.add(fixSlashes(fsPath));
		openEventCollection();
	}

	function collectDeleteEvent(fsPath: string) {
		maybeInvalidateRojoCache(fsPath);
		filesToDelete.add(fixSlashes(fsPath));
		openEventCollection();
	}

	const chokidarOptions: ChokidarOptions = { ...CHOKIDAR_OPTIONS, usePolling };

	const watchPaths = [...getRootDirs(options)];
	if (data.rojoConfigPath) watchPaths.push(data.rojoConfigPath);
	for (const tsConfigPath of tsConfigChainSet) watchPaths.push(tsConfigPath);

	return new Promise<boolean>(resolve => {
		const watcher = chokidar.watch(watchPaths, chokidarOptions);

		function isTsConfigChange(fsPath: string): boolean {
			return tsConfigChainSet.has(fixSlashes(path.resolve(fsPath)));
		}

		async function handleTsConfigChange(fsPath: string) {
			reportText(`tsconfig change detected (${fsPath}) — reloading...`);
			await watcher.close();
			resolve(true);
		}

		watcher
			.on("add", fsPath => {
				if (isTsConfigChange(fsPath)) {
					void handleTsConfigChange(fsPath);
					return;
				}
				collectAddEvent(fsPath);
			})
			.on("addDir", collectAddEvent)
			.on("change", fsPath => {
				if (isTsConfigChange(fsPath)) {
					void handleTsConfigChange(fsPath);
					return;
				}
				collectChangeEvent(fsPath);
			})
			.on("unlink", fsPath => {
				if (isTsConfigChange(fsPath)) {
					void handleTsConfigChange(fsPath);
					return;
				}
				collectDeleteEvent(fsPath);
			})
			.on("unlinkDir", collectDeleteEvent)
			.once("ready", () => {
				reportText("Starting compilation in watch mode...");
				gate.trigger();
			});
	});
}
