import { originalPositionFor, TraceMap } from "@jridgewell/trace-mapping";
import fs from "fs-extra";
import path from "path";
import ts from "typescript";
import { afterEach, describe, expect, it } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { buildSolution } from "./buildSolution.ts";

const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/transformer-sourcemap");
const BUILD_TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.build.json");
const PROJECT_OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

function cleanOutput() {
	fs.removeSync(path.join(FIXTURE_DIR, "out"));
	fs.removeSync(path.join(FIXTURE_DIR, "tsconfig.rbxtsc.tsbuildinfo"));
}

function readMap(filePath: string) {
	return JSON.parse(fs.readFileSync(filePath, "utf-8"));
}

describe("sourcemaps with transformers", () => {
	afterEach(() => {
		cleanOutput();
	});

	it("compiles successfully with a transformer plugin", async () => {
		const result = await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});
		expect(result).toBe(ts.ExitStatus.Success);
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/init.luau"))).toBe(true);
		expect(fs.existsSync(path.join(FIXTURE_DIR, "out/init.luau.map"))).toBe(true);
	});

	it("sourcesContent matches the original file on disk, not the transformed text", async () => {
		await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});

		const mapPath = path.join(FIXTURE_DIR, "out/init.luau.map");
		const map = readMap(mapPath);
		const originalSource = fs.readFileSync(path.join(FIXTURE_DIR, "src/index.ts"), "utf-8");

		expect(map.sourcesContent).toBeInstanceOf(Array);
		expect(map.sourcesContent.length).toBe(1);
		expect(map.sourcesContent[0]).toBe(originalSource);
	});

	it("maps luau lines back to correct original TS lines despite transformer inserting code", async () => {
		await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});

		const luauPath = path.join(FIXTURE_DIR, "out/init.luau");
		const mapPath = path.join(FIXTURE_DIR, "out/init.luau.map");
		const luauLines = fs.readFileSync(luauPath, "utf-8").split("\n");
		const traced = new TraceMap(readMap(mapPath));

		// Find the luau line containing `Hello, {name}` (from `return \`Hello, ${name}!\``)
		const helloLine = luauLines.findIndex(l => l.includes("Hello, {name}")) + 1;
		expect(helloLine).toBeGreaterThan(0);

		const pos = originalPositionFor(traced, { line: helloLine, column: 0 });
		expect(pos.source).toBeTruthy();

		// In the original file, `return \`Hello, ${name}!\`` is on line 2.
		// The transformer inserts a statement, but the sourcemap should still point to original line 2.
		expect(pos.line).toBe(2);
	});

	it("maps function declaration to correct original line", async () => {
		await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});

		const luauPath = path.join(FIXTURE_DIR, "out/init.luau");
		const mapPath = path.join(FIXTURE_DIR, "out/init.luau.map");
		const luauLines = fs.readFileSync(luauPath, "utf-8").split("\n");
		const traced = new TraceMap(readMap(mapPath));

		// Find `function add(` in luau output
		const addLine = luauLines.findIndex(l => l.includes("function add(")) + 1;
		expect(addLine).toBeGreaterThan(0);

		const pos = originalPositionFor(traced, { line: addLine, column: 0 });
		expect(pos.source).toBeTruthy();
		// `export function add(...)` is on line 5 in the original
		expect(pos.line).toBe(5);
	});

	it("synthetic inserted statement does not map to an original source line", async () => {
		await buildSolution(BUILD_TSCONFIG, { ...PROJECT_OPTIONS }, {});

		const luauPath = path.join(FIXTURE_DIR, "out/init.luau");
		const mapPath = path.join(FIXTURE_DIR, "out/init.luau.map");
		const luauLines = fs.readFileSync(luauPath, "utf-8").split("\n");
		const traced = new TraceMap(readMap(mapPath));

		// The transformer injects `const __INJECTED__ = "transformer-was-here"`
		// which becomes something like `local __INJECTED__ = "transformer-was-here"` in luau
		const injectedLine = luauLines.findIndex(l => l.includes("__INJECTED__")) + 1;
		expect(injectedLine).toBeGreaterThan(0);

		const pos = originalPositionFor(traced, { line: injectedLine, column: 0 });
		// The TS printer falls back to the file start (line 1) for synthetic nodes.
		// The key invariant: it must NOT map to a meaningful line in the middle of the file.
		expect(pos.line).toBe(1);
		expect(pos.column).toBe(0);
	});
});
