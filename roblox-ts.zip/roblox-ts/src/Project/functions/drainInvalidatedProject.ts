import type { RojoResolver } from "@isentinel/rojo-utils";
import type { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";
import ts from "typescript";

import { LogService } from "../../Shared/classes/LogService.ts";
import { RBXTS_SCOPE } from "../../Shared/constants.ts";
import type { ProjectData, ProjectOptions } from "../../Shared/types.ts";
import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { hasErrors } from "../../Shared/util/hasErrors.ts";
import { profile, profileAsync } from "../../Shared/util/profile.ts";
import { rojoResolverCache } from "../classes/RojoResolverCache.ts";
import { loadCopyFilesGatePreBuild } from "../util/loadCopyFilesGatePreBuild.ts";
import { loadRojoCachesPreBuild } from "../util/loadRojoCachesPreBuild.ts";
import { runRbxtsEmit } from "../util/runRbxtsEmit.ts";
import { snapshotBuildState } from "../util/snapshotBuildState.ts";
import { cleanup } from "./cleanup.ts";
import { compileFiles } from "./compileFiles.ts";
import { copyFiles } from "./copyFiles.ts";
import { copyInclude } from "./copyInclude.ts";
import { createPathTranslator } from "./createPathTranslator.ts";
import { createProjectData } from "./createProjectData.ts";
import { getChangedSourceFiles } from "./getChangedSourceFiles.ts";
import { getTsConfigProjectOptions } from "./getTsConfigProjectOptions.ts";

export interface LoadedResolverInfo {
	readonly project: string;
	readonly kind: "fromPath" | "synthetic";
	readonly key: string;
	readonly resolver: RojoResolver;
}

export interface DrainContext {
	readonly projectOptions: ProjectOptions;
	readonly resolvedConfigPath: string;
	readonly isSolutionCoordinator: boolean;
	readonly importPathMap: Map<string, string>;
	readonly pendingRojoCachePersists: Array<() => void>;
	readonly pendingCopyFilesPersists: Array<() => void>;
	readonly diagnosticReporter: ts.DiagnosticReporter;
	/**
	 * Watch mode hook: fires BEFORE the project's pipeline runs (once the
	 * Build-kind / rbxts checks have passed). Watch mode uses this to drop
	 * stale resolver-watcher ownership so a project that's changing its
	 * rbxts.rojo / typeRoots can release its old scopes before the new
	 * ones are registered via onResolverLoaded.
	 */
	readonly onProjectDrainStart?: (project: string) => void;
	/**
	 * Watch mode hook: invoked after the per-project rojo caches resolve so
	 * the watcher can register file/dir watchers per resolver. Receives one
	 * call per loaded resolver (one fromPath if a rojo config is present,
	 * plus one synthetic per typeRoot basePath). Optional — undefined in
	 * batch mode.
	 */
	readonly onResolverLoaded?: (info: LoadedResolverInfo) => void;
	/**
	 * Watch mode hook: invoked once per drained project with the computed
	 * rootDirs. Asset watchers register against these dirs.
	 */
	readonly onProjectRootDirsResolved?: (project: string, rootDirs: ReadonlyArray<string>) => void;
	/**
	 * Watch mode hook: invoked once per drained project with the resolved
	 * ProjectData + PathTranslator. Watch mode stashes both so its async
	 * asset drain uses the SAME translator the build drain just used —
	 * not a re-derivation from entry projectOptions, which would ignore
	 * per-project rbxts.rojo / rbxts.type overrides.
	 */
	readonly onProjectArtifactsResolved?: (project: string, data: ProjectData, pathTranslator: PathTranslator) => void;
	/**
	 * Watch mode: tracks per-project ownership of importPathMap entries so
	 * a re-draining project's stale entries are dropped before the new
	 * map is populated. Without ownership tracking the first-write-wins
	 * guard below leaves the pre-rojo-edit import paths in place even
	 * after the owning project re-emits with a new mount.
	 */
	readonly importPathMapOwnership?: Map<string, Set<string>>;
}

export interface DrainOutcome {
	readonly hadErrors: boolean;
	readonly skipped: boolean;
}

function isRbxtsProject(compilerOptions: ts.CompilerOptions): boolean {
	return compilerOptions.typeRoots?.some(r => path.basename(path.normalize(r)) === RBXTS_SCOPE) ?? false;
}

export async function drainInvalidatedProject(
	project: ts.InvalidatedProject<ts.EmitAndSemanticDiagnosticsBuilderProgram>,
	ctx: DrainContext,
): Promise<DrainOutcome> {
	if (project.kind !== ts.InvalidatedProjectKind.Build) {
		project.done();
		return { hadErrors: false, skipped: true };
	}

	const projectTag = path.relative(process.cwd(), project.project) || project.project;
	const tag = (name: string) => `buildSolution[${projectTag}] ${name}`;

	const program = profile(tag("getBuilderProgram"), () => project.getBuilderProgram());
	if (!program) {
		project.done();
		return { hadErrors: false, skipped: true };
	}

	const compilerOptions = program.getCompilerOptions();

	if (!isRbxtsProject(compilerOptions)) {
		project.done();
		return { hadErrors: false, skipped: true };
	}

	// Broad try/finally so a throw anywhere downstream still settles the
	// project via done(). A narrower wrap around runRbxtsEmit alone would
	// leak the project on earlier failures (createProjectData, rojo cache
	// load, cleanup/copy, import-map build, etc.) — SolutionBuilder would
	// then re-attempt emit on the next builder.build() pass.
	ctx.onProjectDrainStart?.(project.project);

	const isEntryProject =
		!ctx.isSolutionCoordinator && getCanonicalFileName(path.normalize(project.project)) === ctx.resolvedConfigPath;
	let hadErrors = false;
	try {
		let opts: ProjectOptions;
		if (isEntryProject) {
			// CLI entry tsconfig — rbxts + CLI overrides already resolved upstream.
			opts = { ...ctx.projectOptions };
		} else {
			// Each referenced project may declare its own rbxts options (rojo, type, …)
			// via its tsconfig + extends chain. Presence of an rbxts block anywhere
			// in the chain (even empty) makes that project authoritative so a
			// solution can contain siblings with distinct Rojo projects. Without an
			// rbxts block we fall back to prior behavior: coordinators inherit CLI
			// flags, other referenced projects auto-detect.
			const perProjectRbxts = profile(tag("getTsConfigProjectOptions"), () =>
				getTsConfigProjectOptions(project.project),
			);
			if (perProjectRbxts !== undefined) {
				if (ctx.projectOptions.rojo !== undefined || ctx.projectOptions.type !== undefined) {
					LogService.writeLineIfVerbose(
						`rbxts: ignoring entry tsconfig/CLI rojo/type for referenced project ` +
							`${path.relative(process.cwd(), project.project)} — using its own rbxts block`,
					);
				}
				opts = { ...ctx.projectOptions, type: undefined, rojo: undefined, ...perProjectRbxts };
			} else if (ctx.isSolutionCoordinator) {
				opts = { ...ctx.projectOptions };
			} else {
				opts = { ...ctx.projectOptions, type: undefined, rojo: undefined };
			}
		}
		const data = profile(tag("createProjectData"), () => createProjectData(project.project, opts));
		const pathTranslator = profile(tag("createPathTranslator"), () => createPathTranslator(program, data));

		ctx.onProjectArtifactsResolved?.(project.project, data, pathTranslator);

		// Load rojo caches BEFORE cleanup/copyInclude/copyFiles — those phases
		// mutate dirs whose mtimes are in the cache manifest, which would
		// falsely invalidate the cache on the next run.
		const typeRoots = compilerOptions.typeRoots ?? [];
		const rojoCaches = profile(tag("loadRojoCaches"), () =>
			loadRojoCachesPreBuild(rojoResolverCache, {
				rojoConfigPath: data.rojoConfigPath,
				typeRoots,
				outDir: compilerOptions.outDir!,
				nodeModulesPath: data.nodeModulesPath,
			}),
		);

		if (ctx.onResolverLoaded !== undefined) {
			if (rojoCaches.rojoCacheEntry !== undefined && data.rojoConfigPath !== undefined) {
				ctx.onResolverLoaded({
					project: project.project,
					kind: "fromPath",
					key: data.rojoConfigPath,
					resolver: rojoCaches.rojoCacheEntry.resolver,
				});
			}
			const resolvers = rojoCaches.typeRootsEntry.resolvers;
			for (let i = 0; i < typeRoots.length; i++) {
				const key = typeRoots[i];
				const resolver = resolvers[i];
				// loadRojoCachesPreBuild guarantees parallel arrays today; the guard
				// turns a future divergence into a silent skip rather than an
				// `undefined`-as-key cache invalidation later.
				if (key === undefined || resolver === undefined) continue;
				ctx.onResolverLoaded({
					project: project.project,
					kind: "synthetic",
					key,
					resolver,
				});
			}
		}

		// Snapshot the program's changedFilesSet once; both the warm-noop gate
		// and any downstream consumer must see an identical view.
		const snapshot = profile(tag("snapshotBuildState"), () => snapshotBuildState(program));

		// Compute rootDirs once: `baseRootDirs` is what `getRootDirs` returns
		// (passed straight to consumers that normalize internally — copyFiles,
		// loadCopyFilesGate, getChangedSourceFiles). `rootDirs` adds
		// `path.normalize` + trailing `path.sep` for the buildImportPathMap
		// prefix check so sibling dirs (e.g. "/foo/barz" vs "/foo/bar") can't
		// false-positive on startsWith.
		const baseRootDirs = getRootDirs(compilerOptions);
		const rootDirs = baseRootDirs.map(d => path.normalize(d) + path.sep);

		ctx.onProjectRootDirsResolved?.(project.project, baseRootDirs);

		const copyFilesGate = profile(tag("loadCopyFilesGate"), () =>
			loadCopyFilesGatePreBuild({
				rootDirs: baseRootDirs,
				outDir: compilerOptions.outDir!,
				declaration: compilerOptions.declaration === true,
				pathTranslator,
				snapshot,
			}),
		);

		profile(tag("cleanup"), () => {
			if (copyFilesGate.skipCleanup) return;
			cleanup(pathTranslator);
		});
		profile(tag("copyInclude"), () => copyInclude(data));

		// Capture program/options BEFORE project.emit() — emit invalidates the builder program.
		const tsProgram = profile(tag("program.getProgram"), () => program.getProgram());

		// Populate cross-project import path map so other projects resolve
		// imports through this project's PathTranslator. Hand-authored Luau
		// modules use a .d.ts beside a .luau runtime that copyFiles emits into
		// this project's outDir, so include declaration files too — otherwise a
		// dependent project would fall back to its own pathTranslator and route
		// the import into the wrong outDir/Rojo mount. First write wins so the
		// project that owns the file (processed first via reference order)
		// retains the entry, even when a dependent project's program also sees
		// the file via project-reference redirect.
		//
		// Watch mode: drop stale entries this project owned BEFORE repopulating.
		// Without the drop, a rojo mount edit that forces this project to
		// re-emit would still resolve through the cached pre-edit importPath
		// (first-write-wins keeps the old value). Batch mode never re-drains
		// a project so ownership tracking is a no-op there.
		const projectOwnershipKey = getCanonicalFileName(path.normalize(project.project));
		if (ctx.importPathMapOwnership !== undefined) {
			const owned = ctx.importPathMapOwnership.get(projectOwnershipKey);
			if (owned !== undefined) {
				for (const canonical of owned) ctx.importPathMap.delete(canonical);
			}
			ctx.importPathMapOwnership.set(projectOwnershipKey, new Set());
		}

		profile(tag("buildImportPathMap"), () => {
			const owned = ctx.importPathMapOwnership?.get(projectOwnershipKey);
			for (const sf of tsProgram.getSourceFiles()) {
				if (ts.isJsonSourceFile(sf)) continue;
				const normalized = path.normalize(sf.fileName);
				if (!rootDirs.some(rd => normalized.startsWith(rd))) continue;

				const canonical = getCanonicalFileName(normalized);
				if (ctx.importPathMap.has(canonical)) continue;

				const importPath = pathTranslator.getImportPath(sf.fileName);
				ctx.importPathMap.set(canonical, importPath);
				owned?.add(canonical);

				if (compilerOptions.declaration && !sf.isDeclarationFile) {
					const dtsPath = pathTranslator.getOutputDeclarationPath(sf.fileName);
					const dtsCanonical = getCanonicalFileName(path.normalize(dtsPath));
					if (!ctx.importPathMap.has(dtsCanonical)) {
						ctx.importPathMap.set(dtsCanonical, importPath);
						owned?.add(dtsCanonical);
					}
				}
			}
		});

		profile(tag("copyFiles"), () => {
			if (copyFilesGate.skipCopyFiles) return;
			copyFiles(data, pathTranslator, new Set(baseRootDirs));
		});

		// Pass only changed + downstream-affected files to compileFiles. The
		// previous "all project-local files" filter forced a full Luau
		// re-transform on every invalidation — single-project mode
		// (build.ts) already uses this pattern, this just brings --build
		// into parity.
		//
		// pathHints come from the pre-emit snapshot of changedFilesSet
		// (TS marks all files changed on cold build, only dirty ones on
		// incremental). getChangedSourceFiles walks the reverseReferencedMap
		// from those hints to pick up within-project downstream importers
		// and filters out cross-project files via rootDirs.
		const sourceFiles = profile(tag("getChangedSourceFiles"), () =>
			getChangedSourceFiles(program, baseRootDirs, [...snapshot.changedFilePaths]),
		);

		// Emit .tsbuildinfo and capture .d.ts output via SolutionBuilder,
		// then flush declarations while compileFiles emits .luau. The
		// shared helper advances the BuilderProgram's incremental state,
		// dodges the Flamework dirty-environment guard via tsbuildinfo
		// round-trip, and gates tsbuildinfo restoration on emit success.
		//
		// project.emit is used in place of program.emit so SolutionBuilder
		// also advances past its internal BuildStep.Emit gate — otherwise
		// `done()` below would re-run emit and trample the .luau outputs.
		const { compileResult, preEmitDiagnostics, emittedSuccessfully } = await runRbxtsEmit({
			program,
			solutionEmit: writeFile => project.emit(undefined, writeFile),
			compileThunk: innerProgram =>
				profileAsync(tag("compileFiles"), () =>
					compileFiles(innerProgram, data, pathTranslator, sourceFiles, ctx.importPathMap),
				),
		});
		for (const diagnostic of preEmitDiagnostics) ctx.diagnosticReporter(diagnostic);
		for (const diagnostic of compileResult.diagnostics) ctx.diagnosticReporter(diagnostic);
		hadErrors = hasErrors(preEmitDiagnostics) || hasErrors(compileResult.diagnostics);

		// Defer cache persists to AFTER the entire solution loop completes —
		// otherwise subsequent projects' copyInclude can bump the shared
		// include/ mtime and invalidate the cache we just wrote.
		ctx.pendingRojoCachePersists.push(rojoCaches.persistAll);
		// Persist the copyFiles manifest ONLY when emit + compile succeeded
		// AND neither pre-emit nor compile reported errors. Mirrors the
		// single-project gate in build.ts and the tsbuildinfo rollback
		// above: a failed emit leaves partial outputs in outDir; recording
		// mtimes for those would mark the build "settled" and let the next
		// run skip cleanup/copyFiles over partial state.
		if (emittedSuccessfully && !hadErrors) {
			ctx.pendingCopyFilesPersists.push(copyFilesGate.persist);
		}
	} finally {
		// done() only runs QueueReferencingProjects now (emit step already done).
		profile(tag("project.done"), () => project.done());
	}

	return { hadErrors, skipped: false };
}
