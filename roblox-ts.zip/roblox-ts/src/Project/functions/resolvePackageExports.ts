import path from "path";

import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";

export interface PackageJsonWithExports {
	main?: string;
	types?: string;
	typings?: string;
	exports?: PackageExportsField;
}

type PackageExportsField = string | ExportsConditions | Array<ExportsConditions | string | null> | null;

interface ExportsConditions {
	[key: string]: PackageExportsField;
}

const RUNTIME_CONDITIONS = new Set(["node", "require", "import", "default"]);
const TYPES_CONDITIONS = new Set(["types"]);

function adjacentDts(filePath: string): string {
	const ext = path.extname(filePath);
	return filePath.slice(0, -ext.length) + ".d.ts";
}

interface ResolvedTargets {
	types?: string;
	runtime?: string;
	customTargets: Array<string>;
}

function resolveConditionObject(value: ExportsConditions, customConditions: ReadonlySet<string>): ResolvedTargets {
	const result: ResolvedTargets = { customTargets: [] };

	for (const key of Object.keys(value)) {
		const nested = value[key];

		if (TYPES_CONDITIONS.has(key)) {
			if (typeof nested === "string") result.types ??= nested;
		} else if (customConditions.has(key)) {
			if (typeof nested === "string") result.customTargets.push(nested);
		} else if (RUNTIME_CONDITIONS.has(key)) {
			if (typeof nested === "string") {
				result.runtime ??= nested;
			} else if (nested !== null && !Array.isArray(nested) && typeof nested === "object") {
				const inner = resolveConditionObject(nested, customConditions);
				result.types ??= inner.types;
				result.runtime ??= inner.runtime;
				result.customTargets.push(...inner.customTargets);
			}
		}
	}

	return result;
}

function resolveSubpath(
	pkgPath: string,
	pkgJson: PackageJsonWithExports,
	subpath: string,
	value: PackageExportsField,
	customConditions: ReadonlySet<string>,
	result: Map<string, string>,
) {
	if (value === null) return;

	let runtimeTarget: string | undefined;
	let typesTarget: string | undefined;
	const customTargets: Array<string> = [];

	if (typeof value === "string") {
		runtimeTarget = value;
	} else if (Array.isArray(value)) {
		for (const entry of value) {
			if (entry !== null) {
				if (typeof entry === "string") {
					runtimeTarget = entry;
					break;
				}
				if (typeof entry === "object") {
					const resolved = resolveConditionObject(entry, customConditions);
					typesTarget ??= resolved.types;
					runtimeTarget ??= resolved.runtime;
					customTargets.push(...resolved.customTargets);
					if (runtimeTarget !== undefined) break;
				}
			}
		}
	} else if (typeof value === "object") {
		const resolved = resolveConditionObject(value, customConditions);
		typesTarget = resolved.types;
		runtimeTarget = resolved.runtime;
		customTargets.push(...resolved.customTargets);
	}

	if (runtimeTarget === undefined) return;

	if (typesTarget === undefined) {
		if (subpath === ".") {
			const topLevel = pkgJson.types ?? pkgJson.typings;
			if (topLevel !== undefined) {
				typesTarget = topLevel;
			}
		}
		if (typesTarget === undefined) {
			typesTarget = adjacentDts(runtimeTarget);
		}
	}

	const resolvedRuntime = path.resolve(pkgPath, runtimeTarget);

	const canonicalTypes = getCanonicalFileName(path.resolve(pkgPath, typesTarget));
	result.set(canonicalTypes, resolvedRuntime);

	for (const customTarget of customTargets) {
		const canonicalCustom = getCanonicalFileName(path.resolve(pkgPath, customTarget));
		if (!result.has(canonicalCustom)) {
			result.set(canonicalCustom, resolvedRuntime);
		}
	}
}

/**
 * Resolves package.json `exports` field into a map of canonical types paths to runtime paths.
 * Returns an empty map if no `exports` field or nothing resolvable.
 */
export function resolvePackageExports(
	pkgPath: string,
	pkgJson: PackageJsonWithExports,
	customConditions?: ReadonlyArray<string>,
): Map<string, string> {
	const result = new Map<string, string>();
	const { exports: exportsField } = pkgJson;
	const customs = new Set(customConditions ?? []);

	if (exportsField === undefined || exportsField === null) return result;

	if (typeof exportsField === "string") {
		resolveSubpath(pkgPath, pkgJson, ".", exportsField, customs, result);
		return result;
	}

	if (Array.isArray(exportsField)) {
		resolveSubpath(pkgPath, pkgJson, ".", exportsField, customs, result);
		return result;
	}

	// Object — could be subpath map or conditions map
	const keys = Object.keys(exportsField);
	const isSubpathMap = keys.length > 0 && keys.every(k => k.startsWith("."));

	if (isSubpathMap) {
		for (const subpath of keys) {
			if (subpath.includes("*")) continue;
			resolveSubpath(pkgPath, pkgJson, subpath, exportsField[subpath], customs, result);
		}
	} else {
		// Top-level conditions (e.g. { "types": "...", "require": "..." })
		resolveSubpath(pkgPath, pkgJson, ".", exportsField, customs, result);
	}

	return result;
}
