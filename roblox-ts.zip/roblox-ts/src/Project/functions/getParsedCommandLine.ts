import inspector from "inspector";
import ts from "typescript";

import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
import { ProjectError } from "../../Shared/errors/ProjectError.ts";
import { applyRbxtscBuildInfoPath } from "../../Shared/util/rbxtscBuildInfo.ts";
import type { ProjectData } from "../index.ts";
import { validateCompilerOptions } from "./validateCompilerOptions.ts";

function createParseConfigFileHost(): ts.ParseConfigFileHost {
	return {
		fileExists: ts.sys.fileExists,
		getCurrentDirectory: ts.sys.getCurrentDirectory,
		onUnRecoverableConfigFileDiagnostic: d => {
			throw new DiagnosticError([d]);
		},
		readDirectory: ts.sys.readDirectory,
		readFile: ts.sys.readFile,
		useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
	};
}

export function getParsedCommandLine(data: ProjectData) {
	const parsedCommandLine = ts.getParsedCommandLineOfConfigFile(data.tsConfigPath, {}, createParseConfigFileHost());
	if (parsedCommandLine === undefined) {
		throw new ProjectError("Unable to load TS program!");
	} else if (parsedCommandLine.errors.length > 0) {
		throw new DiagnosticError(parsedCommandLine.errors);
	}

	if ((globalThis as unknown as { RBXTSC_DEV: boolean }).RBXTSC_DEV || inspector.url() !== undefined) {
		parsedCommandLine.options.incremental = false;
		parsedCommandLine.options.tsBuildInfoFile = undefined;
	}

	// Applied unconditionally. The dev/inspector guard above clears
	// `incremental`, but TS treats `composite` as an implicit incremental
	// signal (isIncrementalCompilation = incremental || composite), so a
	// composite project still gets a default-computed tsbuildinfo path and
	// TS still writes it. The suffix has to land on that path too — otherwise
	// dev-mode composite builds would re-introduce the tsgo collision this
	// transform exists to prevent.
	applyRbxtscBuildInfoPath(parsedCommandLine.options);

	validateCompilerOptions(parsedCommandLine.options, data.projectPath);
	return parsedCommandLine;
}
