import { originalPositionFor } from "@jridgewell/trace-mapping";
import ts from "typescript";
import { describe, expect, it } from "vitest";

import { printSourceFileWithTraceMap } from "./printSourceFileWithTraceMap.ts";

function createSourceFile(text: string, fileName = "test.ts") {
	return ts.createSourceFile(fileName, text, ts.ScriptTarget.Latest, true);
}

function insertStatementAtTop(sourceFile: ts.SourceFile, statementText: string): ts.SourceFile {
	const insertedStmt = ts.factory.createExpressionStatement(ts.factory.createIdentifier(statementText));
	const newStatements = ts.factory.createNodeArray([insertedStmt, ...sourceFile.statements]);
	return ts.factory.updateSourceFile(sourceFile, newStatements);
}

describe("printSourceFileWithTraceMap", () => {
	it("returns printed text matching ts.createPrinter().printFile()", () => {
		const source = createSourceFile("const x = 1;\nconst y = 2;\n");
		const result = printSourceFileWithTraceMap(source, { sourceMap: true } as ts.CompilerOptions);

		const expected = ts.createPrinter().printFile(source);
		expect(result.text).toBe(expected);
	});

	it("returns a traceMap when sourceMap is enabled", () => {
		const source = createSourceFile("const x = 1;\n");
		const result = printSourceFileWithTraceMap(source, { sourceMap: true } as ts.CompilerOptions);

		expect(result.traceMap).toBeDefined();
	});

	it("returns undefined traceMap when sourceMap is disabled", () => {
		const source = createSourceFile("const x = 1;\n");
		const result = printSourceFileWithTraceMap(source, { sourceMap: false } as ts.CompilerOptions);

		expect(result.traceMap).toBeUndefined();
	});

	it("maps preserved statements to original lines when a statement is inserted at the top", () => {
		const original = createSourceFile("const x = 1;\nconst y = 2;\n");
		const transformed = insertStatementAtTop(original, "INJECTED");
		const result = printSourceFileWithTraceMap(transformed, { sourceMap: true } as ts.CompilerOptions);

		expect(result.text).toContain("INJECTED");
		expect(result.traceMap).toBeDefined();

		// "const x = 1" was on line 1 in original, now on line 2 in printed output
		// The trace map should map printed line 2 back to original line 1
		const pos = originalPositionFor(result.traceMap!, { line: 2, column: 0 });
		expect(pos.line).toBe(1);
	});

	it("maps preserved statements correctly when multiple statements are inserted", () => {
		const original = createSourceFile("const a = 1;\nconst b = 2;\nconst c = 3;\n");
		const inserted1 = ts.factory.createExpressionStatement(ts.factory.createIdentifier("FIRST"));
		const inserted2 = ts.factory.createExpressionStatement(ts.factory.createIdentifier("SECOND"));
		const newStatements = ts.factory.createNodeArray([inserted1, inserted2, ...original.statements]);
		const transformed = ts.factory.updateSourceFile(original, newStatements);

		const result = printSourceFileWithTraceMap(transformed, { sourceMap: true } as ts.CompilerOptions);

		expect(result.traceMap).toBeDefined();

		// "const a = 1" was line 1 originally, now at line 3 in printed output
		const posA = originalPositionFor(result.traceMap!, { line: 3, column: 0 });
		expect(posA.line).toBe(1);

		// "const b = 2" was line 2 originally, now at line 4
		const posB = originalPositionFor(result.traceMap!, { line: 4, column: 0 });
		expect(posB.line).toBe(2);
	});

	it("synthetic inserted statements do not map to original source lines", () => {
		const original = createSourceFile("const x = 1;\n");
		const transformed = insertStatementAtTop(original, "SYNTHETIC");
		const result = printSourceFileWithTraceMap(transformed, { sourceMap: true } as ts.CompilerOptions);

		// Line 1 is the synthetic statement - should have no original mapping
		const pos = originalPositionFor(result.traceMap!, { line: 1, column: 0 });
		expect(pos.source).toBeNull();
	});

	it("handles an empty source file", () => {
		const source = createSourceFile("");
		const result = printSourceFileWithTraceMap(source, { sourceMap: true } as ts.CompilerOptions);

		expect(result.text).toBeDefined();
		expect(result.traceMap).toBeDefined();
	});
});
