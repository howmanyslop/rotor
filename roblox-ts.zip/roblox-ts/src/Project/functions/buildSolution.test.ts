import { eachMapping, originalPositionFor, TraceMap } from "@jridgewell/trace-mapping";
import nodeFs from "fs";
import fs from "fs-extra";
import path from "path";
import ts from "typescript";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { buildSolution } from "./buildSolution.ts";

const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/build-mode");
const ROOT_TSCONFIG = path.join(FIXTURE_DIR, "tsconfig.json");
const GAME_TSCONFIG = path.join(FIXTURE_DIR, "game/tsconfig.json");
const GAME_ROJO = path.join(FIXTURE_DIR, "game/game.project.json");
const LUA_OPTIONS = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Package };

const PER_PROJECT_ROJO_FIXTURE = path.resolve(__dirname, "../../..", "tests/per-project-rojo");
const PER_PROJECT_ROOT_TSCONFIG = path.join(PER_PROJECT_ROJO_FIXTURE, "tsconfig.json");
const PER_PROJECT_PKG_DIR = path.join(PER_PROJECT_ROJO_FIXTURE, "custom-pkg");

const REF_PATHS_FIXTURE = path.resolve(__dirname, "../../..", "tests/project-ref-paths");
const REF_PATHS_TSCONFIG = path.join(REF_PATHS_FIXTURE, "tsconfig.json");
const REF_PATHS_ROJO = path.join(REF_PATHS_FIXTURE, "game.project.json");

const CROSS_DTS_FIXTURE = path.resolve(__dirname, "../../..", "tests/cross-project-dts");
const CROSS_DTS_ROOT_TSCONFIG = path.join(CROSS_DTS_FIXTURE, "tsconfig.json");
const CROSS_DTS_LIB_DIR = path.join(CROSS_DTS_FIXTURE, "lib");
const CROSS_DTS_GAME_DIR = path.join(CROSS_DTS_FIXTURE, "game");
const CROSS_DTS_LIB_TSCONFIG = path.join(CROSS_DTS_LIB_DIR, "tsconfig.json");
const CROSS_DTS_GAME_TSCONFIG = path.join(CROSS_DTS_GAME_DIR, "tsconfig.json");

function cleanPerProjectOutput() {
	fs.removeSync(path.join(PER_PROJECT_PKG_DIR, "out"));
	fs.removeSync(path.join(PER_PROJECT_PKG_DIR, "include"));
	fs.removeSync(path.join(PER_PROJECT_PKG_DIR, "tsconfig.rbxtsc.tsbuildinfo"));
}

function cleanCrossDtsOutput() {
	for (const sub of [CROSS_DTS_LIB_DIR, CROSS_DTS_GAME_DIR]) {
		fs.removeSync(path.join(sub, "out"));
		fs.removeSync(path.join(sub, "include"));
		fs.removeSync(path.join(sub, "tsconfig.rbxtsc.tsbuildinfo"));
	}
}

function cleanRefPathsOutput() {
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "out"));
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "out-packages"));
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "include"));
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "tsconfig.rbxtsc.tsbuildinfo"));
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "packages/include"));
	fs.removeSync(path.join(REF_PATHS_FIXTURE, "packages/tsconfig.rbxtsc.tsbuildinfo"));
}

function cleanFixtureOutput() {
	for (const sub of ["shared", "game"]) {
		fs.removeSync(path.join(FIXTURE_DIR, sub, "out"));
		fs.removeSync(path.join(FIXTURE_DIR, sub, "include"));
		fs.removeSync(path.join(FIXTURE_DIR, sub, "tsconfig.rbxtsc.tsbuildinfo"));
	}
}

describe("buildSolution", () => {
	afterEach(() => {
		cleanFixtureOutput();
	});

	describe("lua emit", () => {
		it("emits .luau files for all referenced projects", async () => {
			const result = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(result).toBe(ts.ExitStatus.Success);
			// roblox-ts renames index → init (Roblox convention)
			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/init.luau"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/init.luau"))).toBe(true);
		});

		it("also emits .d.ts files alongside .luau", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/index.d.ts"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/index.d.ts"))).toBe(true);
		});

		it("does not emit .js files", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/index.js"))).toBe(false);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/index.js"))).toBe(false);
		});

		it("emits .d.ts with correct re-export declarations", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const sharedDts = fs.readFileSync(path.join(FIXTURE_DIR, "shared/out/index.d.ts"), "utf-8");
			expect(sharedDts).toContain("helper");
		});

		it("skips rebuild when up to date", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const result = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(result).toBe(ts.ExitStatus.Success);
		});

		it("does not recompile referenced project files during dependent build", async () => {
			// Build everything first
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const sharedLuau = path.join(FIXTURE_DIR, "shared/out/init.luau");
			const mtimeBefore = fs.statSync(sharedLuau).mtimeMs;

			// Wait briefly so mtime would differ if file is rewritten
			const start = Date.now();
			while (Date.now() - start < 50) {
				/* spin */
			}

			// Touch game source to force game-only rebuild, shared stays up-to-date
			const gameSrc = path.join(FIXTURE_DIR, "game/src/index.ts");
			const original = fs.readFileSync(gameSrc, "utf-8");
			fs.writeFileSync(gameSrc, original + "\n");

			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});
			fs.writeFileSync(gameSrc, original); // restore

			const mtimeAfter = fs.statSync(sharedLuau).mtimeMs;
			// shared's output should NOT have been rewritten
			expect(mtimeAfter).toBe(mtimeBefore);
		});

		it("does not recompile unaffected within-project files on incremental rebuild", async () => {
			// Cold build seeds both shared/out/init.luau (from index.ts) and
			// shared/out/helper.luau (from helper.ts).
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			// Stamp helper.luau with a known old mtime so any rewrite below
			// will move it. Sidesteps platform-dependent mtime resolution +
			// the same-tick problem (where two writes within one mtime quantum
			// would look identical).
			const helperLuau = path.join(FIXTURE_DIR, "shared/out/helper.luau");
			const sentinelMtime = new Date(2020, 0, 1);
			fs.utimesSync(helperLuau, sentinelMtime, sentinelMtime);

			// Modify shared/src/index.ts (which imports helper.ts but is not
			// imported by helper.ts). The reverseReferencedMap walk from
			// index.ts has no within-project hops, so the affected set is
			// {index.ts} only — helper.ts must stay out of the per-file Luau
			// transform pass.
			const indexSrc = path.join(FIXTURE_DIR, "shared/src/index.ts");
			const original = fs.readFileSync(indexSrc, "utf-8");
			fs.writeFileSync(indexSrc, `${original}\n// incremental-marker\n`);

			try {
				await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

				expect(fs.statSync(helperLuau).mtimeMs).toBe(sentinelMtime.getTime());
			} finally {
				fs.writeFileSync(indexSrc, original);
			}
		});
	});

	describe("sourcemaps", () => {
		function readMap(filePath: string) {
			return JSON.parse(fs.readFileSync(filePath, "utf-8"));
		}

		function getMappedLines(mapPath: string): Array<number> {
			const traced = new TraceMap(readMap(mapPath));
			const lines: Array<number> = [];
			eachMapping(traced, m => lines.push(m.generatedLine));
			return lines;
		}

		function countNonEmptyLines(luauPath: string): number {
			return fs
				.readFileSync(luauPath, "utf-8")
				.split("\n")
				.filter(l => l.trim() !== "").length;
		}

		it("emits .luau.map files alongside .luau files", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/init.luau.map"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/helper.luau.map"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/init.luau.map"))).toBe(true);
		});

		it("produces valid V3 sourcemaps", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const map = readMap(path.join(FIXTURE_DIR, "shared/out/helper.luau.map"));

			expect(map.version).toBe(3);
			expect(map.file).toBe("helper.luau");
			expect(map.sources).toBeInstanceOf(Array);
			expect(map.sources.length).toBeGreaterThan(0);
			expect(map.mappings).toBeTruthy();
		});

		it("sourcemap sources reference the original .ts file", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const map = readMap(path.join(FIXTURE_DIR, "shared/out/helper.luau.map"));
			expect(map.sources.some((s: string) => s.includes("helper.ts"))).toBe(true);
		});

		it("maps all luau lines back to valid source positions", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const mapPath = path.join(FIXTURE_DIR, "shared/out/init.luau.map");
			const traced = new TraceMap(readMap(mapPath));
			const mappedLines = getMappedLines(mapPath);

			for (const line of mappedLines) {
				const pos = originalPositionFor(traced, { line, column: 0 });
				expect(pos.source, `line ${line} should have a source`).toBeTruthy();
				expect(pos.line, `line ${line} should map to a valid source line`).toBeGreaterThanOrEqual(1);
			}
		});

		it("maps most generated lines, not just top-level statements", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const luauPath = path.join(FIXTURE_DIR, "shared/out/init.luau");
			const mapPath = path.join(FIXTURE_DIR, "shared/out/init.luau.map");

			const totalLines = countNonEmptyLines(luauPath);
			const mappedCount = getMappedLines(mapPath).length;
			const coverage = mappedCount / totalLines;

			// init.luau has ~9 non-empty lines; boilerplate (comment, TS runtime,
			// `local exports = {}`, `end`, `return exports`) won't be mapped.
			// At least 40% of lines should have mappings.
			expect(coverage).toBeGreaterThanOrEqual(0.4);
		});

		it("maps export assignments to their source declaration", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const luauPath = path.join(FIXTURE_DIR, "shared/out/init.luau");
			const mapPath = path.join(FIXTURE_DIR, "shared/out/init.luau.map");
			const traced = new TraceMap(readMap(mapPath));

			const lines = fs.readFileSync(luauPath, "utf-8").split("\n");
			const exportLine = lines.findIndex(l => l.includes("exports.greet = greet")) + 1;
			expect(exportLine).toBeGreaterThan(0);

			const pos = originalPositionFor(traced, { line: exportLine, column: 0 });
			expect(pos.source, "export assignment should map to source").toBeTruthy();
		});

		it("includes original TypeScript source in sourcesContent", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const mapPath = path.join(FIXTURE_DIR, "shared/out/helper.luau.map");
			const map = readMap(mapPath);
			const helperSource = fs.readFileSync(path.join(FIXTURE_DIR, "shared/src/helper.ts"), "utf-8");

			expect(map.sourcesContent).toBeInstanceOf(Array);
			expect(map.sourcesContent.length).toBe(1);
			expect(map.sourcesContent[0]).toBe(helperSource);
		});

		it("maps function body statements to their source lines", async () => {
			await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			const luauPath = path.join(FIXTURE_DIR, "shared/out/init.luau");
			const mapPath = path.join(FIXTURE_DIR, "shared/out/init.luau.map");
			const traced = new TraceMap(readMap(mapPath));

			const lines = fs.readFileSync(luauPath, "utf-8").split("\n");
			const returnLine = lines.findIndex(l => l.includes("Hello, {name}")) + 1;
			expect(returnLine).toBeGreaterThan(0);

			const pos = originalPositionFor(traced, { line: returnLine, column: 0 });
			expect(pos.source, "function body statement should map to source").toBeTruthy();
		});
	});

	describe("project type inference", () => {
		it("root project preserves CLI type while referenced projects infer", async () => {
			const gameOptions = {
				...DEFAULT_PROJECT_OPTIONS,
				type: ProjectType.Game,
				rojo: GAME_ROJO,
			};

			const result = await buildSolution(GAME_TSCONFIG, gameOptions, {});

			expect(result).toBe(ts.ExitStatus.Success);

			// Root (game) should compile as Game — uses game:GetService for imports
			const gameLuau = fs.readFileSync(path.join(FIXTURE_DIR, "game/out/init.luau"), "utf-8");
			expect(gameLuau).toContain("game:GetService");

			// Referenced (shared) should infer as Package — uses _G[script]
			const sharedLuau = fs.readFileSync(path.join(FIXTURE_DIR, "shared/out/init.luau"), "utf-8");
			expect(sharedLuau).toContain("_G[script]");
			expect(sharedLuau).not.toContain("game:GetService");
		});
	});

	describe("--emitDeclarationOnly", () => {
		it("emits .d.ts files for all referenced projects", async () => {
			const result = await buildSolution(
				ROOT_TSCONFIG,
				{ ...DEFAULT_PROJECT_OPTIONS },
				{
					emitDeclarationOnly: true,
				},
			);

			expect(result).toBe(ts.ExitStatus.Success);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/index.d.ts"))).toBe(true);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/index.d.ts"))).toBe(true);
		});

		it("skips rebuild when up to date", async () => {
			await buildSolution(
				ROOT_TSCONFIG,
				{ ...DEFAULT_PROJECT_OPTIONS },
				{
					emitDeclarationOnly: true,
				},
			);

			const result = await buildSolution(
				ROOT_TSCONFIG,
				{ ...DEFAULT_PROJECT_OPTIONS },
				{
					emitDeclarationOnly: true,
				},
			);

			expect(result).toBe(ts.ExitStatus.Success);
		});

		it("does not emit .js files", async () => {
			await buildSolution(
				ROOT_TSCONFIG,
				{ ...DEFAULT_PROJECT_OPTIONS },
				{
					emitDeclarationOnly: true,
				},
			);

			expect(fs.existsSync(path.join(FIXTURE_DIR, "shared/out/index.js"))).toBe(false);
			expect(fs.existsSync(path.join(FIXTURE_DIR, "game/out/index.js"))).toBe(false);
		});
	});

	describe("per-project rbxts.rojo", () => {
		beforeEach(() => {
			// Force a fresh build — stale out/ or tsbuildinfo from a prior run would
			// let SolutionBuilder skip the project and mask regressions in rbxts.rojo
			// resolution.
			cleanPerProjectOutput();
		});

		afterEach(() => {
			cleanPerProjectOutput();
		});

		it("honors each referenced project's rbxts.rojo during solution build", async () => {
			// custom-pkg/default.project.json maps to a nonexistent folder; without
			// per-project resolution, RojoResolver would auto-detect and pick that
			// file (since default.project.json wins), breaking the emit. The tsconfig
			// declares rbxts.rojo: "./custom.project.json" which maps src → out
			// correctly, so the build should use that file and succeed.
			const result = await buildSolution(PER_PROJECT_ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(result).toBe(ts.ExitStatus.Success);
			expect(fs.existsSync(path.join(PER_PROJECT_PKG_DIR, "out/init.luau"))).toBe(true);
		});
	});

	describe("cross-project import resolution", () => {
		// Two composite projects with different outDirs (lib → lib/out, game → game/out).
		// game.project.json mounts BOTH outDirs under distinct Rojo paths. game's
		// index.ts imports two siblings from lib: a regular .ts module (regular.ts)
		// and a hand-authored Luau module declared as .d.ts (handauth/index.d.ts
		// + handauth/init.luau). Both imports must compile to TS.import calls that
		// reach lib's mount, not game's.
		beforeEach(() => {
			cleanCrossDtsOutput();
		});

		afterEach(() => {
			cleanCrossDtsOutput();
		});

		it("routes both .ts and .d.ts cross-project imports through the owning project's outDir", async () => {
			// LUA_OPTIONS sets type: Package as the CLI default; lib inherits this
			// (no rbxts block) and so is treated as a package (no Rojo required).
			// game has its own rbxts block declaring type: game + its game.project.json,
			// so it overrides the package default and is type-checked as a game.
			const result = await buildSolution(CROSS_DTS_ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

			expect(result).toBe(ts.ExitStatus.Success);

			const gameIndex = fs.readFileSync(path.join(CROSS_DTS_GAME_DIR, "out/init.luau"), "utf-8");

			// Regular .ts source from lib: must resolve through lib's outDir (Rojo
			// mount "shared"), not game's outDir (mount "game"). Pre-fix this worked
			// because lib's importPathMap entry covered .ts files.
			expect(gameIndex).toContain('"shared", "regular")');

			// Hand-authored Luau module imported via its .d.ts: pre-fix this fell
			// back to game's PathTranslator → wrong mount. The fix includes .d.ts
			// files in the cross-project importPathMap so handauth resolves to
			// lib's outDir (mount "shared") just like regular.ts.
			expect(gameIndex).toContain('"shared", "handauth")');
			expect(gameIndex).not.toContain('"game", "handauth")');
		});

		it("routes cross-project imports correctly when the referenced project is up-to-date", async () => {
			// Reproduces the two-stage build the Anime Rush spec compile triggers:
			// first build lib in isolation (writes tsbuildinfo), then build the
			// dependent project in isolation. The second invocation sees lib as
			// up-to-date, so SolutionBuilder never invalidates it and
			// drainInvalidatedProject is never called for lib — leaving every
			// lib source file out of the cross-project importPathMap. Imports
			// from the dependent into lib then fall through to the dependent's
			// own PathTranslator (wrong outDir) and pick the wrong Rojo mount.
			const libResult = await buildSolution(CROSS_DTS_LIB_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(libResult).toBe(ts.ExitStatus.Success);

			const gameResult = await buildSolution(CROSS_DTS_GAME_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(gameResult).toBe(ts.ExitStatus.Success);

			const gameIndex = fs.readFileSync(path.join(CROSS_DTS_GAME_DIR, "out/init.luau"), "utf-8");

			expect(gameIndex).toContain('"shared", "regular")');
			expect(gameIndex).toContain('"shared", "handauth")');
			expect(gameIndex).not.toContain('"game", "regular")');
			expect(gameIndex).not.toContain('"game", "handauth")');
		});
	});

	describe("project reference declaration redirect", () => {
		// Mirrors the Anime Rush staged-monorepo shape: the entry project
		// (rootDir "src") references a packages project (rootDir ".", outDir
		// "../out-packages") and imports it through a tsconfig `paths` alias
		// that points at the referenced project's SOURCE .ts file. Stock tsc
		// redirects that resolution to the referenced project's emitted .d.ts;
		// without the redirect the source file lands in the entry program and
		// its rootDir check rejects it with TS6059.
		//
		// packages/package.json is load-bearing: its scoped name makes
		// createProjectData classify the referenced project as a Package, so
		// it compiles without its own Rojo config.
		beforeEach(() => {
			cleanRefPathsOutput();
		});

		afterEach(() => {
			cleanRefPathsOutput();
		});

		it("builds a paths alias into referenced project source and routes the require to the owning project", async () => {
			const options = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Game, rojo: REF_PATHS_ROJO };

			const result = await buildSolution(REF_PATHS_TSCONFIG, options, {});

			expect(result).toBe(ts.ExitStatus.Success);

			const entryLuau = fs.readFileSync(path.join(REF_PATHS_FIXTURE, "out/init.luau"), "utf-8");
			// The import must route through the packages project's Rojo mount
			// ("packages" → out-packages), not the entry project's own outDir.
			expect(entryLuau).toContain('"packages", "errors"');
			expect(entryLuau).not.toContain('"game", "errors"');
		});

		it("redirects when the referenced project is already up to date", async () => {
			// The motivating failure hit this exact shape: packages had a fresh
			// tsbuildinfo (skipped by SolutionBuilder), only the entry project
			// rebuilt, and the transformer language-service program rejected the
			// aliased source with TS6059.
			// No `type` override on purpose: Package classification comes from
			// packages/package.json's scoped name via createProjectData, not
			// from the options object.
			const packagesResult = await buildSolution(
				path.join(REF_PATHS_FIXTURE, "packages/tsconfig.json"),
				{ ...DEFAULT_PROJECT_OPTIONS },
				{},
			);
			expect(packagesResult).toBe(ts.ExitStatus.Success);

			const options = { ...DEFAULT_PROJECT_OPTIONS, type: ProjectType.Game, rojo: REF_PATHS_ROJO };
			const result = await buildSolution(REF_PATHS_TSCONFIG, options, {});

			expect(result).toBe(ts.ExitStatus.Success);

			const entryLuau = fs.readFileSync(path.join(REF_PATHS_FIXTURE, "out/init.luau"), "utf-8");
			expect(entryLuau).toContain('"packages", "errors"');
			expect(entryLuau).not.toContain('"game", "errors"');
		});
	});

	describe("tsbuildinfo recovery on emit failure", () => {
		const SHARED_TSBUILDINFO = path.join(FIXTURE_DIR, "shared", "tsconfig.rbxtsc.tsbuildinfo");
		const SHARED_OUT = path.join(FIXTURE_DIR, "shared", "out");
		const GAME_OUT = path.join(FIXTURE_DIR, "game", "out");

		afterEach(() => {
			vi.restoreAllMocks();
		});

		it("preserves tsbuildinfo on successful build and skips emit on no-change rebuild", async () => {
			const result1 = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(result1).toBe(ts.ExitStatus.Success);
			expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(true);
			expect(fs.existsSync(path.join(SHARED_OUT, "init.luau"))).toBe(true);

			// No-change rebuild: SolutionBuilder should see tsbuildinfo as up-to-date
			// and skip the compileFiles path entirely. Spy on fs.promises.writeFile
			// to prove no .luau writes happen on the second build (mtime equality
			// would be flaky on coarse-resolution filesystems within the same
			// tick). The async write phase routes through fs.promises.
			const writeSpy = vi.spyOn(fs.promises, "writeFile");
			const result2 = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(result2).toBe(ts.ExitStatus.Success);
			const luauWrites = writeSpy.mock.calls.filter(
				([p]) => typeof p === "string" && (p as string).endsWith(".luau"),
			);
			expect(luauWrites).toEqual([]);
		});

		it("deletes tsbuildinfo when compileFiles throws so next --build re-runs emit", async () => {
			// Setup: no prior tsbuildinfo (afterEach already cleaned the fixture).
			expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(false);

			// Simulate a disk-full / EACCES mid-emit failure on the very first build.
			// The write helper routes through fs.promises.writeFile on large
			// queues and fs.writeFileSync on small ones (sync cutoff); the
			// fixture has only 2 source files so we cover both.
			vi.spyOn(fs.promises, "writeFile").mockImplementation((async (p: string) => {
				if (typeof p === "string" && p.endsWith(".luau")) {
					throw new Error("synthetic write failure mid-emit");
				}
				return undefined;
			}) as never);
			vi.spyOn(nodeFs, "writeFileSync").mockImplementation(((p: string) => {
				if (typeof p === "string" && p.endsWith(".luau")) {
					throw new Error("synthetic write failure mid-emit");
				}
				return undefined;
			}) as never);

			await expect(buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {})).rejects.toThrow(
				/synthetic write failure/,
			);

			// With no prior tsbuildinfo to recover, the post-failure state must leave
			// tsbuildinfo absent. The pre-fix code restored the newly-emitted one,
			// causing the next --build to skip compileFiles and leave Luau missing.
			expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(false);

			vi.restoreAllMocks();

			// Next rebuild MUST re-run emit and produce Luau.
			const result2 = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(result2).toBe(ts.ExitStatus.Success);
			expect(fs.existsSync(path.join(SHARED_OUT, "init.luau"))).toBe(true);
		});

		it("deletes tsbuildinfo when compileFiles returns emitSkipped:true", async () => {
			// Setup: no prior tsbuildinfo (afterEach already cleaned the fixture).
			expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(false);

			// Drop an init.ts into shared/src — the rbxts FILENAME_WARNINGS set lists
			// `init.ts` as an incorrect name (use `index.ts`). checkFileName adds an
			// error diagnostic, compileFiles short-circuits with emitSkipped:true.
			const sharedSrc = path.join(FIXTURE_DIR, "shared", "src");
			const badPath = path.join(sharedSrc, "init.ts");
			fs.writeFileSync(badPath, "export const x = 1;\n");

			try {
				const result = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});

				// The bad filename should surface a diagnostic.
				expect(result).toBe(ts.ExitStatus.DiagnosticsPresent_OutputsGenerated);
				// And shared's Luau should NOT be present (emitSkipped:true).
				expect(fs.existsSync(path.join(SHARED_OUT, "init.luau"))).toBe(false);
				// Pre-fix: emitSkipped:true still restored the new tsbuildinfo. The
				// fix gates restore on !compileResult.emitSkipped.
				expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(false);
			} finally {
				fs.removeSync(badPath);
			}
		});
		it("restores prior tsbuildinfo content on failure when one existed before the build", async () => {
			// Baseline: produce a real, successful tsbuildinfo snapshot.
			const result1 = await buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {});
			expect(result1).toBe(ts.ExitStatus.Success);
			expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(true);

			const priorContent = fs.readFileSync(SHARED_TSBUILDINFO, "utf-8");
			expect(priorContent.length).toBeGreaterThan(0);

			// Force a recompile of shared by touching one of its sources, and wipe
			// out/ so compileFiles definitely runs.
			fs.removeSync(SHARED_OUT);
			fs.removeSync(GAME_OUT);
			const helperPath = path.join(FIXTURE_DIR, "shared", "src", "helper.ts");
			const originalHelper = fs.readFileSync(helperPath, "utf-8");
			fs.writeFileSync(helperPath, originalHelper + "\n// touch\n");

			try {
				vi.spyOn(fs.promises, "writeFile").mockImplementation((async (p: string) => {
					if (typeof p === "string" && p.endsWith(".luau")) {
						throw new Error("synthetic write failure mid-emit");
					}
					return undefined;
				}) as never);
				vi.spyOn(nodeFs, "writeFileSync").mockImplementation(((p: string) => {
					if (typeof p === "string" && p.endsWith(".luau")) {
						throw new Error("synthetic write failure mid-emit");
					}
					return undefined;
				}) as never);

				await expect(buildSolution(ROOT_TSCONFIG, { ...LUA_OPTIONS }, {})).rejects.toThrow(
					/synthetic write failure/,
				);

				// The fix snapshots the prior tsbuildinfo BEFORE project.emit()
				// overwrites it, and restores that snapshot on failure rather than
				// either leaving the lying new one or dropping the project entirely.
				// On the next --build the previously-successful incremental state is
				// recoverable instead of forcing a full rebuild.
				expect(fs.existsSync(SHARED_TSBUILDINFO)).toBe(true);
				expect(fs.readFileSync(SHARED_TSBUILDINFO, "utf-8")).toBe(priorContent);
			} finally {
				fs.writeFileSync(helperPath, originalHelper);
			}
		});
	});
});
