import path from "path";
import ts from "typescript";
import { describe, expect, it } from "vitest";

import { validateCompilerOptions } from "./validateCompilerOptions.ts";

function createValidOptions(overrides: Partial<ts.CompilerOptions> = {}): ts.CompilerOptions {
	const projectPath = path.resolve("/fake/project");
	return {
		target: ts.ScriptTarget.ESNext,
		module: ts.ModuleKind.CommonJS,
		moduleDetection: ts.ModuleDetectionKind.Force,
		moduleResolution: ts.ModuleResolutionKind.Node10,
		noLib: true,
		strict: true,
		allowSyntheticDefaultImports: true,
		typeRoots: [path.join(projectPath, "node_modules", "@rbxts")],
		rootDir: "./src",
		outDir: "./out",
		...overrides,
	};
}

const PROJECT_PATH = path.resolve("/fake/project");

describe("validateCompilerOptions", () => {
	describe("module and moduleResolution", () => {
		it("accepts commonjs + Node10", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.CommonJS,
				moduleResolution: ts.ModuleResolutionKind.Node10,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).not.toThrow();
		});

		it("accepts Preserve + Bundler", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.Preserve,
				moduleResolution: ts.ModuleResolutionKind.Bundler,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).not.toThrow();
		});

		it("rejects Preserve module with Node10 moduleResolution", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.Preserve,
				moduleResolution: ts.ModuleResolutionKind.Node10,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).toThrow();
		});

		it("rejects Bundler moduleResolution with CommonJS module", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.CommonJS,
				moduleResolution: ts.ModuleResolutionKind.Bundler,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).toThrow();
		});

		it("rejects Node16 + Node16", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.Node16,
				moduleResolution: ts.ModuleResolutionKind.Node16,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).toThrow();
		});

		it("rejects ESNext module", () => {
			const opts = createValidOptions({
				module: ts.ModuleKind.ESNext,
			});

			expect(() => validateCompilerOptions(opts, PROJECT_PATH)).toThrow();
		});
	});
});
