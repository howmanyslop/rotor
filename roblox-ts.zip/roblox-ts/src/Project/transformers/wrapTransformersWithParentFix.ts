import ts from "typescript";

/**
 * Walks the AST and sets `.parent` only on nodes that are truly orphaned —
 * where `.parent` is undefined or disconnected from any source file.
 *
 * Unlike `ts.setParentRecursive`, this preserves existing parent chains on
 * nodes carried over from the original source file, keeping their connection
 * to the fully-bound AST intact. This is critical when a subsequent
 * transformer uses the type checker — the type checker walks `.parent` and
 * needs to reach bound nodes with valid symbols.
 *
 * Narrow safety contract: this only rescues synthesized nodes that lack any
 * parent. Spliced bound nodes keep their original `.parent` (which may point
 * to their old location); fixing that is a transformer-author concern, not
 * something this wrap can detect.
 */
function fixOrphanedParents(root: ts.SourceFile) {
	const walk = (parent: ts.Node) => {
		ts.forEachChild(parent, child => {
			if (!child.parent || !child.parent.getSourceFile?.()) {
				(child as { parent: ts.Node }).parent = parent;
			}
			walk(child);
		});
	};
	walk(root);
}

/**
 * Wraps each transformer factory so that after it transforms a SourceFile,
 * orphaned `.parent` pointers on newly-created nodes are fixed.
 *
 * Without this, when multiple transformers run in a single `ts.transformNodes`
 * pass, nodes created by an earlier transformer have no `.parent` set — the
 * binder only runs after printing. Subsequent transformers that walk `.parent`
 * will see `undefined` and break.
 */
export function wrapTransformersWithParentFix(
	transformers: Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>,
): Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>> {
	const lastIndex = transformers.length - 1;
	return transformers.map((factory, index) => {
		// The last transformer's output won't be consumed by another transformer
		// in this pass — it goes straight to the printer, which doesn't need
		// `.parent`. Skipping the final tree walk avoids wasted work.
		if (index === lastIndex) return factory;
		return (context: ts.TransformationContext) => {
			const transform = factory(context);
			return (sourceFile: ts.SourceFile | ts.Bundle) => {
				const result = transform(sourceFile);
				// Identity-preserving transformers leave the SourceFile reference
				// untouched, so by definition no orphan was introduced — the AST
				// walk would be pure overhead.
				if (result !== sourceFile && ts.isSourceFile(result)) {
					fixOrphanedParents(result);
				}

				return result;
			};
		};
	});
}
