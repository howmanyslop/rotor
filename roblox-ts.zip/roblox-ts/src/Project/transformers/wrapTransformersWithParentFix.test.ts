import ts from "typescript";
import { describe, expect, it } from "vitest";

import { wrapTransformersWithParentFix } from "./wrapTransformersWithParentFix.ts";

/**
 * Helper: create a minimal in-memory SourceFile from source text.
 */
function createSourceFile(source: string, fileName = "test.ts"): ts.SourceFile {
	return ts.createSourceFile(fileName, source, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
}

/**
 * Transformer that adds `const __injected = true;` to the top of the file
 * using updateSourceFile — this produces nodes without `.parent` set.
 */
function createNodeInjectingTransformer(): ts.TransformerFactory<ts.SourceFile | ts.Bundle> {
	return () => node => {
		if (!ts.isSourceFile(node)) return node;
		const decl = ts.factory.createVariableStatement(
			undefined,
			ts.factory.createVariableDeclarationList(
				[ts.factory.createVariableDeclaration("__injected", undefined, undefined, ts.factory.createTrue())],
				ts.NodeFlags.Const,
			),
		);
		return ts.factory.updateSourceFile(node, [decl, ...node.statements]);
	};
}

/**
 * Transformer that walks all nodes and records those with a truly
 * orphaned `.parent` (undefined or disconnected from a source file).
 */
function createOrphanCheckingTransformer(orphans: Array<{ kind: string }>) {
	const factory: ts.TransformerFactory<ts.SourceFile | ts.Bundle> = () => node => {
		if (!ts.isSourceFile(node)) return node;

		const walk = (child: ts.Node) => {
			if (!child.parent || !child.parent.getSourceFile?.()) {
				orphans.push({ kind: ts.SyntaxKind[child.kind] });
			}
			ts.forEachChild(child, walk);
		};

		ts.forEachChild(node, walk);
		return node;
	};
	return factory;
}

/**
 * Walks a source file's AST and returns nodes with orphaned `.parent`.
 */
function findOrphanedNodes(root: ts.SourceFile): Array<{ kind: string }> {
	const orphans: Array<{ kind: string }> = [];
	const walk = (child: ts.Node) => {
		if (!child.parent || !child.parent.getSourceFile?.()) {
			orphans.push({ kind: ts.SyntaxKind[child.kind] });
		}
		ts.forEachChild(child, walk);
	};
	ts.forEachChild(root, walk);
	return orphans;
}

/**
 * Runs transformers through ts.transformNodes (same as compileFiles does).
 */
function runTransformers(
	sourceFile: ts.SourceFile,
	transformers: Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>,
): ts.SourceFile {
	const result = ts.transformNodes(
		undefined,
		undefined,
		ts.factory,
		ts.getDefaultCompilerOptions(),
		[sourceFile],
		transformers,
		false,
	);
	const transformed = result.transformed[0]!;
	if (!ts.isSourceFile(transformed)) throw new Error("expected SourceFile");
	return transformed;
}

describe("transformer parent orphan problem", () => {
	it("without fix, second transformer sees orphaned nodes from first transformer", () => {
		const source = createSourceFile(`const x = 1;`);
		const orphans: Array<{ kind: string }> = [];

		runTransformers(source, [createNodeInjectingTransformer(), createOrphanCheckingTransformer(orphans)]);

		// The injected nodes should have missing/wrong parents
		expect(orphans.length).toBeGreaterThan(0);
	});
});

describe("wrapTransformersWithParentFix", () => {
	it("no orphaned nodes after fix — all nodes have a parent connected to a source file", () => {
		const source = createSourceFile(`const x = 1;`);
		const orphans: Array<{ kind: string }> = [];

		const transformers = [createNodeInjectingTransformer(), createOrphanCheckingTransformer(orphans)];
		const wrapped = wrapTransformersWithParentFix(transformers);

		runTransformers(source, wrapped);

		expect(orphans).toEqual([]);
	});

	it("preserves transformer behavior — injected node exists in output", () => {
		const source = createSourceFile(`const x = 1;`);

		const transformers = [createNodeInjectingTransformer()];
		const wrapped = wrapTransformersWithParentFix(transformers);

		const result = runTransformers(source, wrapped);
		const printed = ts.createPrinter().printFile(result);

		expect(printed).toContain("__injected");
		expect(printed).toContain("const x = 1");
	});

	it("handles transformers that return the source file unchanged", () => {
		const source = createSourceFile(`const x = 1;`);
		const orphans: Array<{ kind: string }> = [];

		const noopTransformer: ts.TransformerFactory<ts.SourceFile | ts.Bundle> = () => node => node;
		const transformers = [noopTransformer, createOrphanCheckingTransformer(orphans)];
		const wrapped = wrapTransformersWithParentFix(transformers);

		runTransformers(source, wrapped);

		expect(orphans).toEqual([]);
	});

	it("skips parent fix after the last transformer — avoids wasted tree walk", () => {
		const source = createSourceFile(`const x = 1;`);

		// Single injecting transformer = last transformer, fix should be skipped
		const transformers = [createNodeInjectingTransformer()];
		const wrapped = wrapTransformersWithParentFix(transformers);

		const result = runTransformers(source, wrapped);

		// The output should still have orphaned nodes since the fix was skipped
		expect(findOrphanedNodes(result).length).toBeGreaterThan(0);
	});

	it("still fixes intermediate transformers when last is skipped", () => {
		const source = createSourceFile(`const x = 1;`);
		const orphans: Array<{ kind: string }> = [];

		// Inject → check → inject. The check (middle) should see no orphans,
		// even though the last transformer's fix is skipped.
		const transformers = [
			createNodeInjectingTransformer(),
			createOrphanCheckingTransformer(orphans),
			createNodeInjectingTransformer(),
		];
		const wrapped = wrapTransformersWithParentFix(transformers);

		const result = runTransformers(source, wrapped);

		// Middle transformer saw no orphans
		expect(orphans).toEqual([]);
		// But final output has orphans (last transformer's fix was skipped)
		expect(findOrphanedNodes(result).length).toBeGreaterThan(0);
	});

	it("preserves original parent chain on existing nodes — does not reparent to synthetic source file", () => {
		const source = createSourceFile(`const x = 1;`);
		const originalStatement = source.statements[0]!;
		const originalParent = originalStatement.parent;

		// Transformer that injects a node, producing a NEW source file via updateSourceFile.
		// The original statement's .parent should still point to the OLD source file.
		const transformers = [createNodeInjectingTransformer()];
		const wrapped = wrapTransformersWithParentFix(transformers);

		runTransformers(source, wrapped);

		// Original statement must keep its parent pointing to the original (bound) source file,
		// NOT the new synthetic source file. This is critical for type checker correctness.
		expect(originalStatement.parent).toBe(originalParent);
	});
});
