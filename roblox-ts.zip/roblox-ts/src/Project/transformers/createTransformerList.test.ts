import path from "path";
import ts from "typescript";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import type { TransformerPluginConfig } from "../../Shared/types.ts";
import { createTransformerList, flattenIntoTransformers } from "./createTransformerList.ts";

const FIXTURE_DIR = path.resolve(__dirname, "../../..", "tests/transformer-plugin-fixture");

function createSourceFile(fileName: string, source = ""): ts.SourceFile {
	return ts.createSourceFile(fileName, source, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
}

function runTransformers(
	sourceFiles: Array<ts.SourceFile>,
	transformers: Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>,
): Array<ts.SourceFile> {
	const result = ts.transformNodes(
		undefined,
		undefined,
		ts.factory,
		ts.getDefaultCompilerOptions(),
		sourceFiles,
		transformers,
		false,
	);
	return result.transformed.filter(ts.isSourceFile);
}

describe("createTransformerList", () => {
	beforeEach(() => {
		(globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits = [];
	});

	afterEach(() => {
		delete (globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits;
	});

	it("skips files where shouldTransformSourceFile returns false", () => {
		const config: TransformerPluginConfig = { transform: "./identity-rewrite-transformer.js" };
		const stubProgram = {} as ts.Program;
		const transformers = flattenIntoTransformers(createTransformerList(stubProgram, [config], FIXTURE_DIR));

		const processed = createSourceFile("process-me.ts");
		const skipped = createSourceFile("skip-this.ts");

		const [out1, out2] = runTransformers([processed, skipped], transformers);
		const visits = (globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits;

		expect(visits).toEqual(["process-me.ts"]);
		expect(out2).toBe(skipped);
		// process-me.ts goes through the transformer; identity may or may not be preserved
		// depending on TS — but the key invariant is that the visit happened.
		expect(out1).toBeDefined();
	});

	it("invokes the transformer for every file when no hook is exported", () => {
		const stubProgram = {} as ts.Program;
		// no-hook-transformer.js intentionally omits shouldTransformSourceFile,
		// so the compiler should fall back to invoking the transformer on every file.
		const transformers = flattenIntoTransformers(
			createTransformerList(stubProgram, [{ transform: "./no-hook-transformer.js" }], FIXTURE_DIR),
		);

		const a = createSourceFile("alpha.ts");
		const b = createSourceFile("skip-bravo.ts");

		runTransformers([a, b], transformers);
		const visits = (globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits;

		expect(new Set(visits)).toEqual(new Set(["alpha.ts", "skip-bravo.ts"]));
	});

	it("keeps afterDeclarations plugins out of the source-file pass", () => {
		const stubProgram = {} as ts.Program;
		const transformerList = createTransformerList(
			stubProgram,
			[{ transform: "./declaration-only-transformer.js", afterDeclarations: true }],
			FIXTURE_DIR,
		);

		// The bucket is what compileFiles hands to `Program.emit` as the
		// declaration pass; flattenIntoTransformers must not duplicate it into
		// the `ts.transformNodes` list, which only ever sees source files.
		expect(transformerList.afterDeclarations).toHaveLength(1);
		expect(flattenIntoTransformers(transformerList)).toEqual([]);

		runTransformers([createSourceFile("alpha.ts")], flattenIntoTransformers(transformerList));
		expect((globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits).toEqual([]);
	});

	it("ignores non-function shouldTransformSourceFile exports without throwing", () => {
		const stubProgram = {} as ts.Program;
		// non-function-hook-transformer.js exports `shouldTransformSourceFile = true`;
		// the typeof guard in createTransformerList must drop it and behave as if no
		// hook was exported.
		const transformers = flattenIntoTransformers(
			createTransformerList(stubProgram, [{ transform: "./non-function-hook-transformer.js" }], FIXTURE_DIR),
		);

		const a = createSourceFile("alpha.ts");
		const b = createSourceFile("skip-bravo.ts");

		expect(() => runTransformers([a, b], transformers)).not.toThrow();
		const visits = (globalThis as { __shouldTransformVisits?: Array<string> }).__shouldTransformVisits;
		expect(new Set(visits)).toEqual(new Set(["alpha.ts", "skip-bravo.ts"]));
	});
});

describe("flattenIntoTransformers", () => {
	const orderGlobal = globalThis as { __transformerOrder?: Array<string> };

	beforeEach(() => {
		orderGlobal.__transformerOrder = [];
	});

	afterEach(() => {
		delete orderGlobal.__transformerOrder;
	});

	it("orders before, then after, and drops afterDeclarations", () => {
		const before: ts.TransformerFactory<ts.SourceFile> = () => node => node;
		const after: ts.TransformerFactory<ts.SourceFile> = () => node => node;
		const afterDeclarations: ts.TransformerFactory<ts.SourceFile | ts.Bundle> = () => node => node;

		const flattened = flattenIntoTransformers({
			before: [before],
			after: [after],
			afterDeclarations: [afterDeclarations],
		});

		// afterDeclarations belongs to the declaration printer's pass, which
		// compileFiles drives through Program.emit — not to ts.transformNodes.
		expect(flattened).toHaveLength(2);
		expect(flattened[0]).toBe(before);
		expect(flattened[1]).toBe(after);
	});

	it("skips buckets the caller left off", () => {
		const before: ts.TransformerFactory<ts.SourceFile> = () => node => node;

		expect(flattenIntoTransformers({ before: [before] })).toEqual([before]);
		expect(flattenIntoTransformers({})).toEqual([]);
	});

	it("runs an `after` plugin last even when it is configured first", () => {
		const stubProgram = {} as ts.Program;
		const configs: Array<TransformerPluginConfig> = [
			{ transform: "./order-recording-transformer.js", label: "leaf", after: true },
			{ transform: "./order-recording-transformer.js", label: "base" },
		];
		const transformers = flattenIntoTransformers(createTransformerList(stubProgram, configs, FIXTURE_DIR));

		runTransformers([createSourceFile("alpha.ts")], transformers);

		expect(orderGlobal.__transformerOrder).toEqual(["base", "leaf"]);
	});
});
