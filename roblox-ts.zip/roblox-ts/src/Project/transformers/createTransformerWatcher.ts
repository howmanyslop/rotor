import ts from "typescript";

import type { TransformerWatcher } from "../../Shared/types.ts";

function createServiceHost(program: ts.Program) {
	const rootFileNames = program.getRootFileNames().map(x => x);
	const files = new Map<string, number>();

	rootFileNames.forEach(fileName => {
		files.set(fileName, 0);
	});

	const overriddenText = new Map<string, string>();

	// getScriptFileNames stats every root file; hosts that sync the open-file
	// set (typescript-native-bridge) call it far more often than stock, so the
	// filtered list is cached until a new file name appears.
	let scriptFileNamesCache: Array<string> | undefined;

	function updateFile(fileName: string, text: string) {
		// Skip the version bump when content hasn't changed — the language service
		// uses version (not content) to decide whether to re-parse, so bumping for
		// no-op rewrites forces redundant rebinds on getProgram().
		if (overriddenText.get(fileName) === text) return;

		if (!files.has(fileName)) scriptFileNamesCache = undefined;

		overriddenText.set(fileName, text);

		const currentVersion = files.get(fileName) ?? 0;
		files.set(fileName, currentVersion + 1);
	}

	const serviceHost: ts.LanguageServiceHost = {
		getScriptFileNames: () => (scriptFileNamesCache ??= [...files.keys()].filter(ts.sys.fileExists)),
		getCurrentDirectory: () => process.cwd(),
		getCompilationSettings: () => program.getCompilerOptions(),
		getDefaultLibFileName: options => ts.getDefaultLibFilePath(options),
		fileExists: ts.sys.fileExists,
		readDirectory: ts.sys.readDirectory,
		directoryExists: ts.sys.directoryExists,
		getDirectories: ts.sys.getDirectories,
		// Forward realpath so the language service canonicalizes symlinks the same
		// way the builder program (and stock tsc) do. Without it, module
		// resolution keeps symlinked paths, so under pnpm's isolated node_modules
		// a transitive @rbxts dependency imported from a top-level-symlinked
		// package fails to resolve — it walks up to the flat node_modules/@rbxts
		// instead of the package's real .pnpm sibling — degrading types that
		// package re-exports and producing phantom diagnostics.
		realpath: ts.sys.realpath,
		// Forward project references so the language service program applies the
		// same source-of-project-reference redirect as the builder program.
		// Without this, module resolution that lands on a referenced project's
		// .ts source ingests it directly instead of redirecting to its emitted
		// .d.ts, and the per-file getPreEmitDiagnostics pass rejects the file
		// with TS6059 under this project's rootDir.
		getProjectReferences: () => program.getProjectReferences(),
		// Without this the language service defaults to case-insensitive path
		// canonicalization while the builder program follows ts.sys — divergent
		// on case-sensitive filesystems (Linux CI), same class of plugin-only
		// drift as the redirect above.
		useCaseSensitiveFileNames: () => ts.sys.useCaseSensitiveFileNames,
		getScriptVersion,
		getScriptSnapshot,
		readFile,
	};

	function getScriptVersion(fileName: string) {
		const version = files.get(fileName)?.toString();
		return version ?? "0";
	}

	// Version-keyed snapshot cache: repeated getScriptSnapshot calls must return
	// the same snapshot instance while a file is unchanged. Stable identity lets
	// downstream hosts skip content re-compares (and avoids re-reading disk for
	// files that were never overridden).
	const snapshotCache = new Map<string, { snapshot: ts.IScriptSnapshot; version: string }>();

	function getScriptSnapshot(fileName: string) {
		const version = getScriptVersion(fileName);
		const cached = snapshotCache.get(fileName);
		if (cached !== undefined && cached.version === version) return cached.snapshot;

		const content = readFile(fileName);
		if (content === undefined) return;

		const snapshot = ts.ScriptSnapshot.fromString(content);
		snapshotCache.set(fileName, { snapshot, version });
		return snapshot;
	}

	function readFile(fileName: string, encoding?: string) {
		const content = overriddenText.get(fileName);
		if (content !== undefined) return content;

		return ts.sys.readFile(fileName, encoding);
	}

	return { serviceHost, updateFile };
}

export function createTransformerWatcher(program: ts.Program): TransformerWatcher {
	const { serviceHost, updateFile } = createServiceHost(program);
	const service = ts.createLanguageService(
		serviceHost,
		// Match the host's case sensitivity — the registry defaults to
		// case-insensitive keys, which would disagree with the host on
		// case-sensitive filesystems.
		ts.createDocumentRegistry(ts.sys.useCaseSensitiveFileNames),
	);

	return { service, updateFile };
}
