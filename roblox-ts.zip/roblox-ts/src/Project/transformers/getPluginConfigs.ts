import { createRequire } from "node:module";
import path from "path";
import ts from "typescript";

import { ProjectError } from "../../Shared/errors/ProjectError.ts";
import type { TransformerPluginConfig } from "../../Shared/types.ts";

// Resolve tsconfig "extends" paths whether rbxtsc runs from the bundled CJS
// dist or directly from ESM source under node, where bare `require` is undefined.
const requireModule = createRequire(import.meta.url);

export function getPluginConfigs(tsConfigPath: string) {
	const configFile = ts.readConfigFile(tsConfigPath, ts.sys.readFile);
	if (configFile.error) {
		throw new ProjectError(configFile.error.messageText.toString());
	}

	const pluginConfigs = new Array<TransformerPluginConfig>();
	const config = configFile.config;
	const plugins = config.compilerOptions?.plugins;
	if (plugins && Array.isArray(plugins)) {
		for (const pluginConfig of plugins) {
			if (pluginConfig.transform && typeof pluginConfig.transform === "string") {
				pluginConfigs.push(pluginConfig);
			}
		}
	}

	if (config.extends) {
		const extendedPath = requireModule.resolve(config.extends, {
			paths: [path.dirname(tsConfigPath)],
		});
		pluginConfigs.push(...getPluginConfigs(extendedPath));
	}

	return pluginConfigs;
}
