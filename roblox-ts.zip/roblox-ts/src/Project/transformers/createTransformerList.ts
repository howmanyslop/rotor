import { createRequire } from "node:module";

import resolve from "resolve";
import ts from "typescript";

import { errors } from "../../Shared/diagnostics.ts";
import type { ShouldTransformSourceFile, TransformerPluginConfig } from "../../Shared/types.ts";
import { DiagnosticService } from "../../TSTransformer/classes/DiagnosticService.ts";

// Load user transformer plugins whether rbxtsc runs from the bundled CJS dist
// or directly from ESM source under node. createRequire loads CJS plugins only;
// an ESM-only plugin package fails here with ERR_REQUIRE_ESM, so ship a CJS build.
const requireModule = createRequire(import.meta.url);

interface TransformerBasePlugin {
	before?: ts.TransformerFactory<ts.SourceFile>;
	after?: ts.TransformerFactory<ts.SourceFile>;
	afterDeclarations?: ts.TransformerFactory<ts.SourceFile | ts.Bundle>;
}

type TransformerPlugin = TransformerBasePlugin | ts.TransformerFactory<ts.SourceFile>;

type LSPattern = (ls: ts.LanguageService, config: unknown) => TransformerPlugin;

type ProgramPattern = (program: ts.Program, config: unknown, helpers?: { ts: typeof ts }) => TransformerPlugin;

type CompilerOptionsPattern = (compilerOpts: ts.CompilerOptions, config: unknown) => TransformerPlugin;

type ConfigPattern = (config: unknown) => TransformerPlugin;

type TypeCheckerPattern = (checker: ts.TypeChecker, config: unknown) => TransformerPlugin;

type RawPattern = (
	context: ts.TransformationContext,
	program: ts.Program,
	config: unknown,
) => ts.Transformer<ts.SourceFile>;

type PluginFactory =
	| LSPattern
	| ProgramPattern
	| ConfigPattern
	| CompilerOptionsPattern
	| TypeCheckerPattern
	| RawPattern;

function getTransformerFromFactory(factory: PluginFactory, config: TransformerPluginConfig, program: ts.Program) {
	const { after, afterDeclarations, type, ...manualConfig } = config;
	let transformer: TransformerPlugin;
	switch (type) {
		case undefined:
		case "program":
			transformer = (factory as ProgramPattern)(program, manualConfig, { ts });
			break;
		case "checker":
			transformer = (factory as TypeCheckerPattern)(program.getTypeChecker(), manualConfig);
			break;
		case "compilerOptions":
			transformer = (factory as CompilerOptionsPattern)(program.getCompilerOptions(), manualConfig);
			break;
		case "config":
			transformer = (factory as ConfigPattern)(manualConfig);
			break;
		case "raw":
			transformer = (ctx: ts.TransformationContext) => (factory as RawPattern)(ctx, program, manualConfig);
			break;
		default:
			return undefined;
	}

	if (typeof transformer === "function") {
		if (after) {
			return { after: transformer };
		} else if (afterDeclarations) {
			return { afterDeclarations: transformer as ts.TransformerFactory<ts.SourceFile | ts.Bundle> };
		}
		return { before: transformer };
	}
	return transformer;
}

function wrapWithShouldTransform<T extends ts.SourceFile | ts.Bundle>(
	factory: ts.TransformerFactory<T>,
	hook: ShouldTransformSourceFile,
	program: ts.Program,
	config: TransformerPluginConfig,
): ts.TransformerFactory<T> {
	return (context: ts.TransformationContext) => {
		const transform = factory(context);
		return (sourceFile: T) => {
			if (ts.isSourceFile(sourceFile) && !hook(sourceFile, program, config)) {
				return sourceFile;
			}
			return transform(sourceFile);
		};
	};
}

/**
 * Flattens the two source-file buckets into the single ordered list
 * `ts.transformNodes` consumes, so `before` really does run before `after`.
 *
 * The distinction only survives as array position here — every plugin
 * transformer goes into one `ts.transformNodes` call. That makes `after: true`
 * a leaf tsconfig's one lever for running behind a plugin its base tsconfig
 * declares, because `getPluginConfigs` walks `extends` leaf-first and would
 * otherwise pin the leaf's plugin ahead of the base's.
 *
 * `afterDeclarations` stays out: those factories belong to the declaration
 * printer's pass, which `compileFiles` drives through `Program.emit`. Flattening
 * them in here fed them source files and routed their output into the Luau emit.
 */
export function flattenIntoTransformers(
	transformers: ts.CustomTransformers,
): Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>> {
	// Every bucket on ts.CustomTransformers is optional, so a caller may hand
	// over a partial set even though createTransformerList always fills all three.
	const result: Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>> = [];
	result.push(
		...((transformers.before ?? []) as Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>),
		...((transformers.after ?? []) as Array<ts.TransformerFactory<ts.SourceFile | ts.Bundle>>),
	);
	return result;
}

export function createTransformerList(
	program: ts.Program,
	configs: Array<TransformerPluginConfig>,
	baseDir: string,
): ts.CustomTransformers {
	const transforms: ts.CustomTransformers = {
		before: [],
		after: [],
		afterDeclarations: [],
	};
	for (const config of configs) {
		if (!config.transform) continue;

		try {
			const modulePath = resolve.sync(config.transform, { basedir: baseDir });

			const commonjsModule: PluginFactory | { [key: string]: PluginFactory } = requireModule(modulePath);

			// When a plugin uses `module.exports = factory` (CJS function-export style),
			// any attached named exports (`module.exports.shouldTransformSourceFile = ...`)
			// live on the function itself — so we merge them into the lookup object.
			const factoryModule = (
				typeof commonjsModule === "function"
					? Object.assign({ default: commonjsModule }, commonjsModule)
					: commonjsModule
			) as { [key: string]: unknown };
			const factory = factoryModule[config.import ?? "default"] as PluginFactory | undefined;

			if (!factory || typeof factory !== "function") throw new Error("factory not a function");

			const shouldTransformExport = factoryModule.shouldTransformSourceFile;
			const shouldTransform =
				typeof shouldTransformExport === "function"
					? (shouldTransformExport as ShouldTransformSourceFile)
					: undefined;
			const gate = <T extends ts.SourceFile | ts.Bundle>(f: ts.TransformerFactory<T>) =>
				shouldTransform ? wrapWithShouldTransform(f, shouldTransform, program, config) : f;

			const transformer = getTransformerFromFactory(factory, config, program);
			if (transformer) {
				if (transformer.afterDeclarations) {
					transforms.afterDeclarations?.push(gate(transformer.afterDeclarations));
				}
				if (transformer.after) {
					transforms.after?.push(gate(transformer.after));
				}
				if (transformer.before) {
					transforms.before?.push(gate(transformer.before));
				}
			}
		} catch (err) {
			// A configured transformer that cannot be loaded silently changes
			// the emit, so this errors instead of warning.
			DiagnosticService.addDiagnostic(errors.transformerNotFound(config.transform, err));
		}
	}

	return transforms;
}
