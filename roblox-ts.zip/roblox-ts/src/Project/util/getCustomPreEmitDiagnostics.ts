import type ts from "typescript";

import type { ProjectData } from "../../Shared/types.ts";
import { fileUsesCommentDirectives } from "../preEmitDiagnostics/fileUsesCommentDirectives.ts";

export type PreEmitChecker = (data: ProjectData, sourceFile: ts.SourceFile) => Array<ts.Diagnostic>;
const PRE_EMIT_DIAGNOSTICS: Array<PreEmitChecker> = [fileUsesCommentDirectives];

export function getCustomPreEmitDiagnostics(data: ProjectData, sourceFile: ts.SourceFile) {
	const diagnostics = new Array<ts.Diagnostic>();
	for (const check of PRE_EMIT_DIAGNOSTICS) {
		diagnostics.push(...check(data, sourceFile));
	}
	return diagnostics;
}
