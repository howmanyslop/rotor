import type ts from "typescript";
import { describe, expect, it } from "vitest";

import { snapshotBuildState } from "./snapshotBuildState.ts";

function fakeProgram(changed: Map<string, true> | undefined): ts.BuilderProgram {
	return { state: { changedFilesSet: changed } } as never;
}

describe("snapshotBuildState", () => {
	it("returns an empty set when BuilderProgram.state.changedFilesSet is undefined", () => {
		const snapshot = snapshotBuildState(fakeProgram(undefined));

		expect(snapshot.changedFilePaths.size).toBe(0);
	});

	it("returns an empty set when BuilderProgram.state.changedFilesSet has no entries", () => {
		const snapshot = snapshotBuildState(fakeProgram(new Map()));

		expect(snapshot.changedFilePaths.size).toBe(0);
	});

	it("returns every entry currently in BuilderProgram.state.changedFilesSet", () => {
		const live = new Map<string, true>([
			["/project/src/a.ts", true],
			["/project/src/b.ts", true],
		]);

		const snapshot = snapshotBuildState(fakeProgram(live));

		expect([...snapshot.changedFilePaths].sort()).toEqual(["/project/src/a.ts", "/project/src/b.ts"].sort());
	});

	it("the returned set is stable across a subsequent clear of the live changedFilesSet", () => {
		const live = new Map<string, true>([["/project/src/a.ts", true]]);
		const snapshot = snapshotBuildState(fakeProgram(live));

		live.clear();

		expect(snapshot.changedFilePaths.has("/project/src/a.ts")).toBe(true);
	});
});
