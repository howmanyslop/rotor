import { randomUUID } from "crypto";
import fs from "fs";
import os from "os";
import path from "path";
import type ts from "typescript";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { runRbxtsEmit } from "./runRbxtsEmit.ts";

const ROOT = path.join(os.tmpdir(), "rbxts-runRbxtsEmit-tests");
type WriteFileArgs = Parameters<typeof fs.promises.writeFile>;
type EmitWriteFile = NonNullable<Parameters<ts.BuilderProgram["emit"]>[1]>;

interface Deferred<T = void> {
	readonly promise: Promise<T>;
	readonly resolve: (value: T | PromiseLike<T>) => void;
	readonly reject: (reason?: unknown) => void;
}

function createDeferred<T = void>(): Deferred<T> {
	let resolve!: (value: T | PromiseLike<T>) => void;
	let reject!: (reason?: unknown) => void;
	const promise = new Promise<T>((innerResolve, innerReject) => {
		resolve = innerResolve;
		reject = innerReject;
	});
	return { promise, resolve, reject };
}

async function waitForUnhandledRejectionTurn(): Promise<void> {
	await new Promise(resolve => setImmediate(resolve));
}

function createFakeBuilderProgram(
	compilerOptions: ts.CompilerOptions,
	tsProgram: ts.Program,
	emit?: (writeFile: EmitWriteFile) => ts.EmitResult | undefined,
): ts.BuilderProgram {
	const noopWriteFile: EmitWriteFile = () => {};
	const builderEmit: ts.BuilderProgram["emit"] = (_targetSourceFile, writeFile) =>
		emit?.(writeFile ?? noopWriteFile) ?? { diagnostics: [], emitSkipped: false };

	return {
		getCompilerOptions: () => compilerOptions,
		getProgram: () => tsProgram,
		emit: builderEmit,
	} as unknown as ts.BuilderProgram;
}

describe("runRbxtsEmit", () => {
	let tmp: string;

	beforeEach(() => {
		tmp = path.join(ROOT, randomUUID());
		fs.mkdirSync(tmp, { recursive: true });
	});

	afterEach(() => {
		vi.restoreAllMocks();
		fs.rmSync(tmp, { recursive: true, force: true });
	});

	it("handles a declaration flush failure without an unhandled rejection while compileFiles is still running", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.ts");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			declarationMap: true,
			isolatedDeclarations: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram);
		const declarationError = new Error("synthetic declaration write failure");
		const unhandled = new Array<unknown>();
		const onUnhandledRejection = (reason: unknown) => unhandled.push(reason);
		const originalWriteFile = fs.promises.writeFile;
		const continueCompile = createDeferred();

		vi.spyOn(fs.promises, "writeFile").mockImplementation((async (...args: WriteFileArgs) => {
			const [filePath] = args;
			if (String(filePath).endsWith(".d.ts")) throw declarationError;
			return originalWriteFile(...args);
		}) as never);
		process.on("unhandledRejection", onUnhandledRejection);

		try {
			const resultPromise = runRbxtsEmit({
				program,
				solutionEmit: writeFile => {
					writeFile(dtsPath, "export declare const value: number;\n", false);
					writeFile(buildInfoPath, '{"program":"new"}', false);
					return { diagnostics: [], emitSkipped: false };
				},
				compileThunk: async () => {
					await continueCompile.promise;
					return { diagnostics: [], emitSkipped: false };
				},
			});

			await waitForUnhandledRejectionTurn();
			continueCompile.resolve();

			await expect(resultPromise).rejects.toThrow(declarationError);

			expect(unhandled).toEqual([]);
			expect(compilerOptions.declaration).toBe(true);
			expect(compilerOptions.composite).toBe(true);
			expect(compilerOptions.isolatedDeclarations).toBe(true);
			expect(compilerOptions.declarationMap).toBe(true);
			expect(tsProgram.emitBuildInfo).toBe(originalEmitBuildInfo);
		} finally {
			process.off("unhandledRejection", onUnhandledRejection);
		}
	});

	it("leaves the prior tsbuildinfo on disk while the compile thunk runs", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.ts");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram);

		fs.mkdirSync(outDir, { recursive: true });
		fs.writeFileSync(buildInfoPath, '{"program":"prior"}');

		let buildInfoSeenByCompile: string | undefined;

		const result = await runRbxtsEmit({
			program,
			solutionEmit: writeFile => {
				writeFile(dtsPath, "export declare const value: number;\n", false);
				writeFile(buildInfoPath, '{"program":"new"}', false);
				return { diagnostics: [], emitSkipped: false };
			},
			// Ctrl-C resilience: the long Luau compile must run with the prior
			// tsbuildinfo intact on disk, never the new one and never absent, so
			// an interrupt mid-compile leaves an incremental-ready buildinfo.
			compileThunk: async () => {
				buildInfoSeenByCompile = fs.readFileSync(buildInfoPath, "utf-8");
				return { diagnostics: [], emitSkipped: false };
			},
		});

		expect(buildInfoSeenByCompile).toBe('{"program":"prior"}');
		expect(result.emittedSuccessfully).toBe(true);
		// Flushed only after the compile succeeds.
		expect(fs.readFileSync(buildInfoPath, "utf-8")).toBe('{"program":"new"}');
	});

	it("runs compileFiles while declarations flush and waits for declarations before resolving", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.ts");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram);
		const originalWriteFile = fs.promises.writeFile;
		const dtsWriteStarted = createDeferred();
		const releaseDtsWrite = createDeferred();
		let resolved = false;

		vi.spyOn(fs.promises, "writeFile").mockImplementation((async (...args: WriteFileArgs) => {
			const [filePath] = args;
			if (String(filePath).endsWith(".d.ts")) {
				dtsWriteStarted.resolve();
				await releaseDtsWrite.promise;
			}
			return originalWriteFile(...args);
		}) as never);

		const resultPromise = runRbxtsEmit({
			program,
			solutionEmit: writeFile => {
				writeFile(dtsPath, "export declare const value: number;\n", false);
				writeFile(buildInfoPath, '{"program":"new"}', false);
				return { diagnostics: [], emitSkipped: false };
			},
			compileThunk: async () => {
				await dtsWriteStarted.promise;
				expect(fs.existsSync(dtsPath)).toBe(false);
				return { diagnostics: [], emitSkipped: false };
			},
		}).then(result => {
			resolved = true;
			return result;
		});

		await dtsWriteStarted.promise;
		await Promise.resolve();
		expect(resolved).toBe(false);
		expect(fs.existsSync(dtsPath)).toBe(false);

		releaseDtsWrite.resolve();

		await expect(resultPromise).resolves.toMatchObject({ emittedSuccessfully: true });
		expect(resolved).toBe(true);
		expect(fs.readFileSync(dtsPath, "utf-8")).toBe("export declare const value: number;\n");
		expect(fs.readFileSync(buildInfoPath, "utf-8")).toBe('{"program":"new"}');
		expect(tsProgram.emitBuildInfo).toBe(originalEmitBuildInfo);
	});

	it("waits for declarations and restores prior buildinfo when compileFiles fails", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.ts");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram);
		const originalWriteFile = fs.promises.writeFile;
		const dtsWriteStarted = createDeferred();
		const releaseDtsWrite = createDeferred();
		let rejected = false;

		fs.mkdirSync(outDir, { recursive: true });
		fs.writeFileSync(buildInfoPath, '{"program":"prior"}');

		vi.spyOn(fs.promises, "writeFile").mockImplementation((async (...args: WriteFileArgs) => {
			const [filePath] = args;
			if (String(filePath).endsWith(".d.ts")) {
				dtsWriteStarted.resolve();
				await releaseDtsWrite.promise;
			}
			return originalWriteFile(...args);
		}) as never);

		const resultPromise = runRbxtsEmit({
			program,
			solutionEmit: writeFile => {
				writeFile(dtsPath, "export declare const failed: true;\n", false);
				writeFile(buildInfoPath, '{"program":"new"}', false);
				return { diagnostics: [], emitSkipped: false };
			},
			compileThunk: async () => {
				await dtsWriteStarted.promise;
				throw new Error("synthetic compile failure");
			},
		}).catch(error => {
			rejected = true;
			throw error;
		});

		await dtsWriteStarted.promise;
		await Promise.resolve();
		expect(rejected).toBe(false);
		expect(fs.existsSync(dtsPath)).toBe(false);

		releaseDtsWrite.resolve();

		await expect(resultPromise).rejects.toThrow(/synthetic compile failure/);
		expect(fs.readFileSync(dtsPath, "utf-8")).toBe("export declare const failed: true;\n");
		expect(fs.readFileSync(buildInfoPath, "utf-8")).toBe('{"program":"prior"}');
		expect(compilerOptions.declaration).toBe(true);
		expect(compilerOptions.composite).toBe(true);
		expect(tsProgram.emitBuildInfo).toBe(originalEmitBuildInfo);
	});

	it("keeps compileFiles failure as the primary error when declaration flush also fails", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.ts");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram);
		const declarationError = new Error("synthetic declaration write failure");
		const compileError = new Error("synthetic compile failure");
		const originalWriteFile = fs.promises.writeFile;

		fs.mkdirSync(outDir, { recursive: true });
		fs.writeFileSync(buildInfoPath, '{"program":"prior"}');

		vi.spyOn(fs.promises, "writeFile").mockImplementation((async (...args: WriteFileArgs) => {
			const [filePath] = args;
			if (String(filePath).endsWith(".d.ts")) throw declarationError;
			return originalWriteFile(...args);
		}) as never);

		await expect(
			runRbxtsEmit({
				program,
				solutionEmit: writeFile => {
					writeFile(dtsPath, "export declare const failed: true;\n", false);
					writeFile(buildInfoPath, '{"program":"new"}', false);
					return { diagnostics: [], emitSkipped: false };
				},
				compileThunk: async () => {
					throw compileError;
				},
			}),
		).rejects.toThrow(compileError);

		expect(fs.readFileSync(buildInfoPath, "utf-8")).toBe('{"program":"prior"}');
		expect(compilerOptions.declaration).toBe(true);
		expect(compilerOptions.composite).toBe(true);
		expect(tsProgram.emitBuildInfo).toBe(originalEmitBuildInfo);
	});

	it("uses program.emit when no solution emit wrapper is provided", async () => {
		const outDir = path.join(tmp, "out");
		const dtsPath = path.join(outDir, "index.d.mts");
		const dtsMapPath = path.join(outDir, "index.d.mts.map");
		const jsPath = path.join(outDir, "index.mjs");
		const buildInfoPath = path.join(outDir, "tsconfig.rbxtsc.tsbuildinfo");
		const compilerOptions: ts.CompilerOptions = {
			composite: true,
			declaration: true,
			declarationMap: true,
			tsBuildInfoFile: buildInfoPath,
		};
		const originalEmitBuildInfo = () => ({ diagnostics: [], emitSkipped: false });
		const tsProgram = { emitBuildInfo: originalEmitBuildInfo } as unknown as ts.Program;
		const program = createFakeBuilderProgram(compilerOptions, tsProgram, writeFile => {
			writeFile(dtsPath, "export declare const value: number;\n", false);
			writeFile(dtsMapPath, '{"version":3}\n', false);
			writeFile(jsPath, "export const value = 1;\n", false);
			writeFile(buildInfoPath, '{"program":"new"}', false);
			return { diagnostics: [], emitSkipped: false };
		});

		await expect(
			runRbxtsEmit({
				program,
				compileThunk: async () => ({ diagnostics: [], emitSkipped: false }),
			}),
		).resolves.toMatchObject({ emittedSuccessfully: true });

		expect(fs.readFileSync(dtsPath, "utf-8")).toBe("export declare const value: number;\n");
		expect(fs.readFileSync(dtsMapPath, "utf-8")).toBe('{"version":3}\n');
		expect(fs.existsSync(jsPath)).toBe(false);
		expect(fs.readFileSync(buildInfoPath, "utf-8")).toBe('{"program":"new"}');
		expect(compilerOptions.declaration).toBe(true);
		expect(compilerOptions.composite).toBe(true);
		expect(compilerOptions.declarationMap).toBe(true);
		expect(tsProgram.emitBuildInfo).toBe(originalEmitBuildInfo);
	});
});
