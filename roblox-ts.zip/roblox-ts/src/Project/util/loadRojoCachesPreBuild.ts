import type { RojoResolver } from "@isentinel/rojo-utils";
import crypto from "crypto";
import fs from "fs-extra";
import path from "path";

import type { RojoResolverCache } from "../classes/RojoResolverCache.ts";

interface LoadInputs {
	rojoConfigPath: string | undefined;
	typeRoots: ReadonlyArray<string>;
	outDir: string;
	nodeModulesPath: string;
}

interface LoadOutputs {
	rojoCacheEntry: { resolver: RojoResolver; persist: () => void } | undefined;
	typeRootsEntry: { resolvers: ReadonlyArray<RojoResolver>; persist: () => void };
	persistAll: () => void;
}

const ROJO_CACHE_FILENAME = "rbxts.rojocache.json";
const TYPEROOTS_CACHE_FILENAME_FALLBACK = "rbxts.typeroots.rojocache.json";

/**
 * Walks from `start` upward looking for a pnpm-workspace.yaml file. Returns the
 * containing directory or undefined if we hit the filesystem root first.
 */
function findWorkspaceRoot(start: string): string | undefined {
	let current = path.resolve(start);
	while (true) {
		if (fs.existsSync(path.join(current, "pnpm-workspace.yaml"))) return current;
		const parent = path.dirname(current);
		if (parent === current) return undefined;
		current = parent;
	}
}

function typeRootsCachePath(typeRoots: ReadonlyArray<string>, nodeModulesPath: string, outDir: string): string {
	const workspaceRoot = findWorkspaceRoot(path.dirname(nodeModulesPath));
	if (workspaceRoot === undefined) {
		return path.join(outDir, TYPEROOTS_CACHE_FILENAME_FALLBACK);
	}
	// Hash the sorted basePaths so projects with different typeRoot sets get
	// distinct cache files but identical sets share a single file across the
	// whole workspace.
	const hash = crypto
		.createHash("sha256")
		.update(
			typeRoots
				.map(r => path.normalize(r))
				.sort()
				.join("\n"),
		)
		.digest("hex")
		.slice(0, 16);
	return path.join(workspaceRoot, "node_modules", ".cache", "rbxts", `typeroots-${hash}.rojocache.json`);
}

/**
 * Loads (or seeds) the rojo + typeRoots disk caches for one project. Must run
 * BEFORE cleanup/copyInclude/copyFiles so the manifest mtimes captured at
 * load time match what's on disk on the NEXT run. The persistAll callback
 * must be invoked AFTER all output has settled — in --build that means after
 * the entire solution loop completes.
 */
export function loadRojoCachesPreBuild(cache: RojoResolverCache, inputs: LoadInputs): LoadOutputs {
	const rojoCacheFilePath = path.join(inputs.outDir, ROJO_CACHE_FILENAME);
	const typeRootsCacheFilePath = typeRootsCachePath(inputs.typeRoots, inputs.nodeModulesPath, inputs.outDir);
	const sentinelPath = path.join(inputs.nodeModulesPath, ".modules.yaml");

	const rojoCacheEntry =
		inputs.rojoConfigPath !== undefined
			? cache.getFromPathWithDiskCache(inputs.rojoConfigPath, rojoCacheFilePath)
			: undefined;
	const typeRootsEntry = cache.getSyntheticBatchWithDiskCache(inputs.typeRoots, typeRootsCacheFilePath, sentinelPath);

	return {
		rojoCacheEntry,
		typeRootsEntry,
		persistAll: () => {
			rojoCacheEntry?.persist();
			typeRootsEntry.persist();
		},
	};
}
