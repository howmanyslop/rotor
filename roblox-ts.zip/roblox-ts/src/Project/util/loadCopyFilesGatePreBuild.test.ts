import { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { loadCopyFilesGatePreBuild } from "./loadCopyFilesGatePreBuild.ts";
import { type BuildStateSnapshot } from "./snapshotBuildState.ts";

const TMP_DIR = path.join(__dirname, "__loadCopyFilesGate_tmp__");
const ROOT_DIR = path.join(TMP_DIR, "src");
const OUT_DIR = path.join(TMP_DIR, "out");
const CACHE_PATH = path.join(OUT_DIR, "rbxts.copyfiles.json");

function emptySnapshot(): BuildStateSnapshot {
	return { changedFilePaths: new Set() };
}

function runGate(opts: { snapshot?: BuildStateSnapshot; declaration?: boolean } = {}) {
	return loadCopyFilesGatePreBuild({
		rootDirs: [ROOT_DIR],
		outDir: OUT_DIR,
		declaration: opts.declaration ?? false,
		pathTranslator: new PathTranslator(ROOT_DIR, OUT_DIR, undefined, false, true),
		snapshot: opts.snapshot ?? emptySnapshot(),
	});
}

function seedAndPersist() {
	const gate = runGate();
	gate.persist();
	return gate;
}

describe("loadCopyFilesGatePreBuild", () => {
	beforeEach(() => {
		fs.mkdirpSync(ROOT_DIR);
		fs.mkdirpSync(OUT_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
	});

	describe("cold build (no manifest on disk yet)", () => {
		it("returns skipCleanup=false and skipCopyFiles=false on first build", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");

			const gate = runGate();

			expect(gate.skipCleanup).toBe(false);
			expect(gate.skipCopyFiles).toBe(false);
		});

		it("persist() writes a manifest the gate can read back on the next run", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");

			seedAndPersist();

			expect(fs.pathExistsSync(CACHE_PATH)).toBe(true);
		});
	});

	describe("warm build, no source mutations", () => {
		it("returns skipCleanup=true and skipCopyFiles=true when nothing changed", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();

			const gate = runGate();

			expect(gate.skipCleanup).toBe(true);
			expect(gate.skipCopyFiles).toBe(true);
		});
	});

	describe("warm build, .ts source deletion", () => {
		it("returns skipCleanup=false because the snapshot has the deleted .ts file", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "src.ts"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			fs.removeSync(path.join(ROOT_DIR, "src.ts"));
			// Bump parent dir mtime so dir-mtime drift mirrors a real delete.
			const future = Date.now() / 1000 + 60;
			fs.utimesSync(ROOT_DIR, future, future);

			const gate = runGate({
				snapshot: { changedFilePaths: new Set([path.join(ROOT_DIR, "src.ts")]) },
			});

			expect(gate.skipCleanup).toBe(false);
		});

		it("returns skipCopyFiles=true when only a .ts file was deleted (no non-.ts file changed)", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "src.ts"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			fs.removeSync(path.join(ROOT_DIR, "src.ts"));

			const gate = runGate({
				snapshot: { changedFilePaths: new Set([path.join(ROOT_DIR, "src.ts")]) },
			});

			expect(gate.skipCopyFiles).toBe(true);
		});
	});

	describe("warm build, new .luau under rootDir", () => {
		it("returns skipCopyFiles=false because the new file is not in the manifest", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "existing.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "existing.luau"), "");
			seedAndPersist();
			fs.outputFileSync(path.join(ROOT_DIR, "new.luau"), "");

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, .luau edited in place (critical, was missing from v1)", () => {
		it("returns skipCopyFiles=false because the file's mtime drifted from the manifest", () => {
			const luauPath = path.join(ROOT_DIR, "asset.luau");
			fs.outputFileSync(luauPath, "v1");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "v1");
			seedAndPersist();
			fs.outputFileSync(luauPath, "v2");
			const future = Date.now() / 1000 + 60;
			fs.utimesSync(luauPath, future, future);

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, .json edited in place", () => {
		it("returns skipCopyFiles=false because the file's mtime drifted from the manifest", () => {
			const jsonPath = path.join(ROOT_DIR, "data.json");
			fs.outputFileSync(jsonPath, "{}");
			fs.outputFileSync(path.join(OUT_DIR, "data.json"), "{}");
			seedAndPersist();
			fs.outputFileSync(jsonPath, '{"v":2}');
			const future = Date.now() / 1000 + 60;
			fs.utimesSync(jsonPath, future, future);

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, .luau renamed", () => {
		it("returns skipCopyFiles=false because old entry missing and new entry present", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "old.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "old.luau"), "");
			seedAndPersist();
			fs.renameSync(path.join(ROOT_DIR, "old.luau"), path.join(ROOT_DIR, "new.luau"));

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, pnpm install adds an @rbxts package", () => {
		it("returns skipCleanup=true and skipCopyFiles=true (node_modules outside rootDirs)", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			// Simulate pnpm install adding a package; node_modules is OUTSIDE rootDirs.
			fs.outputFileSync(path.join(TMP_DIR, "node_modules", "@rbxts", "newpkg", "init.luau"), "");

			const gate = runGate();

			expect(gate.skipCleanup).toBe(true);
			expect(gate.skipCopyFiles).toBe(true);
		});
	});

	describe("warm build, changedFilesSet non-empty (.ts edited)", () => {
		it("returns skipCleanup=false because the snapshot has entries", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "src.ts"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();

			const gate = runGate({
				snapshot: { changedFilePaths: new Set([path.join(ROOT_DIR, "src.ts")]) },
			});

			expect(gate.skipCleanup).toBe(false);
		});

		it("returns skipCopyFiles=true when only a .ts file changed and no non-.ts file mtime drifted", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "src.ts"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();

			const gate = runGate({
				snapshot: { changedFilePaths: new Set([path.join(ROOT_DIR, "src.ts")]) },
			});

			expect(gate.skipCopyFiles).toBe(true);
		});
	});

	describe("warm build, manifest file is corrupt", () => {
		it("returns skipCleanup=false and skipCopyFiles=false (silent fall-through)", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(CACHE_PATH, "{ not valid json");

			const gate = runGate();

			expect(gate.skipCleanup).toBe(false);
			expect(gate.skipCopyFiles).toBe(false);
		});

		it("persist() rewrites the manifest with a valid format", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(CACHE_PATH, "{ not valid json");

			runGate().persist();

			const raw = fs.readFileSync(CACHE_PATH, "utf-8");
			expect(() => JSON.parse(raw)).not.toThrow();
		});
	});

	describe("warm build, destination file was deleted from outDir", () => {
		it("returns skipCopyFiles=false so the missing dest is re-copied", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			fs.removeSync(path.join(OUT_DIR, "asset.luau"));

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, destination file was externally modified in outDir", () => {
		it("returns skipCopyFiles=false because the dest mtime drifted from the manifest", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			// Simulate external modification: branch switch, rollback, manual edit.
			const future = Date.now() / 1000 + 60;
			fs.utimesSync(path.join(OUT_DIR, "asset.luau"), future, future);

			const gate = runGate();

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, rootDirs config changed since previous run", () => {
		it("returns skipCopyFiles=false because the cached manifest's destinations belong to the old PathTranslator", () => {
			const oldRoot = path.join(TMP_DIR, "old-root");
			fs.mkdirpSync(oldRoot);
			fs.outputFileSync(path.join(oldRoot, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			loadCopyFilesGatePreBuild({
				rootDirs: [oldRoot],
				outDir: OUT_DIR,
				declaration: false,
				pathTranslator: new PathTranslator(oldRoot, OUT_DIR, undefined, false, true),
				snapshot: emptySnapshot(),
			}).persist();

			// User reconfigures rootDirs — files now belong under a different
			// rootDir and would map to a different dest path.
			const newRoot = path.join(TMP_DIR, "new-root");
			fs.mkdirpSync(newRoot);
			fs.outputFileSync(path.join(newRoot, "asset.luau"), "");

			const gate = loadCopyFilesGatePreBuild({
				rootDirs: [newRoot],
				outDir: OUT_DIR,
				declaration: false,
				pathTranslator: new PathTranslator(newRoot, OUT_DIR, undefined, false, true),
				snapshot: emptySnapshot(),
			});

			expect(gate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, source edited mid-build (between gate-walk and persist)", () => {
		it("the persisted manifest reflects the pre-build src mtime so next run detects the edit", () => {
			const luauPath = path.join(ROOT_DIR, "asset.luau");
			fs.outputFileSync(luauPath, "v1");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "v1");

			// Iter-1 gate captures src state before cleanup/copyFiles.
			const gate = runGate();
			expect(gate.skipCopyFiles).toBe(false);

			// User edits the source after gate-walk but before persist.
			fs.outputFileSync(luauPath, "v2");
			const future = Date.now() / 1000 + 60;
			fs.utimesSync(luauPath, future, future);

			gate.persist();

			// Next gate must see the new mtime on disk as a drift from the
			// persisted manifest — otherwise the edit is silently lost.
			const nextGate = runGate();
			expect(nextGate.skipCopyFiles).toBe(false);
		});
	});

	describe("warm build, non-.ts source deleted with dir-mtime artificially stable", () => {
		it("returns skipCleanup=false because the file set drifted (defends FS-precision blind spot)", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			const cachedDirMtimeSec = fs.statSync(ROOT_DIR).mtimeMs / 1000;
			fs.removeSync(path.join(ROOT_DIR, "asset.luau"));
			// Restore dir mtime to mimic FS resolution that didn't catch the delete.
			fs.utimesSync(ROOT_DIR, cachedDirMtimeSec, cachedDirMtimeSec);

			const gate = runGate();

			expect(gate.skipCleanup).toBe(false);
		});
	});

	describe("snapshot regression", () => {
		it("the gate observes the same snapshot whether or not the snapshot's source set was cleared after the snapshot ran", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");
			seedAndPersist();
			// Snapshot taken from a populated set, then the underlying source is cleared
			// (mirroring getChangedFilePaths' clear() of the live BuilderProgram set).
			const live = new Set([path.join(ROOT_DIR, "src.ts")]);
			const snapshot: BuildStateSnapshot = { changedFilePaths: new Set(live) };
			live.clear();

			const gate = runGate({ snapshot });

			expect(gate.skipCleanup).toBe(false);
		});
	});
});
