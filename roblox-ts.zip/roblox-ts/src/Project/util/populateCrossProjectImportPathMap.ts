import { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";
import ts from "typescript";

import { DTS_EXT, RBXTS_SCOPE, TS_EXT, TSX_EXT } from "../../Shared/constants.ts";
import type { ProjectOptions } from "../../Shared/types.ts";
import { findAncestorDir } from "../../Shared/util/findAncestorDir.ts";
import { getCanonicalFileName } from "../../Shared/util/getCanonicalFileName.ts";
import { getTsConfigProjectOptions } from "../functions/getTsConfigProjectOptions.ts";

function isRbxtsCommandLine(commandLine: ts.ParsedCommandLine): boolean {
	return commandLine.options.typeRoots?.some(r => path.basename(path.normalize(r)) === RBXTS_SCOPE) ?? false;
}

function isDeclarationFile(fileName: string): boolean {
	return fileName.endsWith(DTS_EXT);
}

// `.d.ts` ends with `.ts` and is intentionally matched here so hand-authored
// declaration files (e.g. handauth/index.d.ts pointing at a runtime .luau)
// land in the map. The downstream loop branches on isDeclarationFile to
// decide whether to also emit the output-side .d.ts entry.
function isTsOrDtsFile(fileName: string): boolean {
	return fileName.endsWith(TS_EXT) || fileName.endsWith(TSX_EXT);
}

/**
 * Pre-populate `importPathMap` for every referenced project in the build
 * order, including projects that are up-to-date and won't drain.
 *
 * Without this, a two-stage build (build lib alone → build dependent alone)
 * leaves the dependent's drain with no `importPathMap` entries for lib's
 * source files. Cross-project imports then fall through to the dependent's
 * own `PathTranslator` — wrong outDir → wrong Rojo mount.
 *
 * Entries written here are attributed to the referenced project via
 * `importPathMapOwnership`. If that project later drains (e.g. its
 * tsbuildinfo gets invalidated mid-watch), the drain's drop-block clears
 * these entries and the drain's own populate writes canonical ones built
 * from a real `PathTranslator` (with full program / commonSourceDirectory).
 */
export function populateCrossProjectImportPathMap(
	buildOrder: ReadonlyArray<string>,
	getParsedCommandLine: (configPath: string) => ts.ParsedCommandLine | undefined,
	entryProjectOptions: ProjectOptions,
	importPathMap: Map<string, string>,
	importPathMapOwnership?: Map<string, Set<string>>,
): void {
	for (const configPath of buildOrder) {
		const commandLine = getParsedCommandLine(configPath);
		if (commandLine === undefined) continue;
		if (!isRbxtsCommandLine(commandLine)) continue;

		const compilerOptions = commandLine.options;
		const outDir = compilerOptions.outDir;
		if (outDir === undefined) continue;

		// Inline guard rather than `getRootDirs(compilerOptions)` — the shared
		// helper asserts and would crash the whole solution build on a project
		// that's missing both fields. Pre-populate must skip such projects
		// (drain handles them later with its own diagnostics).
		const rootDirs = compilerOptions.rootDir ? [compilerOptions.rootDir] : compilerOptions.rootDirs;
		if (rootDirs === undefined || rootDirs.length === 0) continue;
		const rootDir = findAncestorDir([...rootDirs]);

		// `luau` inherits from CLI options unless a per-project rbxts block
		// overrides it (mirrors drainInvalidatedProject's opts resolution).
		const perProjectRbxts = getTsConfigProjectOptions(configPath);
		const luau = perProjectRbxts?.luau ?? entryProjectOptions.luau;

		const buildInfoPath = ts.getTsBuildInfoEmitOutputFilePath(compilerOptions);
		const declaration = compilerOptions.declaration === true;
		const pathTranslator = new PathTranslator(
			rootDir,
			outDir,
			buildInfoPath !== undefined ? path.normalize(buildInfoPath) : undefined,
			declaration,
			luau,
		);

		const projectOwnershipKey = getCanonicalFileName(path.normalize(configPath));
		let owned = importPathMapOwnership?.get(projectOwnershipKey);
		if (importPathMapOwnership !== undefined && owned === undefined) {
			owned = new Set();
			importPathMapOwnership.set(projectOwnershipKey, owned);
		}

		for (const fileName of commandLine.fileNames) {
			if (!isTsOrDtsFile(fileName)) continue;

			const canonical = getCanonicalFileName(path.normalize(fileName));
			if (importPathMap.has(canonical)) continue;

			const importPath = pathTranslator.getImportPath(fileName);
			importPathMap.set(canonical, importPath);
			owned?.add(canonical);

			if (declaration && !isDeclarationFile(fileName)) {
				const dtsPath = pathTranslator.getOutputDeclarationPath(fileName);
				const dtsCanonical = getCanonicalFileName(path.normalize(dtsPath));
				if (!importPathMap.has(dtsCanonical)) {
					importPathMap.set(dtsCanonical, importPath);
					owned?.add(dtsCanonical);
				}
			}
		}
	}
}
