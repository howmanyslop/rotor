import { PathTranslator } from "@roblox-ts/path-translator";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
	buildCopyFilesManifest,
	type CopyFilesManifest,
	tryLoadCopyFilesManifest,
	writeCopyFilesManifest,
} from "./copyFilesManifest.ts";

const TMP_DIR = path.join(__dirname, "__copyFilesManifest_tmp__");
const ROOT_DIR = path.join(TMP_DIR, "src");
const OUT_DIR = path.join(TMP_DIR, "out");
const CACHE_PATH = path.join(OUT_DIR, "rbxts.copyfiles.json");

function makeTranslator() {
	return new PathTranslator(ROOT_DIR, OUT_DIR, undefined, false, true);
}

function buildDefault(overrides: { declaration?: boolean; rootDirs?: ReadonlyArray<string> } = {}) {
	return buildCopyFilesManifest({
		rootDirs: overrides.rootDirs ?? [ROOT_DIR],
		outDir: OUT_DIR,
		declaration: overrides.declaration ?? false,
		key: ROOT_DIR,
		pathTranslator: makeTranslator(),
	});
}

function writeTampered(manifest: CopyFilesManifest, patch: Partial<CopyFilesManifest>): string {
	fs.outputFileSync(CACHE_PATH, JSON.stringify({ ...manifest, ...patch }));
	return CACHE_PATH;
}

describe("copyFilesManifest", () => {
	beforeEach(() => {
		fs.mkdirpSync(ROOT_DIR);
		fs.mkdirpSync(OUT_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
		vi.restoreAllMocks();
	});

	describe("buildCopyFilesManifest", () => {
		it("captures every non-compilable file under rootDirs with its mtime", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "a");
			fs.outputFileSync(path.join(ROOT_DIR, "data.json"), "{}");
			fs.outputFileSync(path.join(ROOT_DIR, "nested", "more.luau"), "b");

			const manifest = buildDefault();

			const sources = manifest.files.map(entry => entry[0]).sort();
			expect(sources).toEqual(
				[
					path.join(ROOT_DIR, "asset.luau"),
					path.join(ROOT_DIR, "data.json"),
					path.join(ROOT_DIR, "nested", "more.luau"),
				].sort(),
			);
			for (const [, , mtime] of manifest.files) {
				expect(mtime).toBeGreaterThan(0);
			}
		});

		it("captures every directory under rootDirs with its mtime", () => {
			fs.mkdirpSync(path.join(ROOT_DIR, "a", "b"));

			const manifest = buildDefault();

			const dirPaths = manifest.dirs.map(entry => entry[0]).sort();
			expect(dirPaths).toEqual([ROOT_DIR, path.join(ROOT_DIR, "a"), path.join(ROOT_DIR, "a", "b")].sort());
		});

		it("excludes .ts and .tsx source files", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "src.ts"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "comp.tsx"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");

			const manifest = buildDefault();

			expect(manifest.files.map(entry => entry[0])).toEqual([path.join(ROOT_DIR, "asset.luau")]);
		});

		it("excludes .d.ts files when declaration is false", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "types.d.ts"), "");

			const manifest = buildDefault({ declaration: false });

			expect(manifest.files).toEqual([]);
		});

		it("includes .d.ts files when declaration is true", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "types.d.ts"), "");

			const manifest = buildDefault({ declaration: true });

			expect(manifest.files.map(entry => entry[0])).toEqual([path.join(ROOT_DIR, "types.d.ts")]);
		});

		it("excludes node_modules subtrees", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "node_modules", "pkg", "init.luau"), "");
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");

			const manifest = buildDefault();

			expect(manifest.files.map(entry => entry[0])).toEqual([path.join(ROOT_DIR, "asset.luau")]);
			expect(manifest.dirs.map(entry => entry[0])).toEqual([ROOT_DIR]);
		});

		it("excludes the outDir when rootDir encompasses it", () => {
			const projectRoot = path.join(TMP_DIR, "project");
			const projectOut = path.join(projectRoot, "out");
			fs.mkdirpSync(projectOut);
			fs.outputFileSync(path.join(projectOut, "stale.luau"), "");
			fs.outputFileSync(path.join(projectRoot, "asset.luau"), "");
			const translator = new PathTranslator(projectRoot, projectOut, undefined, false, true);

			const manifest = buildCopyFilesManifest({
				rootDirs: [projectRoot],
				outDir: projectOut,
				declaration: false,
				key: projectRoot,
				pathTranslator: translator,
			});

			expect(manifest.files.map(entry => entry[0])).toEqual([path.join(projectRoot, "asset.luau")]);
			expect(manifest.dirs.map(entry => entry[0])).not.toContain(projectOut);
		});

		it("records destination paths via pathTranslator so the gate can stat them", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");

			const manifest = buildDefault();

			expect(manifest.files[0]![1]).toBe(path.join(OUT_DIR, "asset.luau"));
		});

		it("records each tracked dest's mtime so external mutation of outDir is detectable", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			fs.outputFileSync(path.join(OUT_DIR, "asset.luau"), "");

			const manifest = buildDefault();

			expect(manifest.files[0]![3]).toBe(fs.statSync(path.join(OUT_DIR, "asset.luau")).mtimeMs);
		});

		it("includes symlinked files matching copyItem's dereference: true behavior", () => {
			const externalFile = path.join(TMP_DIR, "external.luau");
			fs.outputFileSync(externalFile, "");
			const linkPath = path.join(ROOT_DIR, "linked.luau");
			try {
				fs.symlinkSync(externalFile, linkPath, "file");
			} catch {
				// Symlink creation requires admin on Windows. Skip if unavailable.
				return;
			}

			const manifest = buildDefault();

			expect(manifest.files.map(entry => entry[0])).toContain(linkPath);
		});
	});

	describe("tryLoadCopyFilesManifest", () => {
		it("returns undefined when the cache file does not exist", () => {
			expect(tryLoadCopyFilesManifest(path.join(TMP_DIR, "missing.json"), ROOT_DIR, false)).toBeUndefined();
		});

		it("returns undefined when the cache file contains malformed JSON", () => {
			fs.outputFileSync(CACHE_PATH, "{not json");

			expect(tryLoadCopyFilesManifest(CACHE_PATH, ROOT_DIR, false)).toBeUndefined();
		});

		it("returns undefined when the cached cache-format version does not match", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			const manifest = buildDefault();
			writeTampered(manifest, { version: manifest.version + 1 });

			expect(tryLoadCopyFilesManifest(CACHE_PATH, ROOT_DIR, false)).toBeUndefined();
		});

		it("returns undefined when the cached compilerVersion does not match", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			const manifest = buildDefault();
			writeTampered(manifest, { compilerVersion: `${manifest.compilerVersion}-old` });

			expect(tryLoadCopyFilesManifest(CACHE_PATH, ROOT_DIR, false)).toBeUndefined();
		});

		it("returns undefined when the caller's key does not match the cached key", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			const manifest = buildDefault();
			writeCopyFilesManifest(CACHE_PATH, manifest);

			expect(tryLoadCopyFilesManifest(CACHE_PATH, `${ROOT_DIR}.different`, false)).toBeUndefined();
		});

		it("returns undefined when the declaration flag does not match the cached value", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "");
			const manifest = buildDefault({ declaration: false });
			writeCopyFilesManifest(CACHE_PATH, manifest);

			expect(tryLoadCopyFilesManifest(CACHE_PATH, ROOT_DIR, true)).toBeUndefined();
		});

		it("returns a hydrated manifest when version, key, declaration all match (per-entry drift is the gate's job)", () => {
			fs.outputFileSync(path.join(ROOT_DIR, "asset.luau"), "print()");

			const manifest = buildDefault();
			writeCopyFilesManifest(CACHE_PATH, manifest);

			const loaded = tryLoadCopyFilesManifest(CACHE_PATH, ROOT_DIR, false);

			expect(loaded).toBeDefined();
			expect(loaded!.files.map(entry => entry[0])).toEqual([path.join(ROOT_DIR, "asset.luau")]);
		});
	});

	describe("writeCopyFilesManifest", () => {
		it("swallows fs write errors so cache writes never break the build", () => {
			const spy = vi.spyOn(fs, "outputFileSync").mockImplementation(() => {
				throw new Error("disk full");
			});

			expect(() =>
				writeCopyFilesManifest(CACHE_PATH, {
					version: 1,
					compilerVersion: "x",
					key: "k",
					declaration: false,
					files: [],
					dirs: [],
				}),
			).not.toThrow();
			expect(spy).toHaveBeenCalled();
		});
	});
});
