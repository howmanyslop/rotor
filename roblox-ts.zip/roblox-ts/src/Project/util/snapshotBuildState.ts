import type ts from "typescript";

export interface BuildStateSnapshot {
	changedFilePaths: ReadonlySet<string>;
}

/**
 * Reads `BuilderProgram.state.changedFilesSet` into a new immutable Set so the
 * cleanup/copyFiles gate sees the same view of "what changed" regardless of
 * later consumers (e.g. `getChangedFilePaths` clears the live set after walking
 * it). Returns an empty set when the program has no changedFilesSet yet (cold
 * build, before incremental state is rehydrated).
 */
export function snapshotBuildState(program: ts.BuilderProgram): BuildStateSnapshot {
	const set = new Set<string>();
	program.state.changedFilesSet?.forEach((_, fileName) => {
		set.add(fileName);
	});
	return { changedFilePaths: set };
}
