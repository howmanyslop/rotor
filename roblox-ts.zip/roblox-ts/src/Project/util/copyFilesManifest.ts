import type { PathTranslator } from "@roblox-ts/path-translator";
import { type } from "arktype";
import fs from "fs-extra";
import path from "path";

import { COMPILER_VERSION, DTS_EXT, NODE_MODULES } from "../../Shared/constants.ts";
import { safeStatMtime } from "../../Shared/util/safeStatMtime.ts";
import { isCompilableFile } from "./isCompilableFile.ts";

// v2: file entries carry both srcMtimeMs and destMtimeMs so external mutation
// of an output (rollback, manual edit) invalidates the cache. v1 manifests
// drop on read.
const CACHE_VERSION = 2;

export type CopyFilesFileEntry = [src: string, dest: string, srcMtimeMs: number, destMtimeMs: number];
export type CopyFilesDirEntry = [path: string, mtimeMs: number];

export interface CopyFilesManifest {
	version: number;
	compilerVersion: string;
	key: string;
	declaration: boolean;
	files: Array<CopyFilesFileEntry>;
	dirs: Array<CopyFilesDirEntry>;
}

const fileEntrySchema = type(["string", "string", "number", "number"]);
const dirEntrySchema = type(["string", "number"]);

const manifestSchema = type({
	version: "number",
	compilerVersion: "string",
	key: "string",
	declaration: "boolean",
	files: fileEntrySchema.array(),
	dirs: dirEntrySchema.array(),
});

export interface BuildManifestInputs {
	rootDirs: ReadonlyArray<string>;
	outDir: string;
	declaration: boolean;
	key: string;
	pathTranslator: PathTranslator;
}

export function buildCopyFilesManifest(inputs: BuildManifestInputs): CopyFilesManifest {
	const files = new Array<CopyFilesFileEntry>();
	const dirs = new Array<CopyFilesDirEntry>();
	const normalizedOutDir = path.normalize(inputs.outDir);

	const walk = (dir: string): void => {
		const dirMtime = safeStatMtime(dir);
		if (dirMtime === undefined) return;
		dirs.push([dir, dirMtime]);

		let entries: ReadonlyArray<string>;
		try {
			entries = fs.readdirSync(dir);
		} catch {
			return;
		}

		for (const name of entries) {
			const itemPath = path.join(dir, name);
			if (name === NODE_MODULES) continue;
			if (path.normalize(itemPath) === normalizedOutDir) continue;

			// statSync follows symlinks the same way `copyItem`'s
			// `dereference: true` does — without this, a symlinked .luau under
			// rootDir is silently excluded from the manifest and its drift goes
			// undetected even though `copyFiles` copies it.
			let stat: fs.Stats;
			try {
				stat = fs.statSync(itemPath);
			} catch {
				continue;
			}

			if (stat.isDirectory()) {
				walk(itemPath);
				continue;
			}

			if (!stat.isFile()) continue;

			if (itemPath.endsWith(DTS_EXT)) {
				if (!inputs.declaration) continue;
			} else if (isCompilableFile(itemPath)) {
				continue;
			}

			const dest = inputs.pathTranslator.getOutputPath(itemPath);
			const destMtime = safeStatMtime(dest) ?? 0;
			files.push([itemPath, dest, stat.mtimeMs, destMtime]);
		}
	};

	for (const rootDir of inputs.rootDirs) {
		walk(rootDir);
	}

	return {
		version: CACHE_VERSION,
		compilerVersion: COMPILER_VERSION,
		key: inputs.key,
		declaration: inputs.declaration,
		files,
		dirs,
	};
}

export function writeCopyFilesManifest(filePath: string, manifest: CopyFilesManifest): void {
	try {
		fs.outputFileSync(filePath, JSON.stringify(manifest));
	} catch {
		// Best-effort: cache write failures must never break the build.
	}
}

export function tryLoadCopyFilesManifest(
	filePath: string,
	key: string,
	declaration: boolean,
): CopyFilesManifest | undefined {
	let raw: string;
	try {
		raw = fs.readFileSync(filePath, "utf-8");
	} catch {
		return undefined;
	}

	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch {
		return undefined;
	}

	const validated = manifestSchema(parsed);
	if (validated instanceof type.errors) return undefined;
	if (validated.version !== CACHE_VERSION) return undefined;
	if (validated.compilerVersion !== COMPILER_VERSION) return undefined;
	if (validated.key !== key) return undefined;
	if (validated.declaration !== declaration) return undefined;

	// Per-entry drift detection is deliberately the gate's responsibility:
	// it needs to attribute drift to either cleanup (dirs) or copyFiles
	// (files) independently, so the two can be skipped or run on their own.
	return validated;
}
