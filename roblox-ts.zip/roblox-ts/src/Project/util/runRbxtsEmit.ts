import ts from "typescript";

import { profile, profileAsync } from "../../Shared/util/profile.ts";
import type { PendingWrite } from "../functions/writeEmittedFiles.ts";
import { writeEmittedFiles } from "../functions/writeEmittedFiles.ts";

export interface RunRbxtsEmitOptions {
	/**
	 * The BuilderProgram for the project. Its emit is what advances the
	 * incremental `state.changedFilesSet` — without it, the per-source emit
	 * inside the compile thunk operates on a different Program (the
	 * transformer LanguageService) and the BuilderProgram never sees a flush,
	 * so the next run's tsbuildinfo replays every file as pending.
	 */
	readonly program: ts.BuilderProgram;
	/**
	 * The caller-provided Luau emit pass. Runs with `declaration`, `composite`,
	 * `isolatedDeclarations`, and `declarationMap` forcibly disabled on the
	 * inner Program's compilerOptions, and with `emitBuildInfo` stubbed to
	 * `emitSkipped:true`. We restore those in the `finally`. The result's
	 * `emitSkipped` gates the buildinfo rollback policy: success keeps the
	 * fresh tsbuildinfo, failure restores the prior one (or drops, if there
	 * was none).
	 */
	readonly compileThunk: (tsProgram: ts.Program) => Promise<ts.EmitResult>;
	/**
	 * Whether to additionally call `emit` from a SolutionBuilder project
	 * wrapper. When provided, that wrapper's `emit` is used (so the solution
	 * builder advances its own bookkeeping past the BuildStep.Emit gate).
	 * Otherwise we call `program.emit()` directly.
	 */
	readonly solutionEmit?: (
		writeFile: (fileName: string, text: string, writeByteOrderMark: boolean) => void,
	) => ts.EmitResult | undefined;
}

export interface RunRbxtsEmitResult {
	/** The result returned by the caller's compile thunk. */
	readonly compileResult: ts.EmitResult;
	/** Diagnostics emitted during the BuilderProgram pre-emit pass. */
	readonly preEmitDiagnostics: ReadonlyArray<ts.Diagnostic>;
	/** `true` when the compile thunk reported `emitSkipped:false`. */
	readonly emittedSuccessfully: boolean;
}

const BUILDINFO_RE = /\.tsbuildinfo$/;
const DISCARDABLE_JS_OUTPUT_RE = /\.(?:cjs|mjs|js|jsx)(?:\.map)?$/;
const MAP_EXTENSION = ".map";
const FORCE_ASYNC_DECLARATION_FLUSH_SYNC_CUTOFF = 0;

type AsyncResult = { ok: true } | { ok: false; error: unknown };

interface BufferedBuildInfo {
	readonly path: string;
	readonly text: string;
	readonly writeByteOrderMark: boolean;
}

interface BuilderOutputWriteQueue {
	readonly writeFile: (fileName: string, text: string, writeByteOrderMark: boolean) => void;
	readonly getDeclarationStats: () => { count: number; bytes: number };
	readonly beginDeclarationFlush: () => PendingDeclarationFlush;
	readonly takeBuildInfo: () => BufferedBuildInfo | undefined;
}

interface PendingDeclarationFlush {
	readonly wait: () => Promise<void>;
}

function withBom(text: string, writeByteOrderMark: boolean): string {
	return writeByteOrderMark ? "\uFEFF" + text : text;
}

function isDeclarationOutput(fileName: string): boolean {
	if (ts.isDeclarationFileName(fileName)) return true;
	if (!fileName.endsWith(MAP_EXTENSION)) return false;
	return ts.isDeclarationFileName(fileName.slice(0, -MAP_EXTENSION.length));
}

function createBuilderOutputWriteQueue(): BuilderOutputWriteQueue {
	const declarationWrites = new Array<PendingWrite>();
	let declarationBytes = 0;
	let declarationFlushStarted = false;
	let bufferedBuildInfo: BufferedBuildInfo | undefined;

	function writeFile(fileName: string, text: string, writeByteOrderMark: boolean): void {
		if (BUILDINFO_RE.test(fileName)) {
			// Buffer the new tsbuildinfo instead of writing it. The prior one
			// stays untouched on disk so Flamework's dirty-environment guard sees
			// a settled state during compileThunk and a Ctrl-C mid-compile leaves
			// an incremental-ready buildinfo. Flushed only on a successful emit.
			bufferedBuildInfo = { path: fileName, text, writeByteOrderMark };
		} else if (isDeclarationOutput(fileName)) {
			const data = withBom(text, writeByteOrderMark);
			declarationWrites.push({ path: fileName, data });
			declarationBytes += Buffer.byteLength(data);
		} else if (process.env.RBXTSC_PROFILE === "1" && !DISCARDABLE_JS_OUTPUT_RE.test(fileName)) {
			process.stderr.write(`[profile] runRbxtsEmit ignoredBuilderOutput path=${fileName}\n`);
		}
	}

	function getDeclarationStats() {
		return { count: declarationWrites.length, bytes: declarationBytes };
	}

	function beginDeclarationFlush(): PendingDeclarationFlush {
		if (declarationFlushStarted) throw new Error("beginDeclarationFlush called more than once");
		declarationFlushStarted = true;

		const resultPromise = profileAsync("runRbxtsEmit flushBufferedDeclarations", () =>
			writeEmittedFiles(declarationWrites, {
				writeOnlyChanged: false,
				// Always take the async path so declaration writes overlap compileThunk.
				syncCutoff: FORCE_ASYNC_DECLARATION_FLUSH_SYNC_CUTOFF,
				useCaseSensitiveFileNames: ts.sys.useCaseSensitiveFileNames,
			}),
		).then<AsyncResult, AsyncResult>(
			() => ({ ok: true }),
			error => ({ ok: false, error }),
		);

		return {
			async wait() {
				const result = await resultPromise;
				if (!result.ok) throw result.error;
			},
		};
	}

	function takeBuildInfo(): BufferedBuildInfo | undefined {
		// Consume the buffer so a second call can't flush the same tsbuildinfo
		// twice or observe stale state — `take` transfers ownership to the caller.
		const buildInfo = bufferedBuildInfo;
		bufferedBuildInfo = undefined;
		return buildInfo;
	}

	return { writeFile, getDeclarationStats, beginDeclarationFlush, takeBuildInfo };
}

/**
 * Runs the rbxts emit pipeline for one project:
 *
 *   BuilderProgram.emit (buffers .d.ts + tsbuildinfo, advances changedFilesSet)
 *   → flush declarations while caller's Luau emit thunk runs
 *   → restore options, then flush the buffered tsbuildinfo on success
 *
 * The new tsbuildinfo is buffered rather than written: the prior one stays on
 * disk untouched through the whole compile. That keeps Flamework's
 * dirty-environment guard satisfied (prior tsbuildinfo + prior `flamework.build`
 * read as a settled state) and makes a Ctrl-C mid-compile leave an
 * incremental-ready buildinfo instead of nothing. On success the buffer is
 * flushed (overwriting the prior); on failure/skip nothing is written, so the
 * prior (or absent) tsbuildinfo is already the correct state.
 *
 * This is the shared shape used by `build.ts` (single-project) and
 * `buildSolution.ts` (--build). Keeping the BuilderProgram emit and the Luau
 * emit in lockstep is the only way the next run's incremental state matches
 * what just landed on disk.
 */
export async function runRbxtsEmit(options: RunRbxtsEmitOptions): Promise<RunRbxtsEmitResult> {
	const { program, compileThunk, solutionEmit } = options;
	const tsProgram = program.getProgram();
	const compilerOptions = program.getCompilerOptions();

	const builderOutputWrites = createBuilderOutputWriteQueue();

	const emitResult = profile("runRbxtsEmit builderProgramEmit", () =>
		solutionEmit
			? solutionEmit(builderOutputWrites.writeFile)
			: program.emit(undefined, builderOutputWrites.writeFile),
	);
	const preEmitDiagnostics = emitResult?.diagnostics ?? [];
	const declarationStats = builderOutputWrites.getDeclarationStats();

	if (process.env.RBXTSC_PROFILE === "1" && declarationStats.count > 0) {
		process.stderr.write(
			`[profile] runRbxtsEmit bufferedDeclarations count=${declarationStats.count} ` +
				`bytes=${declarationStats.bytes}\n`,
		);
	}

	const declarationFlush = builderOutputWrites.beginDeclarationFlush();

	const savedDeclaration = compilerOptions.declaration;
	const savedComposite = compilerOptions.composite;
	const savedIsolatedDeclarations = compilerOptions.isolatedDeclarations;
	const savedDeclarationMap = compilerOptions.declarationMap;
	const savedEmitBuildInfo = tsProgram.emitBuildInfo;
	compilerOptions.declaration = false;
	compilerOptions.composite = false;
	compilerOptions.isolatedDeclarations = false;
	compilerOptions.declarationMap = false;
	tsProgram.emitBuildInfo = () => ({ diagnostics: [], emittedFiles: undefined, emitSkipped: true });

	let compileResult: ts.EmitResult | undefined;
	let emittedSuccessfully = false;
	try {
		let compileFailed = false;
		let compileError: unknown;
		let declarationFlushFailed = false;
		let declarationFlushError: unknown;

		try {
			compileResult = await compileThunk(tsProgram);
		} catch (error) {
			compileFailed = true;
			compileError = error;
		}

		try {
			await declarationFlush.wait();
		} catch (error) {
			declarationFlushFailed = true;
			declarationFlushError = error;
		}

		if (compileFailed) throw compileError;
		if (declarationFlushFailed) throw declarationFlushError;
		if (compileResult === undefined) throw new Error("compileThunk did not return an emit result");

		// `emitSkipped:true` covers both the pre-emit-diagnostic short-circuit
		// and the early `emitResultFailure` returns inside compileFiles. The
		// new tsbuildinfo would lie about completeness if restored in either.
		emittedSuccessfully = !compileResult.emitSkipped;
	} finally {
		compilerOptions.declaration = savedDeclaration;
		compilerOptions.composite = savedComposite;
		compilerOptions.isolatedDeclarations = savedIsolatedDeclarations;
		compilerOptions.declarationMap = savedDeclarationMap;
		tsProgram.emitBuildInfo = savedEmitBuildInfo;

		// Flush the buffered tsbuildinfo only on success. On failure/skip the
		// buffer is dropped, leaving the prior (or absent) tsbuildinfo on disk —
		// the next run redoes emit rather than skipping compileFiles over partial
		// state, and an interrupt before this point never touched disk.
		const buildInfo = emittedSuccessfully ? builderOutputWrites.takeBuildInfo() : undefined;
		if (buildInfo) {
			ts.sys.writeFile(buildInfo.path, buildInfo.text, buildInfo.writeByteOrderMark);
		}
	}

	return { compileResult, preEmitDiagnostics, emittedSuccessfully };
}
