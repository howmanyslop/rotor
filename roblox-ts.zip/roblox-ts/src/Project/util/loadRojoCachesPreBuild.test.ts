import { RojoResolver } from "@isentinel/rojo-utils";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { RojoResolverCache } from "../classes/RojoResolverCache.ts";
import { loadRojoCachesPreBuild } from "./loadRojoCachesPreBuild.ts";

const ROJO_CONFIG = path.resolve(__dirname, "../../../tests/default.project.json");
const TMP_DIR = path.join(__dirname, "__loadRojoCachesPreBuild_tmp__");

describe("loadRojoCachesPreBuild", () => {
	beforeEach(() => {
		fs.mkdirpSync(TMP_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
	});

	it("persistAll is a no-op when both caches were L2 hits on cold cache instances", () => {
		const outDir = path.join(TMP_DIR, "out");
		const nodeModulesPath = path.join(TMP_DIR, "node_modules");
		fs.mkdirpSync(outDir);
		fs.mkdirpSync(nodeModulesPath);
		const typeRoot = path.resolve(__dirname, "../../../tests/node_modules/@rbxts");

		// Warm pass: seed both caches.
		const warmCache = new RojoResolverCache();
		const warm = loadRojoCachesPreBuild(warmCache, {
			rojoConfigPath: ROJO_CONFIG,
			typeRoots: [typeRoot],
			outDir,
			nodeModulesPath,
		});
		warm.persistAll();
		const rojoCachePath = path.join(outDir, "rbxts.rojocache.json");
		expect(fs.existsSync(rojoCachePath)).toBe(true);

		// Cold cache instance — both lookups should hit L2 and the persistAll
		// should be a no-op (so we can delete the L2 file beforehand and confirm
		// it doesn't get re-created).
		const coldCache = new RojoResolverCache();
		const cold = loadRojoCachesPreBuild(coldCache, {
			rojoConfigPath: ROJO_CONFIG,
			typeRoots: [typeRoot],
			outDir,
			nodeModulesPath,
		});
		expect(cold.rojoCacheEntry).toBeDefined();
		expect(cold.typeRootsEntry.resolvers.length).toBe(1);
		// Remove the per-project cache file then call persistAll — if it's truly a
		// no-op the file stays missing.
		fs.removeSync(rojoCachePath);
		cold.persistAll();
		expect(fs.existsSync(rojoCachePath)).toBe(false);
	});

	it("places per-project cache at outDir/rbxts.rojocache.json and resolves typeRoots cache", () => {
		const outDir = path.join(TMP_DIR, "out");
		const nodeModulesPath = path.join(TMP_DIR, "node_modules");
		fs.mkdirpSync(outDir);
		fs.mkdirpSync(nodeModulesPath);
		const typeRoot = path.resolve(__dirname, "../../../tests/node_modules/@rbxts");
		const cache = new RojoResolverCache();

		const result = loadRojoCachesPreBuild(cache, {
			rojoConfigPath: ROJO_CONFIG,
			typeRoots: [typeRoot],
			outDir,
			nodeModulesPath,
		});

		expect(result.rojoCacheEntry).toBeDefined();
		expect(result.rojoCacheEntry!.resolver).toBeInstanceOf(RojoResolver);
		expect(result.typeRootsEntry.resolvers.length).toBe(1);

		// persistAll writes the per-project file at the conventional path.
		result.persistAll();
		expect(fs.existsSync(path.join(outDir, "rbxts.rojocache.json"))).toBe(true);
	});
});
