import type { PathTranslator } from "@roblox-ts/path-translator";
import path from "path";

import { safeStatMtime } from "../../Shared/util/safeStatMtime.ts";
import {
	buildCopyFilesManifest,
	type CopyFilesDirEntry,
	type CopyFilesFileEntry,
	type CopyFilesManifest,
	tryLoadCopyFilesManifest,
	writeCopyFilesManifest,
} from "./copyFilesManifest.ts";
import { type BuildStateSnapshot } from "./snapshotBuildState.ts";

export const COPY_FILES_CACHE_FILENAME = "rbxts.copyfiles.json";

// The manifest key folds in outDir + the normalised, sorted rootDirs set.
// Without rootDirs, a tsconfig reconfig that moves sources between rootDirs
// (changing every dest path the cached manifest stored) leaves the cache
// validly mapped to the OLD destinations.
function buildManifestKey(outDir: string, rootDirs: ReadonlyArray<string>): string {
	const normalised = rootDirs.map(r => path.normalize(r)).sort();
	return `${outDir}|${normalised.join(",")}`;
}

export interface GateInputs {
	rootDirs: ReadonlyArray<string>;
	outDir: string;
	declaration: boolean;
	pathTranslator: PathTranslator;
	snapshot: BuildStateSnapshot;
}

export interface GateOutputs {
	skipCleanup: boolean;
	skipCopyFiles: boolean;
	persist: () => void;
}

function dirsEqual(a: ReadonlyArray<CopyFilesDirEntry>, b: ReadonlyArray<CopyFilesDirEntry>): boolean {
	if (a.length !== b.length) return false;
	const lookup = new Map(a.map(([p, m]) => [p, m] as const));
	for (const [p, m] of b) {
		if (lookup.get(p) !== m) return false;
	}
	return true;
}

function filesEqual(a: ReadonlyArray<CopyFilesFileEntry>, b: ReadonlyArray<CopyFilesFileEntry>): boolean {
	if (a.length !== b.length) return false;
	const lookup = new Map(a.map(([src, , m]) => [src, m] as const));
	for (const [src, , m] of b) {
		if (lookup.get(src) !== m) return false;
	}
	return true;
}

function destsValid(files: ReadonlyArray<CopyFilesFileEntry>): boolean {
	for (const [, dest, , expectedDestMtime] of files) {
		const actual = safeStatMtime(dest);
		if (actual === undefined) return false;
		if (actual !== expectedDestMtime) return false;
	}
	return true;
}

/**
 * Stat-only fingerprint check: confirms every cached dir + file + dest still
 * matches the previous run, without doing a readdir walk. This is the warm
 * no-op path. Falls through to the slow path (walk + per-entry compare) when
 * anything drifts so cleanup and copyFiles can be skipped independently.
 *
 * Dir-mtime drift detects added/removed entries (POSIX & NTFS bump parent dir
 * mtime on entry create/delete/rename), so the fast path correctly catches
 * "new .luau added under rootDir" without needing to enumerate the entries.
 */
function fastValidate(cached: CopyFilesManifest, snapshot: BuildStateSnapshot): boolean {
	if (snapshot.changedFilePaths.size > 0) return false;
	for (const [dirPath, expectedMtime] of cached.dirs) {
		const actual = safeStatMtime(dirPath);
		if (actual === undefined || actual !== expectedMtime) return false;
	}
	for (const [src, dest, expectedSrcMtime, expectedDestMtime] of cached.files) {
		const srcMtime = safeStatMtime(src);
		if (srcMtime === undefined || srcMtime !== expectedSrcMtime) return false;
		const destMtime = safeStatMtime(dest);
		if (destMtime === undefined || destMtime !== expectedDestMtime) return false;
	}
	return true;
}

/**
 * Returns whether `cleanup` and `copyFiles` can be skipped on this build, plus
 * a callback to persist the current state to disk for the next run.
 *
 * Must run BEFORE cleanup/copyFiles since the captured mtimes drive the next
 * run's gate. The persist callback must run AFTER the rest of the build
 * settles (multi-project --build flow defers it to the end of the solution
 * loop).
 */
export function loadCopyFilesGatePreBuild(inputs: GateInputs): GateOutputs {
	const cachePath = path.join(inputs.outDir, COPY_FILES_CACHE_FILENAME);
	const key = buildManifestKey(inputs.outDir, inputs.rootDirs);

	const cached = tryLoadCopyFilesManifest(cachePath, key, inputs.declaration);

	if (cached !== undefined && fastValidate(cached, inputs.snapshot)) {
		// State hasn't changed, no need to rewalk on persist.
		return {
			skipCleanup: true,
			skipCopyFiles: true,
			persist: () => writeCopyFilesManifest(cachePath, cached),
		};
	}

	// Slow path: walk rootDirs to attribute drift to cleanup vs copyFiles
	// independently. The walk runs ONCE, pre-build. Persist freezes those
	// src/dir mtimes (a mid-build source edit must NOT be absorbed into the
	// manifest, or the next run would skip copying the new content) and only
	// re-stats dest mtimes (cleanup/copyFiles may have created/mutated them).
	const current = buildCopyFilesManifest({
		rootDirs: inputs.rootDirs,
		outDir: inputs.outDir,
		declaration: inputs.declaration,
		key,
		pathTranslator: inputs.pathTranslator,
	});
	const persist = () => {
		const refreshedFiles: Array<CopyFilesFileEntry> = current.files.map(([src, dest, srcMtime]) => [
			src,
			dest,
			srcMtime,
			safeStatMtime(dest) ?? 0,
		]);
		writeCopyFilesManifest(cachePath, { ...current, files: refreshedFiles });
	};

	if (cached === undefined) {
		return { skipCleanup: false, skipCopyFiles: false, persist };
	}

	const dirsMatch = dirsEqual(current.dirs, cached.dirs);
	const filesMatch = filesEqual(current.files, cached.files);
	// cleanup removes orphans in outDir whenever a non-.ts source disappeared
	// or a tracked dest was externally mutated. Require BOTH dir-set stability
	// AND file-set stability so neither path can be skipped on partial drift.
	//
	// KNOWN LIMITATION: a file dropped into outDir by an EXTERNAL tool (with
	// no corresponding source) is invisible to the gate — sources are
	// unchanged, every tracked dest still matches. cleanup is skipped and the
	// rogue file survives until something else drifts. This is the inherent
	// tradeoff of skipping the outDir walk; users with this scenario should
	// rm -rf outDir to force a full cleanup.
	const skipCleanup =
		dirsMatch && filesMatch && destsValid(cached.files) && inputs.snapshot.changedFilePaths.size === 0;
	const skipCopyFiles = filesMatch && destsValid(cached.files);

	return { skipCleanup, skipCopyFiles, persist };
}
