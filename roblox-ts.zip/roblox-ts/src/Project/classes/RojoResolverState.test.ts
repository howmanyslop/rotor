import { RojoResolver } from "@isentinel/rojo-utils";
import path from "path";
import { describe, expect, it } from "vitest";

const ROJO_CONFIG = path.resolve(__dirname, "../../../tests/default.project.json");
const PKG_BASE = path.resolve(__dirname, "../../../tests/node_modules/@rbxts");

describe("RojoResolver getState / fromState round-trip", () => {
	it("preserves filePathToRbxPathMap, partitions, walkedDirs, walkedConfigFiles", () => {
		const original = RojoResolver.fromPath(ROJO_CONFIG);
		const state = original.getState();
		const restored = RojoResolver.fromState(state);

		expect(restored.isGame).toBe(original.isGame);
		expect(restored.getWarnings()).toEqual(original.getWarnings());
		expect([...restored.walkedDirectories].sort()).toEqual([...original.walkedDirectories].sort());
		expect([...restored.walkedConfigFiles].sort()).toEqual([...original.walkedConfigFiles].sort());

		// walkedDirs / walkedConfigFiles must be non-empty so the cache manifest
		// has something to mtime-check on disk; an empty manifest would mean the
		// cache is unconditionally valid which would corrupt on rojo edits.
		expect(original.walkedDirectories.size).toBeGreaterThan(0);
		expect(original.walkedConfigFiles.size).toBeGreaterThan(0);
	});

	it("restored resolver resolves rbxPath identically to the original for every known file", () => {
		const original = RojoResolver.fromPath(ROJO_CONFIG);
		const restored = RojoResolver.fromState(original.getState());

		const state = original.getState();
		for (const [filePath] of state.filePathToRbxPathMap) {
			expect(restored.getRbxPathFromFilePath(filePath)).toEqual(original.getRbxPathFromFilePath(filePath));
		}
	});

	it("synthetic resolver round-trips with populated walkedDirs", () => {
		const original = RojoResolver.synthetic(PKG_BASE);
		const restored = RojoResolver.fromState(original.getState());

		expect(restored.isGame).toBe(false);
		expect([...restored.walkedDirectories].sort()).toEqual([...original.walkedDirectories].sort());
		expect(original.walkedDirectories.size).toBeGreaterThan(0);
	});
});
