import type { RojoResolverState } from "@isentinel/rojo-utils";
import { RojoResolver } from "@isentinel/rojo-utils";
import { type } from "arktype";
import crypto from "crypto";
import fs from "fs-extra";
import path from "path";

import { COMPILER_VERSION } from "../../Shared/constants.ts";
import {
	manifestEntrySchema,
	rojoResolverStateSchema,
	sentinelSchema,
	serialiseRojoResolver,
	tryLoadResolver,
	writeCacheFile,
} from "../../Shared/util/rojoCacheFile.ts";
import { safeStatMtime } from "../../Shared/util/safeStatMtime.ts";

const SYNTHETIC_CACHE_VERSION = 1;

// Synthetic-batch cache file: one document holds all N typeRoot resolvers so a
// single hit restores the whole batch. Key is a hash of the sorted basePaths so
// order is irrelevant but membership is not.
const syntheticCacheFileSchema = type({
	version: "number",
	compilerVersion: "string",
	key: "string",
	resolvers: type({
		basePath: "string",
		state: rojoResolverStateSchema,
	}).array(),
	manifest: manifestEntrySchema.array(),
	"sentinel?": sentinelSchema,
});

function hashKey(input: string): string {
	return crypto.createHash("sha256").update(input).digest("hex").slice(0, 16);
}

interface ResolverFactory {
	fromPath: (configPath: string) => RojoResolver;
	synthetic: (basePath: string) => RojoResolver;
}

interface CachedFromPath {
	resolver: RojoResolver;
	mtimeMs: number;
}

interface SyntheticCacheFile {
	version: number;
	compilerVersion: string;
	key: string;
	resolvers: Array<{ basePath: string; state: RojoResolverState }>;
	manifest: Array<[string, number]>;
	sentinel?: { path: string; mtimeMs: number };
}

function normalizeKey(p: string): string {
	return path.normalize(p.replace(/\\/g, "/"));
}

export class RojoResolverCache {
	private fromPathCache = new Map<string, CachedFromPath>();
	private syntheticCache = new Map<string, RojoResolver>();
	private resolverFactory: ResolverFactory;
	private statFile: (p: string) => { mtimeMs: number };

	constructor(
		resolverFactory: ResolverFactory = {
			fromPath: RojoResolver.fromPath,
			synthetic: RojoResolver.synthetic,
		},
		statFile: (p: string) => { mtimeMs: number } = p => fs.statSync(p),
	) {
		this.resolverFactory = resolverFactory;
		this.statFile = statFile;
	}

	getFromPath(configPath: string): RojoResolver {
		const key = normalizeKey(configPath);
		const cached = this.fromPathCache.get(key);

		let mtimeMs: number | undefined;
		try {
			mtimeMs = this.statFile(key).mtimeMs;
		} catch {
			// file gone — treat as cache miss
		}

		if (cached && mtimeMs !== undefined && cached.mtimeMs === mtimeMs) {
			return cached.resolver;
		}

		const resolver = this.resolverFactory.fromPath(configPath);
		this.fromPathCache.set(key, { resolver, mtimeMs: mtimeMs ?? -1 });
		return resolver;
	}

	getSynthetic(basePath: string): RojoResolver {
		const key = normalizeKey(basePath);
		let resolver = this.syntheticCache.get(key);
		if (!resolver) {
			resolver = this.resolverFactory.synthetic(basePath);
			this.syntheticCache.set(key, resolver);
		}
		return resolver;
	}

	/**
	 * Two-tier lookup: in-memory L1 first, then on-disk L2 via tryLoadResolver.
	 * Returns the resolver plus a persist callback. The caller MUST invoke the
	 * callback AFTER all build outputs settle — otherwise dir mtimes captured in
	 * the manifest get bumped by intervening file writes and the cache fails to
	 * validate on the next run.
	 */
	getFromPathWithDiskCache(
		configPath: string,
		cacheFilePath: string,
	): { resolver: RojoResolver; persist: () => void } {
		const key = normalizeKey(configPath);
		const cached = this.fromPathCache.get(key);
		const configMtime = safeStatMtime(key);
		const noop = () => {};

		// Storing the real mtime — not -1 — means a subsequent getFromPath call
		// also hits L1 instead of re-walking. compileFiles uses getFromPath; the
		// pre-build loader uses getFromPathWithDiskCache; both share L1.
		if (cached !== undefined && configMtime !== undefined && cached.mtimeMs === configMtime) {
			return { resolver: cached.resolver, persist: noop };
		}

		const fromDisk = tryLoadResolver(cacheFilePath, key);
		if (fromDisk !== undefined) {
			this.fromPathCache.set(key, { resolver: fromDisk, mtimeMs: configMtime ?? -1 });
			return { resolver: fromDisk, persist: noop };
		}

		const resolver = this.resolverFactory.fromPath(configPath);
		this.fromPathCache.set(key, { resolver, mtimeMs: configMtime ?? -1 });
		return {
			resolver,
			persist: () => writeCacheFile(cacheFilePath, serialiseRojoResolver(resolver, key)),
		};
	}

	/**
	 * Batched synthetic resolution + disk cache. The whole batch is stored in a
	 * single cache file so one validation pass restores N resolvers. Cache key
	 * is order-invariant over basePaths (sorted before hashing) but a membership
	 * change invalidates.
	 */
	getSyntheticBatchWithDiskCache(
		basePaths: ReadonlyArray<string>,
		cacheFilePath: string,
		sentinelPath?: string,
	): { resolvers: ReadonlyArray<RojoResolver>; persist: () => void } {
		const normalizedBases = basePaths.map(normalizeKey);
		const cacheKey = hashKey(normalizedBases.slice().sort().join("\n"));
		const noop = () => {};

		const allHitInMemory = normalizedBases.every(base => this.syntheticCache.has(base));
		if (allHitInMemory) {
			return {
				resolvers: normalizedBases.map(base => this.syntheticCache.get(base)!),
				persist: noop,
			};
		}

		const fromDisk = this.tryLoadSyntheticBatch(cacheFilePath, cacheKey, normalizedBases);
		if (fromDisk !== undefined) {
			for (let i = 0; i < normalizedBases.length; i++) {
				this.syntheticCache.set(normalizedBases[i], fromDisk[i]);
			}
			return { resolvers: fromDisk, persist: noop };
		}

		const resolvers = basePaths.map(base => this.getSynthetic(base));
		return {
			resolvers,
			persist: () => this.writeSyntheticBatch(cacheFilePath, cacheKey, basePaths, resolvers, sentinelPath),
		};
	}

	private tryLoadSyntheticBatch(
		cacheFilePath: string,
		expectedKey: string,
		expectedBases: ReadonlyArray<string>,
	): Array<RojoResolver> | undefined {
		let raw: string;
		try {
			raw = fs.readFileSync(cacheFilePath, "utf-8");
		} catch {
			return undefined;
		}

		let parsed: unknown;
		try {
			parsed = JSON.parse(raw);
		} catch {
			return undefined;
		}

		const validated = syntheticCacheFileSchema(parsed);
		if (validated instanceof type.errors) return undefined;
		if (validated.version !== SYNTHETIC_CACHE_VERSION) return undefined;
		if (validated.compilerVersion !== COMPILER_VERSION) return undefined;
		if (validated.key !== expectedKey) return undefined;
		if (validated.resolvers.length !== expectedBases.length) return undefined;
		// Look up resolvers by basePath so caller order doesn't matter. The key
		// hash already covers membership; here we just need to map each expected
		// base back to its stored state.
		const byBase = new Map<string, RojoResolverState>();
		for (const entry of validated.resolvers) {
			byBase.set(normalizeKey(entry.basePath), entry.state);
		}
		const orderedStates = new Array<RojoResolverState>();
		for (const base of expectedBases) {
			const state = byBase.get(base);
			if (state === undefined) return undefined;
			orderedStates.push(state);
		}

		if (validated.sentinel !== undefined) {
			const sentinelMtime = safeStatMtime(validated.sentinel.path);
			if (sentinelMtime !== undefined && sentinelMtime === validated.sentinel.mtimeMs) {
				return orderedStates.map(state => RojoResolver.fromState(state));
			}
		}

		for (const [filePath, expected] of validated.manifest) {
			const actual = safeStatMtime(filePath);
			if (actual === undefined || actual !== expected) return undefined;
		}

		return orderedStates.map(state => RojoResolver.fromState(state));
	}

	private writeSyntheticBatch(
		cacheFilePath: string,
		key: string,
		basePaths: ReadonlyArray<string>,
		resolvers: ReadonlyArray<RojoResolver>,
		sentinelPath: string | undefined,
	): void {
		const manifestSet = new Set<string>();
		for (const resolver of resolvers) {
			for (const dir of resolver.walkedDirectories) manifestSet.add(dir);
			for (const file of resolver.walkedConfigFiles) manifestSet.add(file);
		}
		const manifest = new Array<[string, number]>();
		for (const filePath of manifestSet) {
			const mtime = safeStatMtime(filePath);
			if (mtime === undefined) continue;
			manifest.push([filePath, mtime]);
		}

		const cache: SyntheticCacheFile = {
			version: SYNTHETIC_CACHE_VERSION,
			compilerVersion: COMPILER_VERSION,
			key,
			resolvers: basePaths.map((basePath, i) => ({
				basePath,
				state: resolvers[i].getState(),
			})),
			manifest,
		};
		if (sentinelPath !== undefined) {
			const mtimeMs = safeStatMtime(sentinelPath);
			if (mtimeMs !== undefined) cache.sentinel = { path: sentinelPath, mtimeMs };
		}

		try {
			fs.outputFileSync(cacheFilePath, JSON.stringify(cache));
		} catch {
			// Best-effort.
		}
	}

	invalidate(configPath: string): void {
		this.fromPathCache.delete(normalizeKey(configPath));
	}

	invalidateAll(): void {
		this.fromPathCache.clear();
	}

	invalidateSynthetic(basePath: string): void {
		this.syntheticCache.delete(normalizeKey(basePath));
	}

	invalidateAllSynthetic(): void {
		this.syntheticCache.clear();
	}
}

export const rojoResolverCache = new RojoResolverCache();
