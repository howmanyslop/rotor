import { RojoResolver } from "@isentinel/rojo-utils";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { RojoResolverCache } from "./RojoResolverCache.ts";

type FromPathFn = (configPath: string) => RojoResolver;
type SyntheticFn = (basePath: string) => RojoResolver;
type StatFileFn = (p: string) => { mtimeMs: number };

function createMockResolver(id: string) {
	return { __id: id } as unknown as RojoResolver;
}

function createCache(options: { fromPath?: FromPathFn; synthetic?: SyntheticFn; statFile?: StatFileFn }) {
	const fromPath = options.fromPath ?? vi.fn<FromPathFn>(() => createMockResolver("default"));
	const synthetic = options.synthetic ?? vi.fn<SyntheticFn>(() => createMockResolver("synthetic-default"));
	const statFile = options.statFile ?? vi.fn<StatFileFn>(() => ({ mtimeMs: 1000 }));
	return {
		cache: new RojoResolverCache({ fromPath, synthetic }, statFile),
		fromPath,
		synthetic,
		statFile,
	};
}

describe("RojoResolverCache", () => {
	describe("getFromPath", () => {
		it("creates resolver on first call", () => {
			const resolver = createMockResolver("A");
			const { cache, fromPath } = createCache({ fromPath: vi.fn<FromPathFn>(() => resolver) });

			const result = cache.getFromPath("/project/default.project.json");

			expect(fromPath).toHaveBeenCalledOnce();
			expect(fromPath).toHaveBeenCalledWith("/project/default.project.json");
			expect(result).toBe(resolver);
		});

		it("returns cached resolver when mtime unchanged", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("/config.json");
			cache.getFromPath("/config.json");

			expect(fromPath).toHaveBeenCalledOnce();
		});

		it("recreates resolver when mtime changes", () => {
			const resolverA = createMockResolver("A");
			const resolverB = createMockResolver("B");
			let callCount = 0;
			const fromPath = vi.fn<FromPathFn>(() => (callCount++ === 0 ? resolverA : resolverB));
			let mtime = 1000;
			const statFile = vi.fn<StatFileFn>(() => ({ mtimeMs: mtime }));
			const { cache } = createCache({ fromPath, statFile });

			const first = cache.getFromPath("/config.json");
			mtime = 2000;
			const second = cache.getFromPath("/config.json");

			expect(first).toBe(resolverA);
			expect(second).toBe(resolverB);
			expect(fromPath).toHaveBeenCalledTimes(2);
		});

		it("normalizes path separators", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("/project/sub/../default.project.json");
			cache.getFromPath("/project/default.project.json");

			expect(fromPath).toHaveBeenCalledOnce();
		});

		it("treats backslashes and forward slashes as equivalent", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("C:\\project\\default.project.json");
			cache.getFromPath("C:/project/default.project.json");

			expect(fromPath).toHaveBeenCalledOnce();
		});

		it("treats stat failure as cache miss", () => {
			const resolverA = createMockResolver("A");
			const resolverB = createMockResolver("B");
			let callCount = 0;
			const fromPath = vi.fn<FromPathFn>(() => (callCount++ === 0 ? resolverA : resolverB));
			let shouldThrow = false;
			const statFile = vi.fn<StatFileFn>(() => {
				if (shouldThrow) throw Object.assign(new Error("ENOENT"), { code: "ENOENT" });
				return { mtimeMs: 1000 };
			});
			const { cache } = createCache({ fromPath, statFile });

			cache.getFromPath("/config.json");
			shouldThrow = true;
			const result = cache.getFromPath("/config.json");

			expect(result).toBe(resolverB);
			expect(fromPath).toHaveBeenCalledTimes(2);
		});
	});

	describe("getSynthetic", () => {
		it("creates resolver on first call", () => {
			const resolver = createMockResolver("S");
			const { cache, synthetic } = createCache({ synthetic: vi.fn<SyntheticFn>(() => resolver) });

			const result = cache.getSynthetic("/out");

			expect(synthetic).toHaveBeenCalledOnce();
			expect(synthetic).toHaveBeenCalledWith("/out");
			expect(result).toBe(resolver);
		});

		it("returns cached resolver on subsequent calls", () => {
			const { cache, synthetic } = createCache({});

			cache.getSynthetic("/out");
			cache.getSynthetic("/out");

			expect(synthetic).toHaveBeenCalledOnce();
		});
	});

	describe("invalidate", () => {
		it("forces re-creation on next getFromPath", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("/config.json");
			cache.invalidate("/config.json");
			cache.getFromPath("/config.json");

			expect(fromPath).toHaveBeenCalledTimes(2);
		});
	});

	describe("invalidateAll", () => {
		it("clears all fromPath entries", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("/a.json");
			cache.getFromPath("/b.json");
			cache.invalidateAll();
			cache.getFromPath("/a.json");
			cache.getFromPath("/b.json");

			expect(fromPath).toHaveBeenCalledTimes(4);
		});

		it("does not clear synthetic cache", () => {
			const { cache, synthetic } = createCache({});

			cache.getSynthetic("/out");
			cache.invalidateAll();
			cache.getSynthetic("/out");

			expect(synthetic).toHaveBeenCalledOnce();
		});
	});

	describe("invalidateSynthetic", () => {
		it("forces re-creation on next getSynthetic for that basePath only", () => {
			const { cache, synthetic } = createCache({});

			cache.getSynthetic("/a");
			cache.getSynthetic("/b");
			cache.invalidateSynthetic("/a");
			cache.getSynthetic("/a");
			cache.getSynthetic("/b");

			// /a: re-walked (2 calls); /b: hit (1 call).
			expect(synthetic).toHaveBeenCalledTimes(3);
		});

		it("normalizes path separators", () => {
			const { cache, synthetic } = createCache({});

			cache.getSynthetic("/pkg/sub");
			cache.invalidateSynthetic("/pkg/sub/../sub");
			cache.getSynthetic("/pkg/sub");

			expect(synthetic).toHaveBeenCalledTimes(2);
		});
	});

	describe("invalidateAllSynthetic", () => {
		it("clears all synthetic entries", () => {
			const { cache, synthetic } = createCache({});

			cache.getSynthetic("/a");
			cache.getSynthetic("/b");
			cache.invalidateAllSynthetic();
			cache.getSynthetic("/a");
			cache.getSynthetic("/b");

			expect(synthetic).toHaveBeenCalledTimes(4);
		});

		it("does not clear fromPath cache", () => {
			const { cache, fromPath } = createCache({});

			cache.getFromPath("/cfg.json");
			cache.invalidateAllSynthetic();
			cache.getFromPath("/cfg.json");

			expect(fromPath).toHaveBeenCalledOnce();
		});
	});

	describe("getFromPathWithDiskCache", () => {
		const ROJO_CONFIG = path.resolve(__dirname, "../../../tests/default.project.json");
		const TMP_DIR = path.join(__dirname, "__getFromPathWithDiskCache_tmp__");

		beforeEach(() => {
			fs.mkdirpSync(TMP_DIR);
		});

		afterEach(() => {
			fs.removeSync(TMP_DIR);
		});

		it("persist callback swallows write failures so a failed cache write never breaks the build", () => {
			const cache = new RojoResolverCache();
			// Point at a path inside a non-existent parent dir that we then
			// re-replace with a file so outputFileSync's mkdirp leg fails too.
			const cacheFilePath = path.join(TMP_DIR, "blocked-dir", "rbxts.rojocache.json");
			// Block the parent: create a regular file where outputFileSync would
			// want to mkdirp a directory.
			fs.writeFileSync(path.join(TMP_DIR, "blocked-dir"), "");

			const { persist } = cache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);

			expect(() => persist()).not.toThrow();
			expect(fs.existsSync(cacheFilePath)).toBe(false);
		});

		it("walks on a full miss and the persist callback writes a cache file that round-trips", () => {
			const cache = new RojoResolverCache();
			const cacheFilePath = path.join(TMP_DIR, "rbxts.rojocache.json");
			expect(fs.existsSync(cacheFilePath)).toBe(false);

			const { resolver, persist } = cache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);
			expect(resolver.walkedConfigFiles.size).toBeGreaterThan(0);
			// No file yet — persist hasn't been called.
			expect(fs.existsSync(cacheFilePath)).toBe(false);

			persist();
			expect(fs.existsSync(cacheFilePath)).toBe(true);

			// Round-trip: a sibling cache instance should restore the same
			// rbxPath answers from the file we just wrote.
			const sibling = new RojoResolverCache();
			const { resolver: restored } = sibling.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);
			const state = resolver.getState();
			for (const [filePath] of state.filePathToRbxPathMap) {
				expect(restored.getRbxPathFromFilePath(filePath)).toEqual(resolver.getRbxPathFromFilePath(filePath));
			}
		});

		it("loads from the on-disk cache when the in-memory cache is cold and a valid cache file exists", () => {
			// First pass: real walk + persist, on a fresh cache instance.
			const firstCache = new RojoResolverCache();
			const cacheFilePath = path.join(TMP_DIR, "rbxts.rojocache.json");
			const first = firstCache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);
			first.persist();
			expect(fs.existsSync(cacheFilePath)).toBe(true);

			// Second pass: cold in-memory, hot on disk — fromPath must NOT be called.
			let fromPathCalls = 0;
			const fromPathSpy = vi.fn<FromPathFn>(configPath => {
				fromPathCalls++;
				return RojoResolver.fromPath(configPath);
			});
			const secondCache = new RojoResolverCache({
				fromPath: fromPathSpy,
				synthetic: RojoResolver.synthetic,
			});

			const { resolver: restored, persist } = secondCache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);

			expect(fromPathCalls).toBe(0);
			// The restored resolver must behave like the original for every known file.
			const original = first.resolver;
			const state = original.getState();
			for (const [filePath] of state.filePathToRbxPathMap) {
				expect(restored.getRbxPathFromFilePath(filePath)).toEqual(original.getRbxPathFromFilePath(filePath));
			}

			// L2 hit means persist is a no-op: removing the cache file then
			// invoking persist must not recreate it.
			fs.removeSync(cacheFilePath);
			persist();
			expect(fs.existsSync(cacheFilePath)).toBe(false);
		});

		it("returns the in-memory entry without touching the disk cache file when the in-memory cache is hot", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			let fromPathCalls = 0;
			const fromPathSpy = vi.fn<FromPathFn>(() => {
				fromPathCalls++;
				return resolver;
			});
			const cache = new RojoResolverCache({
				fromPath: fromPathSpy,
				synthetic: RojoResolver.synthetic,
			});
			const cacheFilePath = path.join(TMP_DIR, "rbxts.rojocache.json");

			// Prime L1 by calling once — also serves as the contract assertion
			// that L1 still owns the first walk.
			cache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);
			const { resolver: returned, persist } = cache.getFromPathWithDiskCache(ROJO_CONFIG, cacheFilePath);

			expect(returned).toBe(resolver);
			expect(fromPathCalls).toBe(1);
			// L1-hit must hand back a no-op persist — no point re-writing the
			// disk cache for a hit that came from memory.
			expect(fs.existsSync(cacheFilePath)).toBe(false);
			persist();
			expect(fs.existsSync(cacheFilePath)).toBe(false);
		});
	});

	describe("getSyntheticBatchWithDiskCache", () => {
		const PKG_BASE_A = path.resolve(__dirname, "../../../tests/node_modules/@rbxts");
		const TMP_DIR = path.join(__dirname, "__getSyntheticBatchWithDiskCache_tmp__");

		beforeEach(() => {
			fs.mkdirpSync(TMP_DIR);
		});

		afterEach(() => {
			fs.removeSync(TMP_DIR);
		});

		it("when every basePath is in the in-memory cache the disk file is not read", () => {
			const fakeBaseB = path.join(TMP_DIR, "fake-pkg-base");
			fs.mkdirpSync(fakeBaseB);
			const cache = new RojoResolverCache();
			const cacheFilePath = path.join(TMP_DIR, "typeroots.rojocache.json");

			// Prime L1 (no persist — disk file does not exist).
			cache.getSyntheticBatchWithDiskCache([PKG_BASE_A, fakeBaseB], cacheFilePath);
			expect(fs.existsSync(cacheFilePath)).toBe(false);

			// Plant a deliberately-malformed cache file that would crash if read.
			// Reaching it must fail the L1-hit contract.
			fs.writeFileSync(cacheFilePath, "{ corrupt json");

			const result = cache.getSyntheticBatchWithDiskCache([PKG_BASE_A, fakeBaseB], cacheFilePath);

			expect(result.resolvers.length).toBe(2);
		});

		it("invalidates on basePath membership change — adding or removing a base discards the cache", () => {
			const cacheFilePath = path.join(TMP_DIR, "typeroots.rojocache.json");
			const fakeBaseB = path.join(TMP_DIR, "fake-pkg-base-b");
			const fakeBaseC = path.join(TMP_DIR, "fake-pkg-base-c");
			fs.mkdirpSync(fakeBaseB);
			fs.mkdirpSync(fakeBaseC);

			const first = new RojoResolverCache();
			first.getSyntheticBatchWithDiskCache([PKG_BASE_A, fakeBaseB], cacheFilePath).persist();
			expect(fs.existsSync(cacheFilePath)).toBe(true);

			// Cold cache, different membership ({A,B} -> {A,C}) — must miss and walk.
			let syntheticCalls = 0;
			const second = new RojoResolverCache({
				fromPath: RojoResolver.fromPath,
				synthetic: basePath => {
					syntheticCalls++;
					return RojoResolver.synthetic(basePath);
				},
			});
			second.getSyntheticBatchWithDiskCache([PKG_BASE_A, fakeBaseC], cacheFilePath);

			expect(syntheticCalls).toBeGreaterThan(0);
		});

		it("cache key is order-invariant — same basePaths in any order hit the same cache file", () => {
			const cacheFilePath = path.join(TMP_DIR, "typeroots.rojocache.json");
			// First pass: pre-populate the cache file using order A, B.
			const fakeBaseB = path.join(TMP_DIR, "fake-pkg-base");
			fs.mkdirpSync(fakeBaseB);

			const first = new RojoResolverCache();
			const orderedAB = first.getSyntheticBatchWithDiskCache([PKG_BASE_A, fakeBaseB], cacheFilePath);
			orderedAB.persist();
			expect(fs.existsSync(cacheFilePath)).toBe(true);

			// Second pass: cold cache, opposite order — must still be a hit.
			let syntheticCalls = 0;
			const second = new RojoResolverCache({
				fromPath: RojoResolver.fromPath,
				synthetic: basePath => {
					syntheticCalls++;
					return RojoResolver.synthetic(basePath);
				},
			});
			const orderedBA = second.getSyntheticBatchWithDiskCache([fakeBaseB, PKG_BASE_A], cacheFilePath);

			expect(syntheticCalls).toBe(0);
			expect(orderedBA.resolvers.length).toBe(2);
		});
	});
});
