import { createTextDiagnostic } from "../util/createTextDiagnostic.ts";
import { DiagnosticError } from "./DiagnosticError.ts";

export class ProjectError extends DiagnosticError {
	constructor(message: string) {
		super([createTextDiagnostic(message)]);
	}
}
