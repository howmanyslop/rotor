import type ts from "typescript";

import { formatDiagnostics } from "../util/formatDiagnostics.ts";
import { LoggableError } from "./LoggableError.ts";

export class DiagnosticError extends LoggableError {
	public readonly diagnostics: ReadonlyArray<ts.Diagnostic>;

	constructor(diagnostics: ReadonlyArray<ts.Diagnostic>) {
		super();
		this.diagnostics = diagnostics;
	}

	public toString() {
		return formatDiagnostics(this.diagnostics);
	}
}
