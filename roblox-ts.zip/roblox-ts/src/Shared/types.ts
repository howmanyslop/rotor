import type ts from "typescript";

import type { ProjectType } from "./constants.ts";

export interface SourcePosition {
	line: number;
	column: number;
}

export interface ProjectOptions {
	includePath: string;
	rojo: string | undefined;
	type: ProjectType | undefined;
	logTruthyChanges: boolean;
	noInclude: boolean;
	usePolling: boolean;
	verbose: boolean;
	watch: boolean;
	writeOnlyChanged: boolean;
	writeTransformedFiles: boolean;
	optimizedLoops: boolean;
	allowCommentDirectives: boolean;
	luau: boolean;
}

export interface ProjectData {
	isPackage: boolean;
	nodeModulesPath: string;
	projectOptions: ProjectOptions;
	projectPath: string;
	rojoConfigPath: string | undefined;
	tsConfigPath: string;
	transformerWatcher?: TransformerWatcher;
}

export interface TransformerWatcher {
	service: ts.LanguageService;
	updateFile: (fileName: string, text: string) => void;
}

/**
 * Optional named export a transformer plugin may provide. When present, the
 * compiler calls this once per source file before invoking the transformer's
 * factory output. Returning `false` causes the file to skip the transformer
 * entirely, preserving identity all the way through the pipeline.
 *
 * Plugins must be **conservative**: return `true` whenever in doubt. Two
 * classes of failure to guard against:
 *
 * 1. **False negatives drop user code.** A predicate that returns `false` for
 *    a file the transformer would have modified produces incorrect emit with
 *    no diagnostic. Syntactic checks (e.g. "does the file import package X")
 *    are unsafe for type-driven transformers because barrel re-exports and
 *    aliases hide the dependency.
 * 2. **Cross-file side effects are skipped too.** If the transformer's
 *    per-file work includes bookkeeping that other files depend on (build-
 *    info, glob invalidation, reflection metadata aggregation), returning
 *    `false` skips that bookkeeping. The predicate must return `true` for
 *    any file whose side effects need to run, not only files the transformer
 *    visibly modifies.
 *
 * If the plugin cannot prove a file is safe to skip, do not implement this
 * hook. The compiler-side identity short-circuit still avoids the downstream
 * reprint cost as long as the transformer preserves SourceFile identity.
 */
export type ShouldTransformSourceFile = (
	file: ts.SourceFile,
	program: ts.Program,
	config: TransformerPluginConfig,
) => boolean;

export interface TransformerPluginConfig {
	/**
	 * Path to transformer or transformer module name
	 */
	transform?: string;

	/**
	 * The optional name of the exported transform plugin in the transform module.
	 */
	import?: string;

	/**
	 * Plugin entry point format type, default is program
	 */
	type?: "program" | "config" | "checker" | "raw" | "compilerOptions";

	/**
	 * Should transformer applied after all ones
	 */
	after?: boolean;

	/**
	 * Should transformer applied for d.ts files, supports from TS2.9
	 */
	afterDeclarations?: boolean;

	/**
	 * any other properties provided to the transformer as config argument
	 * */
	[options: string]: unknown;
}

export interface SourceFileWithTextRange {
	sourceFile: ts.SourceFile;
	range: ts.ReadonlyTextRange;
}
