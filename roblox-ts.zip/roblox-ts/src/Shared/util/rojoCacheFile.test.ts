import { RojoResolver } from "@isentinel/rojo-utils";
import fs from "fs-extra";
import path from "path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { serialiseRojoResolver, tryLoadResolver } from "./rojoCacheFile.ts";

const ROJO_CONFIG = path.resolve(__dirname, "../../../tests/default.project.json");
const TMP_DIR = path.join(__dirname, "__rojoCacheFile_tmp__");

describe("rojoCacheFile", () => {
	beforeEach(() => {
		fs.mkdirpSync(TMP_DIR);
	});

	afterEach(() => {
		fs.removeSync(TMP_DIR);
	});

	describe("serialiseRojoResolver", () => {
		it("captures the resolver's full state plus an mtime manifest for every walked file and dir", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);

			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);

			// Caller-supplied identity key — used at load time to confirm the cache
			// belongs to this rojo project before it gets restored.
			expect(cache.key).toBe(ROJO_CONFIG);
			// State round-trip surface is what makes the cache useful.
			expect(cache.state.filePathToRbxPathMap.length).toBeGreaterThan(0);
			// Manifest covers every walked path so a single mtime change anywhere
			// invalidates the cache. Pulling the names out of the manifest entries
			// lets us assert set equality without depending on ordering.
			const configFilePaths = cache.manifest.configFiles.map(([p]) => p).sort();
			const dirPaths = cache.manifest.dirs.map(([p]) => p).sort();
			expect(configFilePaths).toEqual([...resolver.walkedConfigFiles].sort());
			expect(dirPaths).toEqual([...resolver.walkedDirectories].sort());
			// mtimeMs is captured per entry — non-zero numbers from a real fs walk.
			for (const [, mtime] of cache.manifest.configFiles) {
				expect(mtime).toBeGreaterThan(0);
			}
		});
	});

	describe("tryLoadResolver", () => {
		it("returns undefined when the cache file does not exist", () => {
			const missing = path.join(TMP_DIR, "does-not-exist.json");

			expect(tryLoadResolver(missing, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when the cache file contains malformed JSON", () => {
			const corrupt = path.join(TMP_DIR, "corrupt.json");
			fs.writeFileSync(corrupt, "{ this is not json");

			expect(tryLoadResolver(corrupt, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when the cached cache-format version does not match the current version", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			const stale = { ...cache, version: cache.version + 1 };
			const cachePath = path.join(TMP_DIR, "stale-version.json");
			fs.writeFileSync(cachePath, JSON.stringify(stale));

			expect(tryLoadResolver(cachePath, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when the cached compilerVersion does not match the running compiler", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			const stale = { ...cache, compilerVersion: `${cache.compilerVersion}-old` };
			const cachePath = path.join(TMP_DIR, "stale-compiler.json");
			fs.writeFileSync(cachePath, JSON.stringify(stale));

			expect(tryLoadResolver(cachePath, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when the caller's key does not match the cached key", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			const cachePath = path.join(TMP_DIR, "key-mismatch.json");
			fs.writeFileSync(cachePath, JSON.stringify(cache));

			expect(tryLoadResolver(cachePath, `${ROJO_CONFIG}.different`)).toBeUndefined();
		});

		it("returns undefined when a manifest config file has been deleted from disk", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			// Inject a phantom manifest entry pointing at a path that has never
			// existed — simulates the user deleting a sub-rojo file between runs.
			const phantom = path.join(TMP_DIR, "deleted.project.json");
			const tampered = {
				...cache,
				manifest: {
					...cache.manifest,
					configFiles: [...cache.manifest.configFiles, [phantom, 1] as const],
				},
			};
			const cachePath = path.join(TMP_DIR, "missing-config.json");
			fs.writeFileSync(cachePath, JSON.stringify(tampered));

			expect(tryLoadResolver(cachePath, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when a manifest config file's mtime has changed since the cache was written", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			// Forge an mtime in the manifest that is guaranteed not to match disk.
			const tampered = {
				...cache,
				manifest: {
					...cache.manifest,
					configFiles: cache.manifest.configFiles.map(([p, mtime]) => [p, mtime + 1000] as [string, number]),
				},
			};
			const cachePath = path.join(TMP_DIR, "stale-config-mtime.json");
			fs.writeFileSync(cachePath, JSON.stringify(tampered));

			expect(tryLoadResolver(cachePath, ROJO_CONFIG)).toBeUndefined();
		});

		it("returns undefined when a manifest directory's mtime has changed since the cache was written", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG);
			const tampered = {
				...cache,
				manifest: {
					...cache.manifest,
					dirs: cache.manifest.dirs.map(([p, mtime]) => [p, mtime + 1000] as [string, number]),
				},
			};
			const cachePath = path.join(TMP_DIR, "stale-dir-mtime.json");
			fs.writeFileSync(cachePath, JSON.stringify(tampered));

			expect(tryLoadResolver(cachePath, ROJO_CONFIG)).toBeUndefined();
		});

		it("sentinel fast-path: an unchanged sentinel mtime restores the resolver even when the manifest entries are stale", () => {
			const resolver = RojoResolver.fromPath(ROJO_CONFIG);
			const sentinelPath = path.join(TMP_DIR, "sentinel.yaml");
			fs.writeFileSync(sentinelPath, "version: 1\n");
			// Serialise WITH the sentinel so its mtime is captured.
			const cache = serialiseRojoResolver(resolver, ROJO_CONFIG, sentinelPath);
			// Tamper the per-entry manifest in a way that would normally invalidate,
			// to prove the sentinel short-circuits the sweep.
			const tampered = {
				...cache,
				manifest: {
					configFiles: cache.manifest.configFiles.map(([p, mtime]) => [p, mtime + 1000] as [string, number]),
					dirs: cache.manifest.dirs.map(([p, mtime]) => [p, mtime + 1000] as [string, number]),
				},
			};
			const cachePath = path.join(TMP_DIR, "sentinel-fastpath.json");
			fs.writeFileSync(cachePath, JSON.stringify(tampered));

			const restored = tryLoadResolver(cachePath, ROJO_CONFIG);

			expect(restored).toBeDefined();
		});

		it("returns a hydrated resolver when version, key and every manifest entry match disk", () => {
			const original = RojoResolver.fromPath(ROJO_CONFIG);
			const cache = serialiseRojoResolver(original, ROJO_CONFIG);
			const cachePath = path.join(TMP_DIR, "valid.json");
			fs.writeFileSync(cachePath, JSON.stringify(cache));

			const restored = tryLoadResolver(cachePath, ROJO_CONFIG);

			expect(restored).toBeDefined();
			// Equality through the public API — same rbxPath for every known file.
			const state = original.getState();
			for (const [filePath] of state.filePathToRbxPathMap) {
				expect(restored!.getRbxPathFromFilePath(filePath)).toEqual(original.getRbxPathFromFilePath(filePath));
			}
		});
	});
});
