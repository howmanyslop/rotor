import ts from "typescript";

const BUILDINFO_EXT = ".tsbuildinfo";
const RBXTSC_INFIX = ".rbxtsc";

/**
 * Inserts the `.rbxtsc` infix before `.tsbuildinfo` so rbxtsc's incremental
 * cache never collides with tsgo's. Idempotent — calling on an already-suffixed
 * path is a no-op. Returns the input unchanged when it isn't a tsbuildinfo
 * path (defensive: lets the single transform be called from places that read
 * options.tsBuildInfoFile without proving it's set).
 */
export function addRbxtscInfix(filePath: string): string {
	if (!filePath.endsWith(BUILDINFO_EXT)) return filePath;
	const withoutExt = filePath.slice(0, -BUILDINFO_EXT.length);
	if (withoutExt.endsWith(RBXTSC_INFIX)) return filePath;
	return withoutExt + RBXTSC_INFIX + BUILDINFO_EXT;
}

/**
 * Mutates `options.tsBuildInfoFile` to the rbxtsc-suffixed path, computing
 * TS's default when not explicitly set. Returns silently when this project
 * isn't incremental (TS would emit no tsbuildinfo regardless).
 *
 * Apply at the single point a project's compilerOptions enters rbxtsc — both
 * the single-project path (getParsedCommandLine) and the --build path
 * (SolutionBuilderHost.getParsedCommandLine). After that, every reader of
 * `ts.getTsBuildInfoEmitOutputFilePath(options)` (including TS itself on
 * emit + readBuilderProgram) sees the suffixed path.
 */
export function applyRbxtscBuildInfoPath(options: ts.CompilerOptions): void {
	const resolved = ts.getTsBuildInfoEmitOutputFilePath(options);
	if (resolved === undefined) return;
	options.tsBuildInfoFile = addRbxtscInfix(resolved);
}
