import type ts from "typescript";
import { describe, expect, it } from "vitest";

import { addRbxtscInfix, applyRbxtscBuildInfoPath } from "./rbxtscBuildInfo.ts";

describe("addRbxtscInfix", () => {
	it("inserts .rbxtsc before .tsbuildinfo", () => {
		expect(addRbxtscInfix("foo.tsbuildinfo")).toBe("foo.rbxtsc.tsbuildinfo");
	});

	it("inserts .rbxtsc before .tsbuildinfo on nested paths", () => {
		expect(addRbxtscInfix("out/tsconfig.lib.tsbuildinfo")).toBe("out/tsconfig.lib.rbxtsc.tsbuildinfo");
	});

	it("is idempotent on already-suffixed paths", () => {
		expect(addRbxtscInfix("out/tsconfig.rbxtsc.tsbuildinfo")).toBe("out/tsconfig.rbxtsc.tsbuildinfo");
	});

	it("leaves non-tsbuildinfo paths untouched", () => {
		expect(addRbxtscInfix("foo.luau")).toBe("foo.luau");
	});
});

describe("applyRbxtscBuildInfoPath", () => {
	it("suffixes an explicit tsBuildInfoFile path", () => {
		const options: ts.CompilerOptions = {
			composite: true,
			tsBuildInfoFile: "out/tsconfig.tsbuildinfo",
		};
		applyRbxtscBuildInfoPath(options);
		expect(options.tsBuildInfoFile).toBe("out/tsconfig.rbxtsc.tsbuildinfo");
	});

	it("suffixes TS's default-computed path when tsBuildInfoFile is unset", () => {
		const options: ts.CompilerOptions = {
			composite: true,
			outDir: "out",
			configFilePath: "/proj/tsconfig.json",
		};
		applyRbxtscBuildInfoPath(options);
		// TS's default = <outDir>/<configBasename>.tsbuildinfo.
		expect(options.tsBuildInfoFile).toMatch(/tsconfig\.rbxtsc\.tsbuildinfo$/);
	});

	it("is a no-op when the project is not incremental", () => {
		const options: ts.CompilerOptions = {};
		applyRbxtscBuildInfoPath(options);
		expect(options.tsBuildInfoFile).toBeUndefined();
	});

	it("still suffixes for composite projects when incremental=false", () => {
		// `composite || incremental` is the gate, so `incremental=false` does
		// not suppress emission for composite projects — TS computes a default
		// path and writes there regardless. The suffix must land on that path
		// to dodge the tsgo collision the helper exists to prevent.
		const options: ts.CompilerOptions = {
			composite: true,
			configFilePath: "/proj/tsconfig.json",
			incremental: false,
			outDir: "out",
		};
		applyRbxtscBuildInfoPath(options);
		expect(options.tsBuildInfoFile).toMatch(/tsconfig\.rbxtsc\.tsbuildinfo$/);
	});

	it("is idempotent", () => {
		const options: ts.CompilerOptions = {
			composite: true,
			tsBuildInfoFile: "out/tsconfig.tsbuildinfo",
		};
		applyRbxtscBuildInfoPath(options);
		applyRbxtscBuildInfoPath(options);
		expect(options.tsBuildInfoFile).toBe("out/tsconfig.rbxtsc.tsbuildinfo");
	});
});
