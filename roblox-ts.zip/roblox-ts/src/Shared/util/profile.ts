const enabled = process.env.RBXTSC_PROFILE === "1";

function emit(name: string, deltaNs: bigint) {
	const ms = Number(deltaNs) / 1_000_000;
	process.stderr.write(`[profile] ${name} ${ms.toFixed(3)}ms\n`);
}

// Async fns measure scheduling time, not resolution time — the conditional return
// type makes those callsites a compile error rather than a silent wrong measurement.
export function profile<T>(name: string, fn: () => T extends Promise<unknown> ? never : T): T {
	if (!enabled) return fn() as T;
	const start = process.hrtime.bigint();
	try {
		return fn() as T;
	} finally {
		emit(name, process.hrtime.bigint() - start);
	}
}

// Async sibling of `profile` for callsites that genuinely need to measure a
// Promise's resolution time. The sync `profile` deliberately rejects these
// at the type level to prevent accidentally measuring only the scheduling cost.
export async function profileAsync<T>(name: string, fn: () => Promise<T>): Promise<T> {
	if (!enabled) return fn();
	const start = process.hrtime.bigint();
	try {
		return await fn();
	} finally {
		emit(name, process.hrtime.bigint() - start);
	}
}
