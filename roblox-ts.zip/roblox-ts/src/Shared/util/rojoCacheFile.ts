import type { RojoResolverState } from "@isentinel/rojo-utils";
import { RojoResolver } from "@isentinel/rojo-utils";
import { type } from "arktype";
import fs from "fs-extra";

import { COMPILER_VERSION } from "../constants.ts";
import { safeStatMtime } from "./safeStatMtime.ts";

const CACHE_VERSION = 1;

type ManifestEntry = [string, number];

export interface CacheFile {
	version: number;
	compilerVersion: string;
	key: string;
	state: RojoResolverState;
	manifest: {
		configFiles: Array<ManifestEntry>;
		dirs: Array<ManifestEntry>;
	};
	// Optional fast-path: a single mtime that, if unchanged, lets us skip the
	// per-entry manifest sweep (e.g. node_modules/.modules.yaml stands in for
	// every package walked from typeRoots).
	sentinel?: { path: string; mtimeMs: number };
}

// arktype's structural validator is what makes JSON.parse safe to consume —
// the project ban on `as T` casts forces every JSON edge to validate here.
export const manifestEntrySchema = type(["string", "number"]);

// RbxPath is ReadonlyArray<string> in the patched typings; JSON round-trips
// strip readonly so we validate it as a plain string[].
export const rbxPathSchema = type("string[]");

// Exported so the synthetic-batch cache in RojoResolverCache can reuse the
// exact shape — drift between the two validators would silently break one
// cache format.
export const rojoResolverStateSchema = type({
	partitions: type({
		rbxPath: rbxPathSchema,
		fsPath: "string",
	}).array(),
	filePathToRbxPathMap: type(["string", rbxPathSchema]).array(),
	isolatedContainers: rbxPathSchema.array(),
	isGame: "boolean",
	warnings: "string[]",
	walkedDirs: "string[]",
	walkedConfigFiles: "string[]",
});

export const sentinelSchema = type({
	path: "string",
	mtimeMs: "number",
});

const cacheFileSchema = type({
	version: "number",
	compilerVersion: "string",
	key: "string",
	state: rojoResolverStateSchema,
	manifest: {
		configFiles: manifestEntrySchema.array(),
		dirs: manifestEntrySchema.array(),
	},
	"sentinel?": sentinelSchema,
});

function manifestStillValid(entries: ReadonlyArray<ManifestEntry>): boolean {
	for (const [filePath, expectedMtime] of entries) {
		const actual = safeStatMtime(filePath);
		if (actual === undefined) return false;
		if (actual !== expectedMtime) return false;
	}
	return true;
}

function buildManifest(paths: ReadonlyArray<string>): Array<ManifestEntry> {
	const entries = new Array<ManifestEntry>();
	for (const filePath of paths) {
		const mtime = safeStatMtime(filePath);
		if (mtime === undefined) continue;
		entries.push([filePath, mtime]);
	}
	return entries;
}

export function serialiseRojoResolver(resolver: RojoResolver, key: string, sentinelPath?: string): CacheFile {
	const state = resolver.getState();
	const cache: CacheFile = {
		version: CACHE_VERSION,
		compilerVersion: COMPILER_VERSION,
		key,
		state,
		manifest: {
			configFiles: buildManifest(state.walkedConfigFiles),
			dirs: buildManifest(state.walkedDirs),
		},
	};
	if (sentinelPath !== undefined) {
		const mtimeMs = safeStatMtime(sentinelPath);
		if (mtimeMs !== undefined) cache.sentinel = { path: sentinelPath, mtimeMs };
	}
	return cache;
}

export function writeCacheFile(cacheFilePath: string, cache: CacheFile): void {
	try {
		fs.outputFileSync(cacheFilePath, JSON.stringify(cache));
	} catch {
		// Best-effort: cache write failures must never break the build.
	}
}

export function tryLoadResolver(cacheFilePath: string, key: string): RojoResolver | undefined {
	let raw: string;
	try {
		raw = fs.readFileSync(cacheFilePath, "utf-8");
	} catch {
		return undefined;
	}

	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch {
		return undefined;
	}

	const validated = cacheFileSchema(parsed);
	if (validated instanceof type.errors) return undefined;
	if (validated.version !== CACHE_VERSION) return undefined;
	if (validated.compilerVersion !== COMPILER_VERSION) return undefined;
	if (validated.key !== key) return undefined;

	// Sentinel fast-path: a single mtime stat replaces the full per-entry sweep
	// when the consumer can name a file that changes whenever the set of walked
	// packages does (e.g. node_modules/.modules.yaml after `pnpm install`).
	if (validated.sentinel !== undefined) {
		const sentinelMtime = safeStatMtime(validated.sentinel.path);
		if (sentinelMtime !== undefined && sentinelMtime === validated.sentinel.mtimeMs) {
			return RojoResolver.fromState(validated.state);
		}
	}

	if (!manifestStillValid(validated.manifest.configFiles)) return undefined;
	if (!manifestStillValid(validated.manifest.dirs)) return undefined;

	return RojoResolver.fromState(validated.state);
}
