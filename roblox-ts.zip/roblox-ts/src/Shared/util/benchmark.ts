import { LogService } from "../classes/LogService.ts";

function benchmarkStart(name: string) {
	LogService.write(`${name}`);
	return Date.now();
}

function benchmarkEnd(startTime: number) {
	LogService.write(` ( ${Date.now() - startTime} ms )\n`);
}

export function benchmarkSync(name: string, callback: () => void) {
	const startTime = benchmarkStart(name);
	callback();
	benchmarkEnd(startTime);
}

export function benchmarkIfVerbose(name: string, callback: () => void) {
	if (LogService.verbose) {
		benchmarkSync(name, callback);
	} else {
		callback();
	}
}

export async function benchmarkAsync<T>(name: string, callback: () => Promise<T>): Promise<T> {
	const startTime = benchmarkStart(name);
	const result = await callback();
	benchmarkEnd(startTime);
	return result;
}

export async function benchmarkAsyncIfVerbose<T>(name: string, callback: () => Promise<T>): Promise<T> {
	if (LogService.verbose) {
		return benchmarkAsync(name, callback);
	}
	return callback();
}

export async function benchmark<T>(name: string, callback: () => Promise<T>) {
	const startTime = benchmarkStart(name);
	await callback();
	benchmarkEnd(startTime);
}
