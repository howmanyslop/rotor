import fs from "fs-extra";

/**
 * Stat a path and return its mtime in ms, or undefined if the path is missing
 * or unreadable. Treats every error as "cache miss" — callers are expected to
 * use the absence as a signal, not propagate the failure.
 */
export function safeStatMtime(filePath: string): number | undefined {
	try {
		return fs.statSync(filePath).mtimeMs;
	} catch {
		return undefined;
	}
}
