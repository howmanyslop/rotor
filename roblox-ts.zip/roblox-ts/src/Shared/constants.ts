import { fileURLToPath } from "node:url";

import fs from "fs";
import path from "path";

import type { ProjectOptions } from "./types.ts";

function findPackageRoot(dir: string): string {
	if (fs.existsSync(path.join(dir, "package.json"))) return dir;
	const parent = path.dirname(dir);
	if (parent === dir) throw new Error(`Could not find package.json from ${dir}`);
	return findPackageRoot(parent);
}

export const PACKAGE_ROOT = findPackageRoot(path.dirname(fileURLToPath(import.meta.url)));
export const INCLUDE_PATH = path.join(PACKAGE_ROOT, "include");

const { version } = JSON.parse(fs.readFileSync(path.join(PACKAGE_ROOT, "package.json"), "utf8")) as {
	version: string;
};
export const COMPILER_VERSION: string = version;

export const NODE_MODULES = "node_modules";
export const RBXTS_SCOPE = "@rbxts";

export const TS_EXT = ".ts";
export const TSX_EXT = ".tsx";
export const D_EXT = ".d";
export const DTS_EXT = D_EXT + TS_EXT;

export const INDEX_NAME = "index";
export const INIT_NAME = "init";

export const SERVER_SUBEXT = ".server";
export const CLIENT_SUBEXT = ".client";
export const MODULE_SUBEXT = "";

export const FILENAME_WARNINGS = new Map<string, string>();
for (const scriptType of [SERVER_SUBEXT, CLIENT_SUBEXT, MODULE_SUBEXT]) {
	for (const fileType of [TS_EXT, TSX_EXT, DTS_EXT]) {
		FILENAME_WARNINGS.set(INIT_NAME + scriptType + fileType, INDEX_NAME + scriptType + fileType);
	}
}

export const PARENT_FIELD = "Parent";

export const ProjectType = {
	Game: "game",
	Model: "model",
	Package: "package",
} as const;
export type ProjectType = (typeof ProjectType)[keyof typeof ProjectType];

export const DEFAULT_PROJECT_OPTIONS: ProjectOptions = {
	includePath: "",
	rojo: undefined,
	type: undefined,
	watch: false,
	usePolling: false,
	verbose: false,
	noInclude: false,
	logTruthyChanges: false,
	writeOnlyChanged: false,
	writeTransformedFiles: false,
	optimizedLoops: true,
	allowCommentDirectives: false,
	luau: true,
};
