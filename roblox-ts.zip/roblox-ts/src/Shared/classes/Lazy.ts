export class Lazy<T> {
	private isInitialized = false;
	private value: T | undefined;
	private readonly getValue: () => T;

	constructor(getValue: () => T) {
		this.getValue = getValue;
	}

	public get() {
		if (!this.isInitialized) {
			this.isInitialized = true;
			this.value = this.getValue();
		}
		return this.value as T;
	}

	public set(value: T) {
		this.isInitialized = true;
		this.value = value;
	}
}
