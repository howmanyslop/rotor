import fs from "fs-extra";
import path from "path";
import ts from "typescript";
import type { Argv, CommandModule } from "yargs";

import { rojoResolverCache } from "../../Project/classes/RojoResolverCache.ts";
import { buildSolution } from "../../Project/functions/buildSolution.ts";
import { buildSolutionWatch } from "../../Project/functions/buildSolutionWatch.ts";
import { cleanup } from "../../Project/functions/cleanup.ts";
import { compileFiles } from "../../Project/functions/compileFiles.ts";
import { copyFiles } from "../../Project/functions/copyFiles.ts";
import { copyInclude } from "../../Project/functions/copyInclude.ts";
import { createPathTranslator } from "../../Project/functions/createPathTranslator.ts";
import { createProjectData } from "../../Project/functions/createProjectData.ts";
import { createProjectProgram } from "../../Project/functions/createProjectProgram.ts";
import { getChangedSourceFiles } from "../../Project/functions/getChangedSourceFiles.ts";
import { getTsConfigProjectOptions } from "../../Project/functions/getTsConfigProjectOptions.ts";
import { setupProjectWatchProgram } from "../../Project/functions/setupProjectWatchProgram.ts";
import { loadCopyFilesGatePreBuild } from "../../Project/util/loadCopyFilesGatePreBuild.ts";
import { loadRojoCachesPreBuild } from "../../Project/util/loadRojoCachesPreBuild.ts";
import { runRbxtsEmit } from "../../Project/util/runRbxtsEmit.ts";
import { snapshotBuildState } from "../../Project/util/snapshotBuildState.ts";
import { LogService } from "../../Shared/classes/LogService.ts";
import { DEFAULT_PROJECT_OPTIONS, ProjectType } from "../../Shared/constants.ts";
import { LoggableError } from "../../Shared/errors/LoggableError.ts";
import type { ProjectOptions } from "../../Shared/types.ts";
import { getRootDirs } from "../../Shared/util/getRootDirs.ts";
import { hasErrors } from "../../Shared/util/hasErrors.ts";
import { profile, profileAsync } from "../../Shared/util/profile.ts";
import { CLIError } from "../errors/CLIError.ts";

function findTsConfigPath(projectPath: string) {
	let tsConfigPath: string | undefined = path.resolve(projectPath);
	if (!fs.existsSync(tsConfigPath) || !fs.statSync(tsConfigPath).isFile()) {
		tsConfigPath = ts.findConfigFile(tsConfigPath, ts.sys.fileExists);
		if (tsConfigPath === undefined) {
			throw new CLIError("Unable to find tsconfig.json!");
		}
	}
	return path.resolve(process.cwd(), tsConfigPath);
}

interface BuildFlags {
	project: string;
	build?: string | true;
	emitDeclarationOnly?: boolean;
}

/**
 * Defines the behavior for the `rbxtsc build` command.
 */
export default ts.identity<CommandModule<object, BuildFlags & Partial<ProjectOptions>>>({
	command: ["$0", "build"],

	describe: "Build a project",

	builder: (parser: Argv) =>
		parser
			.option("project", {
				alias: "p",
				string: true,
				default: ".",
				describe: "project path",
			})
			.option("build", {
				alias: "b",
				string: true,
				coerce: (val: string) => val || true,
				describe: "build project references (optionally specify tsconfig path)",
			})
			.option("emitDeclarationOnly", {
				boolean: true,
				implies: "build",
				describe: "only emit declaration files",
			})
			// DO NOT PROVIDE DEFAULTS BELOW HERE, USE DEFAULT_PROJECT_OPTIONS
			.option("watch", {
				alias: "w",
				boolean: true,
				describe: "enable watch mode",
			})
			.option("usePolling", {
				implies: "watch",
				boolean: true,
				describe: "use polling for watch mode (single-project --watch only; --build --watch defers to ts.sys)",
			})
			.option("verbose", {
				boolean: true,
				describe: "enable verbose logs",
			})
			.option("noInclude", {
				boolean: true,
				describe: "do not copy include files",
			})
			.option("logTruthyChanges", {
				boolean: true,
				describe: "logs changes to truthiness evaluation from Lua truthiness rules",
			})
			.option("writeOnlyChanged", {
				boolean: true,
				hidden: true,
			})
			.option("writeTransformedFiles", {
				boolean: true,
				hidden: true,
				describe: "writes resulting TypeScript ASTs after transformers to out directory",
			})
			.option("optimizedLoops", {
				boolean: true,
				hidden: true,
			})
			.option("type", {
				choices: [ProjectType.Game, ProjectType.Model, ProjectType.Package] as const,
				describe: "override project type",
			})
			.option("includePath", {
				alias: "i",
				string: true,
				describe: "folder to copy runtime files to",
			})
			.option("rojo", {
				string: true,
				describe: "manually select Rojo project file",
			})
			.option("allowCommentDirectives", {
				boolean: true,
				hidden: true,
			})
			.option("luau", {
				boolean: true,
				describe: "emit files with .luau extension",
			}),

	handler: async argv => {
		try {
			const projectPath = typeof argv.build === "string" ? argv.build : argv.project;
			const tsConfigPath = findTsConfigPath(projectPath);

			let tsConfigChain = new Set<string>();
			// parse the contents of the retrieved JSON path as a partial `ProjectOptions`
			let projectOptions: ProjectOptions = Object.assign(
				{},
				DEFAULT_PROJECT_OPTIONS,
				getTsConfigProjectOptions(tsConfigPath, tsConfigChain),
				argv,
			);

			LogService.verbose = projectOptions.verbose === true;

			const diagnosticReporter = ts.createDiagnosticReporter(ts.sys, true);

			if (argv.build) {
				if (projectOptions.watch) {
					if (argv.emitDeclarationOnly) {
						throw new CLIError(
							"--build --watch is incompatible with --emitDeclarationOnly (no Luau emit to incrementally watch)",
						);
					}
					await buildSolutionWatch(tsConfigPath, projectOptions, {
						verbose: projectOptions.verbose,
					});
					return;
				}
				const exitStatus = await buildSolution(tsConfigPath, projectOptions, {
					emitDeclarationOnly: argv.emitDeclarationOnly,
					verbose: projectOptions.verbose,
				});
				if (exitStatus !== ts.ExitStatus.Success) process.exitCode = 1;
				return;
			}

			if (projectOptions.watch) {
				let watchData = createProjectData(tsConfigPath, projectOptions);
				while (true) {
					const shouldRestart = await setupProjectWatchProgram(
						watchData,
						projectOptions.usePolling,
						tsConfigChain,
					);
					if (!shouldRestart) break;
					tsConfigChain = new Set<string>();
					projectOptions = Object.assign(
						{},
						DEFAULT_PROJECT_OPTIONS,
						getTsConfigProjectOptions(tsConfigPath, tsConfigChain),
						argv,
					);
					LogService.verbose = projectOptions.verbose === true;
					watchData = createProjectData(tsConfigPath, projectOptions);
				}
				return;
			}

			const data = profile("createProjectData", () => createProjectData(tsConfigPath, projectOptions));
			const program = profile("createProjectProgram", () => createProjectProgram(data));
			const pathTranslator = profile("createPathTranslator", () => createPathTranslator(program, data));

			// Load rojo caches BEFORE cleanup/copyInclude/copyFiles — those phases
			// mutate dirs whose mtimes are in the cache manifest, which would
			// falsely invalidate the cache on the next run.
			const compilerOptions = program.getCompilerOptions();
			const rojoCaches = profile("loadRojoCaches", () =>
				loadRojoCachesPreBuild(rojoResolverCache, {
					rojoConfigPath: data.rojoConfigPath,
					typeRoots: compilerOptions.typeRoots ?? [],
					outDir: compilerOptions.outDir!,
					nodeModulesPath: data.nodeModulesPath,
				}),
			);

			// Snapshot the BuilderProgram's changedFilesSet BEFORE any consumer
			// (getChangedSourceFiles) drains it. Both the warm-noop gate and the
			// changed-source-files lookup read the snapshot so they observe an
			// identical view of "what TS thinks changed".
			const snapshot = profile("snapshotBuildState", () => snapshotBuildState(program));

			const rootDirs = getRootDirs(compilerOptions);

			// Walk rootDirs once + compare with the manifest from the previous run.
			// Skip cleanup/copyFiles when nothing relevant drifted.
			const copyFilesGate = profile("loadCopyFilesGate", () =>
				loadCopyFilesGatePreBuild({
					rootDirs,
					outDir: compilerOptions.outDir!,
					declaration: compilerOptions.declaration === true,
					pathTranslator,
					snapshot,
				}),
			);

			profile("cleanup", () => {
				if (copyFilesGate.skipCleanup) return;
				cleanup(pathTranslator);
			});
			profile("copyInclude", () => copyInclude(data));
			profile("copyFiles", () => {
				if (copyFilesGate.skipCopyFiles) return;
				copyFiles(data, pathTranslator, new Set(rootDirs));
			});
			// Capture changedSourceFiles BEFORE runRbxtsEmit's BuilderProgram
			// emit — that emit walks affected files and drains
			// state.changedFilesSet as it goes (TS 6.0.3 typescript.js
			// ~131559-131574, ~132354-132368), so a post-emit lookup would
			// see an empty set on cold builds and skip the .luau pass.
			const changedSourceFiles = profile("getChangedSourceFiles", () =>
				getChangedSourceFiles(program, rootDirs, [...snapshot.changedFilePaths]),
			);

			const { compileResult, preEmitDiagnostics, emittedSuccessfully } = await profileAsync("runRbxtsEmit", () =>
				runRbxtsEmit({
					program,
					compileThunk: tsProgram => compileFiles(tsProgram, data, pathTranslator, changedSourceFiles),
				}),
			);

			// Persist after all output settles so manifest mtimes match the next
			// run's pre-build state.
			profile("persistRojoCaches", () => rojoCaches.persistAll());
			// Skip the copyFiles manifest persist if emit produced errors —
			// the manifest's mtimes would mark a partial-output build as
			// settled, letting the next run skip cleanup/copyFiles over it.
			// Mirrors the exit-code condition below so the persist gate and
			// the failure criterion stay aligned.
			if (emittedSuccessfully && !hasErrors(preEmitDiagnostics) && !hasErrors(compileResult.diagnostics)) {
				profile("persistCopyFilesGate", () => copyFilesGate.persist());
			}

			for (const diagnostic of preEmitDiagnostics) diagnosticReporter(diagnostic);
			for (const diagnostic of compileResult.diagnostics) diagnosticReporter(diagnostic);
			if (hasErrors(preEmitDiagnostics) || hasErrors(compileResult.diagnostics)) {
				process.exitCode = 1;
			}
		} catch (e) {
			process.exitCode = 1;
			if (e instanceof LoggableError) {
				e.log();
				debugger;
			} else {
				throw e;
			}
		}
	},
});
