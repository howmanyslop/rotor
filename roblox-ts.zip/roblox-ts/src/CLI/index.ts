export * from "../Project/index.ts";
export { COMPILER_VERSION } from "../Shared/constants.ts";
import "./util/patchFs.ts";
