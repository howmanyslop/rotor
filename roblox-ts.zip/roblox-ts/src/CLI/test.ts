import fs from "fs-extra";
import path from "path";
import { describe, it } from "vitest";

import { compileFiles } from "../Project/functions/compileFiles.ts";
import { copyFiles } from "../Project/functions/copyFiles.ts";
import { copyInclude } from "../Project/functions/copyInclude.ts";
import { createPathTranslator } from "../Project/functions/createPathTranslator.ts";
import { createProjectData } from "../Project/functions/createProjectData.ts";
import { createProjectProgram } from "../Project/functions/createProjectProgram.ts";
import { getChangedSourceFiles } from "../Project/functions/getChangedSourceFiles.ts";
import { DEFAULT_PROJECT_OPTIONS, PACKAGE_ROOT, TS_EXT, TSX_EXT } from "../Shared/constants.ts";
import type { DiagnosticFactory } from "../Shared/diagnostics.ts";
import { errors, getDiagnosticId } from "../Shared/diagnostics.ts";
import { assert } from "../Shared/util/assert.ts";
import { formatDiagnostics } from "../Shared/util/formatDiagnostics.ts";
import { getRootDirs } from "../Shared/util/getRootDirs.ts";
import { isPathDescendantOf } from "../Shared/util/isPathDescendantOf.ts";

const DIAGNOSTIC_TEST_NAME_REGEX = /^(\w+)(?:\.\d+)?$/;

describe("should compile tests project", () => {
	const data = createProjectData(
		path.join(PACKAGE_ROOT, "tests", "tsconfig.json"),
		Object.assign({}, DEFAULT_PROJECT_OPTIONS, {
			project: "",
			allowCommentDirectives: true,
			optimizedLoops: true,
		}),
	);
	const program = createProjectProgram(data);
	const pathTranslator = createPathTranslator(program, data);

	// clean outDir between test runs
	fs.removeSync(program.getCompilerOptions().outDir!);

	it("should copy include files", () => copyInclude(data));

	it("should copy non-compiled files", () =>
		copyFiles(data, pathTranslator, new Set(getRootDirs(program.getCompilerOptions()))));

	const diagnosticsFolder = path.join(PACKAGE_ROOT, "tests", "src", "diagnostics");

	for (const sourceFile of getChangedSourceFiles(program, getRootDirs(program.getCompilerOptions()))) {
		const fileName = path.relative(process.cwd(), sourceFile.fileName);
		if (isPathDescendantOf(path.normalize(sourceFile.fileName), diagnosticsFolder)) {
			let fileBaseName = path.basename(sourceFile.fileName);
			const ext = path.extname(fileBaseName);
			if (ext === TS_EXT || ext === TSX_EXT) {
				fileBaseName = path.basename(sourceFile.fileName, ext);
			}
			const diagnosticName = fileBaseName.match(DIAGNOSTIC_TEST_NAME_REGEX)?.[1] as keyof typeof errors;
			assert(diagnosticName && errors[diagnosticName], `Diagnostic test for unknown diagnostic ${fileBaseName}`);
			const expectedId = (errors[diagnosticName] as DiagnosticFactory).id;
			it(`should compile ${fileName} and report diagnostic ${diagnosticName}`, async () => {
				process.env.ROBLOX_TS_EXPECTED_DIAGNOSTIC_ID = String(expectedId);
				const emitResult = await compileFiles(program.getProgram(), data, pathTranslator, [sourceFile]);
				delete process.env.ROBLOX_TS_EXPECTED_DIAGNOSTIC_ID;
				if (
					emitResult.diagnostics.length > 0 &&
					emitResult.diagnostics.every(d => getDiagnosticId(d) === expectedId)
				) {
					return;
				} else if (emitResult.diagnostics.length === 0) {
					throw new Error(`Expected diagnostic ${diagnosticName} to be reported.`);
				} else {
					throw new Error("Unexpected diagnostics:\n" + formatDiagnostics(emitResult.diagnostics));
				}
			});
		} else {
			it(`should compile ${fileName}`, async () => {
				const emitResult = await compileFiles(program.getProgram(), data, pathTranslator, [sourceFile]);
				if (emitResult.diagnostics.length > 0) {
					throw new Error("\n" + formatDiagnostics(emitResult.diagnostics));
				}
			});
		}
	}
});
