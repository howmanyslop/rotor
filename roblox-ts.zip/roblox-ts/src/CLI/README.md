# roblox-ts CLI

This handles the command line interface (CLI) entry point for roblox-ts.

The CLI should create Project instances as needed based on input from the user.

Only behavior unique to CLI environments should go here. Any behavior that is common to both the CLI and the playground environments belongs in Project.

## Structure

**commands/** - stores all of the yargs-based subcommands for the cli interface

**commands/build.ts** - the `build` command, this runs by default and can have the following flags:

-   `--project, -p` - Location of the tsconfig.json or folder containing the tsconfig.json _(defaults to ".")_
-   `--watch, -w` - Enable watch mode, recompiles files as they change. Creates a Watcher object. _(defaults to false)_
-   `--includePath, -i` - Path to where the runtime library files should be stored. _(defaults to "include")_
-   `--rojo` - Path to the Rojo configuration file. By default this will attempt to find a \*.project.json in your project folder.

## `rbxts` tsconfig field

Project-stable options can be set directly in `tsconfig.json` via a top-level `rbxts` object. CLI flags override the tsconfig values, so you can pin defaults in the file and still override per-invocation:

```jsonc
{
    "$schema": "./node_modules/@isentinel/roblox-ts/schemas/rbxts-tsconfig.schema.json",
    "compilerOptions": { /* ... */ },
    "rbxts": {
        "rojo": "./halcyon.project.json",
        "type": "game",
        "luau": true
    }
}
```

**Precedence:** CLI argv > tsconfig `rbxts` > built-in defaults.

**Allowed keys:** `rojo`, `type`, `includePath`, `noInclude`, `logTruthyChanges`, `allowCommentDirectives`, `luau`, `optimizedLoops`. Unknown keys (including CLI-only flags like `watch`, `verbose`, or `usePolling`) are warned about and ignored.

**Path resolution:** `rojo` and `includePath` resolve relative to the tsconfig file that declares them, not the current working directory. When using `extends`, a base tsconfig's `rbxts.rojo` points at a file relative to the base tsconfig's directory.

**Extends:** Base tsconfigs' `rbxts` fields cascade into descendants. Child keys override parent keys.

**Watch mode:** Editing any tsconfig in the extends chain triggers a full rebuild with the new options — no restart needed.

**Schema:** Reference `schemas/rbxts-tsconfig.schema.json` via the `"$schema"` field for IDE autocomplete and validation.

**modules/** - stores various classes related to running CLI processes

**modules/Initializer.ts** - used to create projects from templates using the `init` command.

**cli.ts** - used to kickstart yargs
