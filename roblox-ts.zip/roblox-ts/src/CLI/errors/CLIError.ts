import { DiagnosticError } from "../../Shared/errors/DiagnosticError.ts";
import { createTextDiagnostic } from "../../Shared/util/createTextDiagnostic.ts";

export class CLIError extends DiagnosticError {
	constructor(message: string) {
		super([createTextDiagnostic(message)]);
	}
}
