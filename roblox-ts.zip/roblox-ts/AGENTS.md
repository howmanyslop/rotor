# roblox-ts Compiler Notes

## Release and verification

This package has no `project.json`, so Nx does not own it and the pre-commit
affected run covers none of it — verify compiler changes by hand. It is not a
synced-upstream package, so a PR touching it needs no `sync-commit:` line.
`CHANGELOG.md` is frozen at the inherited 3.0.0 and takes no new entries, and a
version bump lands as its own release commit.

## Asserting emitted Luau

`VirtualProject.compileSource` is the only in-repo way to assert emitted Luau;
runtime specs cannot tell two equivalent emits apart. Seed its virtual
filesystem with the `@rbxts` type packages before compiling, or the compile
fails on the globals macro resolution expects.

## Two programs per project

With transformer plugins configured, `compileFiles` swaps to a second program —
a LanguageService — and per-file `getPreEmitDiagnostics` runs against THAT
program, not the solution-builder one. Any program-construction behaviour
(project-reference declaration redirect, module resolution knobs like
`realpath`) must be wired into the LanguageServiceHost too, or plugin-enabled
builds diverge from plugin-less ones. Symptom of divergence: an error that
appears only when `plugins` is non-empty — typically TS6059 for a paths alias
into a referenced project's source, which the builder program redirects to the
emitted `.d.ts`.

## Transformer plugin buckets

`createTransformerList` sorts plugin factories into `before` / `after` (both
source-file passes) and `afterDeclarations` (the declaration printer's pass).
`flattenIntoTransformers` collapses only the first two into the list
`ts.transformNodes` consumes. `compileFiles` reads the `afterDeclarations`
bucket separately and prepends it to the builtin `transformTypeReferenceDirectives`
+ `transformPaths` pair handed to `Program.emit`, so plugin rewrites land before
the builtins normalize module specifiers. Flattening `afterDeclarations` in with
the rest feeds those factories source files and routes their output into the
Luau emit.

That declaration emit is reachable only from the chokidar `--watch` path, which
calls `compileFiles` directly. `build` and `--build` go through `runRbxtsEmit`,
which forces `declaration:false` on the shared `CompilerOptions` object for the
whole compile thunk — declarations there come from the earlier builder/solution
emit, which passes no `customTransformers` at all.

## Solution Builder Emit

`buildSolution` drives `ts.createSolutionBuilder(...).getNextInvalidatedProject()`
directly so rbxtsc can run its own copy, Rojo, Luau emit, and cache steps around
each TypeScript project.

`runRbxtsEmit` first advances the TypeScript `BuilderProgram` and writes only
declaration outputs plus `.tsbuildinfo`, then runs rbxtsc's Luau `compileFiles`
pass. In `--build` mode this uses `InvalidatedProject.emit(undefined, writeFile)`
rather than `BuilderProgram.emit(...)` so TypeScript's solution-builder state
advances past its internal emit step before `project.done()`.

Passing `emitOnlyDtsFiles: true` to `InvalidatedProject.emit` is not equivalent
to a declaration-only solution-builder emit. TypeScript handles that overload by
calling the underlying builder program directly and does not advance the
solution-builder emit step, so a later `project.done()` can emit again. Prefer
testing any declaration-only optimization against the solution-builder state
machine, not just against `BuilderProgram.emit`.

`.tsbuildinfo` paths are suffixed with `.rbxtsc` by
`applyRbxtscBuildInfoPath` before TypeScript reads or writes build info. The
newly-emitted build info is buffered in memory rather than written to disk, so
the prior `.tsbuildinfo` stays untouched while `compileFiles` runs; it is
flushed only when the Luau emit succeeds (on failure/skip the buffer is dropped
and the prior, or absent, build info is already correct). This satisfies
Flamework's dirty-environment guard — the prior `.tsbuildinfo` plus its paired
`flamework.build` read as a settled state — and makes a Ctrl-C mid-compile
leave an incremental-ready build info instead of forcing a cold rebuild.

TypeScript's solution-builder and affected-file emit loops are synchronous. Any
parallelism for Luau emit or file writes has to live outside TypeScript's
builder internals. Declaration *writes* rather than declaration printing are
the largest removable cost on Windows: thousands of tiny `.d.ts` files spend
most of their time in native `closeSync`. Buffering those writes and flushing
them while `compileFiles` runs is the open direction — preserve
solution-builder step advancement and await the flush before `project.done()`.

## Watch mode

`--watch` alone is single-project and chokidar-driven; `--build --watch` drives
the solution builder with TS-native watchers. A project with references MUST use
`--build --watch`; one without can use either. The chokidar path is maintained,
not developed.

### Why builder.build() runs after the initial async drain

TS arms its source-file watchers inside `startWatching()`, which is called
ONLY at the end of `builder.build()`'s `buildWorker` loop. A raw
`getNextInvalidatedProject` drain leaves watchers dormant.

The initial-drain handler in `buildSolutionWatch` calls `builder.build()`
after our async drain. Because every project has already been `done()`d,
`builder.build()` sees no invalidated projects, exits its loop immediately,
and falls through to `startWatching` — arming watchers without re-emitting.

### Rojo dependency watching

Watching the rojo config file alone is insufficient. The resolver walks every
nested `.project.json` it finds and any of those can affect resolution, so the
watch set covers each walked config file plus each walked directory — a new
nested rojo file appearing inside a watched directory has to invalidate too.

Invalidation is scoped: the fromPath resolvers and the synthetic typeRoot batch
have separate caches, and clearing the first alone leaves the second stale.

### Dependent project propagation

A rojo mount change inside project A alters the require path emitted by
referencing project B without changing B's TS inputs, so TS's input-change check
would skip B's rebuild. The watch loop force-invalidates every transitive
dependent instead. The reverse-reference graph is rebuilt at the start of each
drain, so a root-tsconfig `references` edit is reflected before those
force-invalidations are queued.

### Asset-copy drain

Non-TS files inside `rootDir` (hand-authored `.luau`, `.json`) need a copy or a
remove, not a TS rebuild, so they run on their own coalesced queue while `.ts`
events delegate back to TS's watch path.

### Per-project failure boundary

One project's emit failure surfaces a diagnostic without stalling its siblings
in the same tick. A failed project's pending persists are never pushed; every
other project's still flush at the end of the drain. Asset-drain failures are
isolated per file for the same reason.

### Test fixtures

The batch and watch build-mode suites use two copies of the same fixture so
they can run in parallel without contending on a shared `out/`. A change to the
source structure has to land in both.
